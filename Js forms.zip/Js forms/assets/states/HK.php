<?php
/**
 * Hong Kong states
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$states['HK'] = array(
	'HONG KONG'       => __( 'Hong Kong Island', 'erforms' ),
	'KOWLOON'         => __( 'Kowloon', 'erforms' ),
	'NEW TERRITORIES' => __( 'New Territories', 'erforms' ),
);
