<div class="jsF-wrapper wrap">
    <div class="jsF-page-title">
        <h1 class="wp-heading-inline"><?php _e('jsF Help Tags', 'jsForms') ?></h1>
    </div>
    <div class="wrap jsF-help jsF-tags jsForms-admin-content">
        <?php if (!empty($form)): ?>
            <div class="jsF-table-title">
                <h3 class="wp-heading-inline jsF-tags-title"><?php _e('Form Field tags', 'jsForms') ?></h3>
            </div>

            <table class="wp-list-table widefat fixed striped jsF-tags-table">
                <thead>
                    <tr>
                        <th class="manage-column"><?php _e('Tag', 'jsForms') ?></th>
                        <th class="manage-column column-title"><?php _e('Type', 'jsForms') ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $non_input_fields = jsForms_non_input_fields();
                    array_push($non_input_fields, 'password');
                    $field_count=0;
                    foreach ($form['fields'] as $field) {
                        ?>
                        <?php if (!in_array($field['type'], $non_input_fields) ) { $field_count++; ?>
                            <tr>
                                <td><code>{{<?php echo $field['label']; ?>}}</code></td>
                                <td><?php echo $field['type']; ?></td>
                            </tr>
                        <?php } ?>
                    <?php } ?>
                    
                    <?php if(empty($field_count)): ?>        
                        <tr>
                            <td colspan="2"><?php _e('No form fields available.','jsForms'); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        <?php endif; ?>
        <div class="jsF-table-title">
            <h3 class="wp-heading-inline jsF-tags-title"><?php _e('Global Shortcodes', 'jsForms') ?></h3>
        </div>
        
        <table class="wp-list-table widefat fixed striped jsF-tags-table">
            <thead>
                <tr>
                    <th class="manage-column"><?php _e('Tag', 'jsForms') ?></th>
                    <th class="manage-column column-title"><?php _e('Description', 'jsForms') ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><code>[jsForms id="X"]</code></td>
                    <td><?php _e("It renders form in any page/post, 'X' denotes the ID of a form.",'jsForms') ?></td>
                </tr>

                <tr>
                    <td><code>[jsForms_my_account]</code></td>
                    <td><?php _e('Shows listing of all the submissions completed by logged in user. Allows to edit or delete the submission from frontend. Also show profile information and password change options.','jsForms') ?> </td>
                </tr>
                
                <tr>
                    <td><code>[jsForms_my_submissions]</code></td>
                    <td><?php _e('Shows listing of all the submissions completed by logged in user. Also allows to edit or delete the submission from frontend.','jsForms') ?> </td>
                </tr>

                <tr>
                    <td><code>[jsForms_login]</code></td>
                    <td><?php _e('Shows login form with Lost Password link.','jsForms') ?></td>
                </tr>
                
                <tr>
                    <td><code>[jsForms_user_meta key="meta_key_name"]</code></td>
                    <td><?php _e("Shows user meta value for the user. <br>Example: [jsForms_user_meta key='last_name']", 'jsForms') ?> </td>
                </tr>
                
                <tr>
                    <td><code>[jsForms_submission_counter form="form_id" skip="0" skip_before="mm/dd/yyyy"]</code></td>
                    <td><?php _e("Displays submission counter for a form. `skip` and `skip_before` are optionals.", 'jsForms') ?> </td>
                </tr>
                
            </tbody>
        </table>
        
        
        <div class="jsF-table-title">
            <h3 class="wp-heading-inline jsF-tags-title"><?php _e('System tags', 'jsForms') ?></h3>
        </div>

        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th class="manage-column"><?php _e('Tag', 'jsForms') ?></th>
                    <th class="manage-column column-title"><?php _e('Description', 'jsForms') ?></th>
                </tr>
            </thead>    

            <tbody>
                <tr>
                    <td><code>{{registration_data}}</code></td>
                    <td><?php _e("Shows submission with all the fields and payment details(if applicable).", 'jsForms') ?></td>
                </tr>
                
                <?php if(!empty($form) && $form['type']=='reg'): ?>
                <tr>
                    <td><code>{{verification_link}}</code></td>
                    <td><?php printf(__("Shows user verification link. Should be used within <a href='%s'>User Verification</a> template.", 'jsForms'),admin_url('admin.php?page=jsForms-dashboard&tab=notifications&form_id='.$form['id'])); ?></td>
                </tr>
                <?php endif; ?>
                
                <tr>
                    <td><code>{{unique_id}}</code></td>
                    <td><?php _e("Submission Unique ID(if enabled in the form configuration).", 'jsForms') ?></td>
                </tr>
               
                <tr>
                    <td><code>{{user_email}}</code></td>
                    <td><?php _e("User's email address.", 'jsForms') ?></td>
                </tr>

                <tr>
                    <td><code>{{user_login}}</code></td>
                    <td><?php _e("User's login name.", 'jsForms') ?> </td>
                </tr>

                <tr>
                    <td><code>{{user_display_name}}</code></td>
                    <td><?php _e("User's display name.", 'jsForms') ?> </td>
                </tr>
                
                <tr>
                    <td><code>{{display_name}}</code></td>
                    <td><?php _e("User's display name. Otherwise, returns Primary Contact name from the configuration.", 'jsForms') ?> </td>
                </tr>
                
                <tr>
                    <td><code>{{user_nicename}}</code></td>
                    <td><?php _e("User's nicename.", 'jsForms') ?> </td>
                </tr>
                
                <tr>
                    <td><code>{{user_firstname}}</code></td>
                    <td><?php _e("User's firstname.", 'jsForms') ?> </td>
                </tr>

                <tr>
                    <td><code>{{user_lastname}}</code></td>
                    <td><?php _e("User's lastname.", 'jsForms') ?> </td>
                </tr>

                <tr>
                    <td><code>{{user_id}}</code></td>
                    <td><?php _e("User's ID.", 'jsForms') ?> </td>
                </tr>
                
            </tbody>
        </table>
    </div>
</div>      