<div class="wrap about-wrap full-width-layout jsf-addons jsf-wrapper">
    <div class="jsf-page-title">
        <h1 class="wp-heading-inline"><?php _e('Easy Registration Form Add-on', 'jsforms'); ?></h1>
    </div>
    <div class="jsf-add-on-wrap jsforms-admin-content">
        <div class="jsf-add-on">
            <a target="_blank" href="https://github.com/privacyradius/gdpr-checklist/">
            <div class="add-on-img">
                <img src="<?php echo jsfORMS_PLUGIN_URL.'/assets/admin/images/addons/gdpr-compliance.png' ?>">
            </div>
            <h3><?php _e('GDPR compliance', 'jsforms'); ?></h3>
            <p><?php _e('Allow to add GDPR/privacy compliance checkbox in the end of form. Also integrates with WordPress Export Personal Data and Erase Personal Data.', 'jsforms'); ?></p>
            </a>
        </div>
        <div class="jsf-add-on">
            <a target="_blank" href="" target="_blank">
            <div class="add-on-img">
                        
                <img src="<?php echo jsfORMS_PLUGIN_URL.'/assets/admin/images/addons/conditional-logics.png' ?>">
            </div>
            <h3><?php _e('Conditional Logics', 'jsforms'); ?></h3>
            <p><?php _e('Conditional Logic extension allows you to show/hide fields on the basis of desired conditions in addition mail can be sent to various recipients on the basis of selected.', 'jsforms'); ?></p>
            </a>
        </div>
        <div class="jsf-add-on">
            <a target="_blank" href="">
            <div class="add-on-img">
                <img src="<?php echo jsfORMS_PLUGIN_URL.'/assets/admin/images/addons/mail-chimp.png' ?>">
            </div>
            <h3><?php _e('Mailchimp Integration', 'jsforms'); ?></h3>
            <p><?php _e('Create MailChimp signup forms in WordPress to grow your email list.', 'jsforms'); ?></p>
            </a>
        </div>        
        <div class="jsf-add-on">
            <a target="_blank" href="">
            <div class="add-on-img">
                <img src="<?php echo jsfORMS_PLUGIN_URL.'/assets/admin/images/addons/paypal.png' ?>">
            </div>
            <h3><?php _e('PayPal Integration', 'jsforms'); ?></h3>
            <p><?php _e('Allows user to pay through PayPal', 'jsforms'); ?></p>
            </a>
        </div>
        <div class="jsf-add-on">
            <a target="_blank" href="">
            <div class="add-on-img">
                <img src="<?php echo jsfORMS_PLUGIN_URL.'/assets/admin/images/addons/stripe.jpg' ?>">
            </div>
            <h3><?php _e('Stripe Integration', 'jsforms'); ?></h3>
            <p><?php _e('Allows user to pay through Stripe', 'jsforms'); ?></p>
            </a>
        </div>
        <div class="jsf-add-on">
            <a target="_blank" href="">
            <div class="add-on-img">
                <img src="<?php echo jsfORMS_PLUGIN_URL.'/assets/admin/images/addons/submission-importer.png' ?>">
            </div>
            <h3><?php _e('Submission Importer', 'jsforms'); ?></h3>
            <p><?php _e('allows to import bulk data as submissions from any CSV file.', 'jsforms'); ?></p>
            </a>
        </div>
        <div class="jsf-add-on">
            <a target="_blank" href="">
            <div class="add-on-img">
                <img src="<?php echo jsfORMS_PLUGIN_URL.'/assets/admin/images/addons/views.png' ?>">
            </div>
            <h3><?php _e('Submission Views', 'jsforms'); ?></h3>
            <p><?php _e('Simple yet powjsful way to display Submission entries on your website.', 'jsforms'); ?></p>
            </a>
        </div>
        <div class="jsf-add-on">
            <a target="_blank" href="">
            <div class="add-on-img">
                <img src="<?php echo jsfORMS_PLUGIN_URL.'/assets/admin/images/addons/plugin-bundle.png' ?>">
            </div>
            <h3><?php _e('Plugin Bundle', 'jsforms'); ?></h3>
            <p><?php _e('All our premium features in one bundle.', 'jsforms'); ?></p>
            </a>
        </div>
    </div>

    
    
    <div class="jsf-feature-request">
        <h4><?php _e('Have a feature in mind, share with us ', 'jsforms'); ?><a href="/" target="_blank"><?php _e('here', 'jsforms'); ?></a></h4>
    </div>
</div>

<style>
    .jsf-add-on-wrap{
        display: flex;
	flex-direction: row;
	flex-wrap: wrap;
	justify-content: space-between;
	align-items: stretch;
	align-content: center;
    }
    .jsf-add-on-wrap .jsf-add-on{
        width: 23%;
        max-width: 300px;
        text-align: center;
        padding: 10px;
        margin-bottom: 30px;
        box-sizing: border-box;
        box-shadow: 0 0 2rem 0 rgba(136,152,170,.15);
        border-radius: 10px;
        transition: all 0.15s ease-in-out;
    }
    .jsf-add-on-wrap .jsf-add-on:hover{
        transform: translateY(-5px);
    }
    .jsf-add-on-wrap a{
        text-decoration: none;
        color: inherit;
    }
    .jsf-add-on-wrap img{
        border-radius: 4px; 
    }
    .jsf-add-on-wrap h3{
        font-size: 17px;
    }
    .jsf-feature-request h4{
        text-align: center;
    }
    @media all and (max-width: 1200px) {}
    @media all and (max-width: 979px) {}
    @media all and (max-width: 767px) {
        .jsf-add-on-wrap .jsf-add-on{
            width: 50%;
            max-width: 300px;
        }
    }
    @media all and (max-width: 479px) {}

</style>
