<?php
/**
 *
 * @package    JSForms
 * @author     JSForms
 * @since      1.0.0
 */
class JSForms_Addon {

	/**
	 *
	 * @since 1.0.0
	 */
	public function __construct() {

		// Maybe load overview page.
		add_action( 'admin_init', array( $this, 'init' ) );
	}

	/**
	 * Determing if the user is viewing the overview page, if so, party on.
	 *
	 * @since 1.0.0
	 */
	public function init() {

		// Check what page we are on.
		$page = isset( $_GET['page'] ) ? sanitize_text_field($_GET['page']) : '';
		// Only load if we are actually on the overview page.
		if ( 'jsforms-addon' === $page ) {
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueues' ) );
			add_action( 'jsforms_admin_page',    array( $this, 'output'   ) );
		}
	}

	

	/**
	 * Enqueue assets for the Help page.
	 *
	 * @since 1.0.0
	 */
	public function enqueues() {
            wp_enqueue_script('jquery-ui-tabs');
            wp_enqueue_style('jsf-admin-style');
	}

	/**
	 * Build the output for the overview page.
	 *
	 * @since 1.0.0
	 */
	public function output() {
            include 'html/addon.php';
	}
}
new JSForms_Addon;