<?php 
    $menus= jsForms_global_setting_menus();
    $tab= !empty($_REQUEST['tab']) ? sanitize_text_field($_REQUEST['tab']) : '';
    if(!in_array($tab, array_keys($menus))){
        $tab= '';
    }
?>
<?php if(empty($tab)): ?>
    <div class="jsF-wrapper jsForms-settings wrap">
        <div class="jsF-page-title">
            <h1 class="wp-heading-inline">
                <?php _e('Global Settings', 'jsForms'); ?>
            </h1>
            <div class="jsF-page-menu">
                <ul class="jsF-nav clearfix">

                </ul>        
            </div>
        </div>
        <div class="jsF-settings-wrap jsForms-admin-content">
            <?php foreach($menus as $slug=>$menu): ?>
                    <a class="jsF-setting" href="?page=jsForms-settings&tab=<?php echo $slug; ?>" class="jsF-settings-<?php echo $slug; ?>">
                        <div class="jsF-setting-icon">
                            <img src="<?php echo jsFORMS_PLUGIN_URL?>/assets/admin/images/global/<?php echo $slug; ?>-icon.png" style="border-color: transparent; background-color: transparent; box-shadow: 0 0 0 rgba(50, 50, 93, .11), 0 0 0 rgba(0, 0, 0, .08);">
                        </div>
                        <div class="jsF-setting-content">
                            <span class="jsF-setting-title"><?php echo $menu['label'];  ?></span>
                            <div class="jsF-setting-desc"><?php echo implode(',', $menu['desc']);  ?></div>
                        </div>
                    </a>  
            <?php endforeach; ?>
        </div>
    </div> 
<?php else: include('setting-tab.php'); ?>
<?php endif; ?>

