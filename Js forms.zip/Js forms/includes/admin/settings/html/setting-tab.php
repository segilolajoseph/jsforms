<div class="jsF-wrapper jsForms-settings wrap">
    <div class="jsF-page-title">
        <h1 class="wp-heading-inline">
            <?php echo $menus[$tab]['label']; ?>
        </h1>
    </div>
    <div class="jsForms-admin-content">
        <form method="POST">
            <fieldset>
                <div style="<?php echo $tab == 'general' ? '' : 'display:none' ?>">
                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php echo __('Default Registration Page', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control">
                            <?php wp_dropdown_pages(array('selected' => $options['default_register_url'], 'show_option_none' => 'Select Page', 'option_none_value' => 0, 'name' => 'default_register_url', 'class' => 'jsF-input-field')); ?>
                            <p class="description"><?php _e('Replaces default WordPress registration page.', 'jsForms') ?></p>
                        </div>  
                    </div>

                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php echo __('Default Upload Directory', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control">
                            <input pattern="^[A-Za-z-_]+$" type="text" class="jsF-input-field" name="upload_dir" value="<?php echo esc_attr($options['upload_dir']); ?>" />
                            <p class="description"><?php _e('Upload directory name where all the file uploads will take place. Please do not use any special characters in directory name. (Only Alphabets,Hyphens(-) and Underscores(_) allowed.)', 'jsForms') ?></p>
                        </div>  
                    </div>
                    
                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php echo __('Disable Submission Token', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control">
                            
                            <input class="jsF_toggle" type="checkbox" name="disable_sub_token" value="1" <?php echo empty($options['disable_sub_token']) ? '' : 'checked'; ?>/>
                            <label></label>
                            <p class="description"><?php _e('Disables security token. It is recommended to be disabled only when users are getting security token error while submission. ', 'jsForms') ?></p>
                        </div>  
                    </div>

                    <?php do_action('jsF_settings_general', $options, $tab); ?> 
                </div>

                <div style="<?php echo $tab == 'user_login' ? '' : 'display:none' ?>">
                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Form Layout', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control">
                            <select name="login_layout" class="jsF-input-field">
                                <option <?php echo $options['login_layout'] == "one-column" ? 'selected' : ''; ?> value="one-column"><?php _e('One Column', 'jsForms'); ?></option>
                                <option <?php echo $options['login_layout'] == "two-column" ? 'selected' : ''; ?> value="two-column"><?php _e('Two Column', 'jsForms'); ?></option>
                            </select>    
                            <p class="description"><?php _e('Login Form layout.', 'jsForms'); ?></p>
                        </div>   
                    </div>

                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Field Style', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control">
                            <select name="login_field_style" class="jsF-input-field">
                                <option <?php echo $options['login_field_style'] == "flat" ? 'selected' : ''; ?> value="flat"><?php _e('Flat', 'jsForms'); ?></option>
                                <option <?php echo $options['login_field_style'] == "rounded" ? 'selected' : ''; ?> value="rounded"><?php _e('Rounded', 'jsForms'); ?></option>
                                <option <?php echo $options['login_field_style'] == "rounded-corner" ? 'selected' : ''; ?> value="rounded-corner"><?php _e('Rounded Corner', 'jsForms'); ?></option>
                                <option <?php echo $options['login_field_style'] == "border-bottom" ? 'selected' : ''; ?> value="border-bottom"><?php _e('Border Bottom', 'jsForms'); ?></option>
                            </select> 
                            <p class="description"><?php _e('Field style for login form fields.', 'jsForms'); ?></p>
                        </div> 
                    </div>

                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Label Position', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control">
                            <select name="login_label_position" class="jsF-input-field">
                                <option <?php echo $options['login_label_position'] == "top" ? 'selected' : ''; ?> value="top"><?php _e('Top', 'jsForms'); ?></option>
                                <option <?php echo $options['login_label_position'] == "inline" ? 'selected' : ''; ?> value="inline"><?php _e('Inline', 'jsForms'); ?></option>
                                <option <?php echo $options['login_label_position'] == "no-label" ? 'selected' : ''; ?> value="no-label"><?php _e('No Label', 'jsForms'); ?></option>
                            </select>  
                            <p class="description"><?php _e('Label position for login form fields.', 'jsForms'); ?></p>
                        </div>  
                    </div>

                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Hide WordPress admin bar', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control">
                            <input class="jsF_toggle" type="checkbox" name="hide_admin_bar" value="1" <?php echo empty($options['hide_admin_bar']) ? '' : 'checked'; ?>/>
                            <label></label>
                            <p class="description"><?php _e('Hides top WordPress admin bar for logged in front end users.', 'jsForms') ?></p>
                        </div>  
                    </div>

                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Allow login from', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control">
                            <select name="allow_login_from" class="jsF-input-field">
                                <option <?php echo $options['allow_login_from'] == 'username' ? 'selected' : ''; ?> value="username"><?php _e('Username', 'jsForms'); ?></option>
                                <option <?php echo $options['allow_login_from'] == 'email' ? 'selected' : ''; ?> value="email"><?php _e('Email', 'jsForms'); ?></option>
                                <option <?php echo $options['allow_login_from'] == 'both' ? 'selected' : ''; ?> value="both"><?php _e('Username and Email', 'jsForms'); ?></option>
                            </select>  
                            <p class="description"><?php _e("Allows to login from Email,Username or both.", 'jsForms') ?></p>
                        </div>  
                    </div>

                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Social Login Shortcode', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control">
                            <textarea name="social_login" class="jsF-input-field"><?php echo $options['social_login']; ?></textarea>
                            <p class="description"><?php _e("Place any content (including shortcodes) after login button. Useful in case you want to integrate any other plugin's functionality with jsF Login. For example: You can use a Social Login plugin and can place the shortcode here.", 'jsForms'); ?></p>
                        </div>  
                    </div>
                    
                    <?php if (!empty($options['recaptcha_configured'])) : ?>
                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Enable reCaptcha', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control">
                            <input class="jsF_toggle" type="checkbox" name="en_login_recaptcha" value="1" <?php echo empty($options['en_login_recaptcha']) ? '' : 'checked'; ?>/>
                            <label></label>
                            <p class="description"><?php _e("It helps protect websites from spam and abuse. A “CAPTCHA” is a test to tell human and bots apart. Make sure recaptcha is configured in <b>Global Settings->External Integration->Configure Google reCaptcha</b>", 'jsForms'); ?></p>
                        </div>  
                    </div>
                    <?php endif; ?>
                    
                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('After Login Redirection', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control">
                            <input type="url" class="jsF-input-field" name="after_login_redirect_url" value="<?php echo esc_url($options['after_login_redirect_url']) ?>" />
                            <p class="description"><?php _e('URL of the page where user will be redirected after login to WordPress. This value will be overriden in case below role based redirection is enabled and configured.', 'jsForms') ?></p>
                        </div>  
                    </div>

                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Role Based Login Redirection', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control jsF-has-child">
                            <input class="jsF_toggle" class="jsF-input-field" type="checkbox" name="en_role_redirection" value="1" <?php echo empty($options['en_role_redirection']) ? '' : 'checked'; ?>/>
                            <label></label>
                            <p class="description"><?php _e('Enable login redirection per role.', 'jsForms') ?></p>
                        </div>  
                    </div>

                    <div class="jsF-child-rows" style="<?php echo !empty($options['en_role_redirection']) ? '' : 'display:none'; ?>">
                        <?php $roles = jsForms_wp_roles(); ?>
                        <?php foreach ($roles as $key => $role): ?>
                            <div class="jsF-row">
                                <div class="jsF-control-label">
                                    <label><?php echo $role['name']; ?></label>
                                </div>
                                <div class="jsF-control">
                                    <input type="text" class="jsF-input-field" value="<?php echo isset($options[$key . '_login_redirection']) ? esc_attr($options[$key . '_login_redirection']) : '' ?>" name="<?php echo $key ?>_login_redirection" />
                                    <p class="description"><?php echo $role['name'] . __(' will be redirected to this URL after login.', 'jsForms') ?></p>
                                </div>  
                            </div>               
                        <?php endforeach; ?>
                    </div>

                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Logout Redirection', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control jsF-has-child">
                            <input type="text" class="jsF-input-field" value="<?php echo esc_url($options['logout_redirection']); ?>" name="logout_redirection" />
                            <p class="description"><?php _e('Page URL where user will be directed after logout. Leave empty for WordPress default behaviour.', 'jsForms'); ?></p>
                        </div>  
                    </div>

                    <?php do_action('jsF_settings_user_login', $options, $tab); ?> 
                </div>

                <div style="<?php echo $tab == 'external' ? '' : 'display:none' ?>">
                    <div class="jsF-row <?php echo jsForms_is_woocommerce_activated() ? '' : 'jsF-disabled'; ?>">
                        <div class="jsF-control-label">
                            <label><?php _e('WooCommerce My Account Integration', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control">
                            <input class="jsF_toggle" type="checkbox" name="en_wc_my_account" value="1" <?php echo empty($options['en_wc_my_account']) ? '' : 'checked'; ?>/>
                            <label></label>
                            <p class="description"><?php _e('Adds a <b>Submissions</b> link in WooCommerce <b>My Account</b> area. Please resave Permalinks from WordPress settings.', 'jsForms') ?></p>
                        </div>  
                    </div>
                    
                    <div class="jsF-row" id="jsF_recaptcha">
                        <div class="jsF-control-label">
                            <label><?php _e('Configure Google Recaptcha', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control jsF-has-child">
                            <input class="jsF_toggle" type="checkbox" data-has-child="1" data-jsF-child="jsF_settings_recaptcha_options" id="jsF_settings_recaptcha_configured" name="recaptcha_configured" value="1" <?php echo empty($options['recaptcha_configured']) ? '' : 'checked'; ?>/>
                            <label></label>
                            <p class="description"><?php _e('It helps protect websites from spam and abuse. A “CAPTCHA” is a test to tell human and bots apart. Also make sure to enable Recapctha setting in Form->Configure->General Settings.', 'jsForms') ?></p>
                        </div>  
                    </div>
                    
                    
                    <div class="jsF-child-rows" style="<?php echo !empty($options['recaptcha_configured']) ? '' : 'display:none'; ?>"> 
                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Version', 'jsForms'); ?></label>
                            </div>
                            <div class="jsF-control">
                                <select name="recaptcha_version" class="jsF-input-field">
                                    <option <?php echo $options['recaptcha_version'] == "2" ? 'selected' : ''; ?> value="2"><?php _e('reCpatcha v2', 'jsForms'); ?></option>
                                    <option <?php echo $options['recaptcha_version'] == "3" ? 'selected' : ''; ?> value="3"><?php _e('reCpatcha v3', 'jsForms'); ?></option>
                                </select>
                                <p class="description"><?php _e('Mandatory for reCAPTCHA. For more details, <a href="https://www.google.com/recaptcha/intro/index.html">Click Here</a>', 'jsForms') ?></p>
                            </div>  
                        </div>
                        
                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Site Key', 'jsForms'); ?></label>
                            </div>
                            <div class="jsF-control">
                                <input type="text" class="jsF-input-field" name="rc_site_key" value="<?php echo esc_attr($options['rc_site_key']); ?>"/>
                                <p class="description"><?php _e('Mandatory for reCAPTCHA. For more details, <a href="https://www.google.com/recaptcha/intro/index.html">Click Here</a>', 'jsForms') ?></p>
                            </div>  
                        </div>

                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Secret Key', 'jsForms'); ?></label>
                            </div>
                            <div class="jsF-control">
                                <input type="text" class="jsF-input-field" name="rc_secret_key" value="<?php echo esc_attr($options['rc_secret_key']); ?>"/>
                                <p class="description"><?php _e('Mandatory for reCAPTCHA. For more details, <a href="https://www.google.com/recaptcha/intro/index.html">Click Here</a>', 'jsForms') ?></p>
                            </div>  
                        </div>
                    </div>
                    <?php 
                        $extensions = jsForms()->extensions; 
                        if(in_array('views', $extensions)):
                    ?>
                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Google Map API Key', 'jsForms'); ?></label>
                            </div>
                            <div class="jsF-control">
                                <input type="text" class="jsF-input-field" name="gmap_api" value="<?php echo esc_attr($options['gmap_api']); ?>"/>
                                <p class="description"><?php _e('Mandatory to use Google Map field inside views.', 'jsForms') ?></p>
                            </div>  
                        </div>
                    <?php endif; ?>
                    
                    <?php do_action('jsF_settings_external', $options); ?> 
                </div>

                <?php do_action('jsF_global_settings', $options, $tab); ?> 

                <div style="<?php echo $tab == 'payments' ? '' : 'display:none' ?>">
                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Currency', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control">
                            <?php $currencies = jsForms_currencies(); ?>
                            <select name="currency" class="jsF-input-field">
                                <?php foreach ($currencies as $code => $name): ?>
                                    <?php if ($options['currency'] == $code): ?>
                                        <option selected value="<?php echo esc_attr($code); ?>"><?php echo $name . jsForms_currency_symbol($code); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo esc_attr($code); ?>"><?php echo $name . jsForms_currency_symbol($code); ?></option>
                                    <?php endif; ?>    
                                <?php endforeach; ?>
                            </select>    
                        </div>  
                    </div>

                    <?php do_action('jsF_settings_payment', $options); ?>
                </div>

                <div style="<?php echo $tab == 'notifications' ? '' : 'display:none' ?>">
                    <?php include('notifications.php'); ?>
                </div>

                <input type="hidden" name="jsF_save_settings" />
                <?php $type = !empty($_REQUEST['type']) ? sanitize_text_field($_REQUEST['type']) : ''; ?>
                <div style="<?php echo $tab == 'notifications' && empty($type) ? 'display:none' : '' ?>">
                    <p class="submit">
                        <input type="submit" class="button button-primary" value="<?php _e('Save', 'jsForms'); ?>" name="save" /> 
                        <input type="submit" class="button button-primary" value="<?php _e('Save & Close', 'jsForms'); ?>" name="savec" /> 
                    </p>
                </div>
            </fieldset>
        </form>
    </div>
</div>
