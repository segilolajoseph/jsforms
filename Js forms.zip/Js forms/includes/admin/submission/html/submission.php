<?php
$options = jsForms()->options->get_options();
$form = jsForms()->form->get_form($submission['form_id']);
//jsForms_debug($submission);
?>
<div class="jsF-wrapper wrap">
    <div class="jsF-page-title">
        <h1><?php echo $form['title']; ?> - <?php _e('Submission Details', 'jsForms'); ?></h1>
    </div>
    <div class="jsForms-admin-content">
        <div class="tablenav top">

            <div class="alignleft actions">
                <a id="jsF_submission_add_note" class="button button-primary" href="javascript:void(0)"><?php _e('Add Note', 'jsForms'); ?></a>
            </div>
            <div class="alignleft actions">
                <a id="jsF_submission_print" class="button" href="#"><?php _e('Print', 'jsForms'); ?></a>
            </div>
            
            <div class="alignleft actions">
                <form target="_blank" method="POST" action="<?php echo add_query_arg(array('jsForm_id'=>$submission['form_id']),get_permalink($options['preview_page'])); ?>">
                    <a class="button jsF_edit_submission" href="javascript:void(0)"><?php _e('Edit', 'jsForms'); ?></a>
                    <input type="hidden" name="submission_id" value="<?php echo esc_attr($submission['id']); ?>" />
                </form>
            </div>

            <?php if (!empty($form['en_edit_sub'])): ?>
                <?php if (isset($submission['dis_edit_submission']) && $submission['dis_edit_submission'] == 1): ?>
                    <div class="alignleft actions">
                        <a class="button button-primary" href="<?php print wp_nonce_url(admin_url('admin.php?page=jsForms-submission&submission_id=' . $sub_id), 'enable_edit_submission', 'en_edit_sub_nonce'); ?>"><?php _e('Enable Edit Submission', 'jsForms'); ?></a>
                    </div>
                <?php else: ?>
                    <div class="alignleft actions">
                        <a class="button button-danger" href="<?php print wp_nonce_url(admin_url('admin.php?page=jsForms-submission&submission_id=' . $sub_id), 'disable_edit_submission', 'dis_edit_sub_nonce'); ?>"><?php _e('Disable Edit Submission', 'jsForms'); ?></a>
                    </div>
                <?php endif; ?>

            <?php endif; ?>
            
            <?php if(!empty($revisions)): ?>
                <div class="alignleft actions">
                    <a class="button button-primary" href="<?php echo admin_url('admin.php?page=jsForms-submission&view=revisions&submission_id=' . $sub_id); ?>"><?php _e('History', 'jsForms'); ?></a>
                </div>
            <?php endif; ?>
            
            <div class="alignleft actions">
                <a class="button button-danger" href="<?php print wp_nonce_url(admin_url('admin.php?page=jsForms-submissions&submission_id=' . $sub_id), 'submission_delete', 'delete_nonce'); ?>"><?php _e('Delete', 'jsForms'); ?></a>
            </div>
            
        </div>
        <?php if (!empty($submission['user'])): ?>
            <div class="jsF-submission-from jsF-feature-request">
                <strong><?php _e('Submission From: ', 'jsForms'); ?></strong>
                <a target="_blank" href="<?php echo get_edit_user_link($submission['user']['ID']); ?>"><?php echo $submission['user']['user_email']; ?></a>
            </div>
        <?php endif; ?>
        <div class="jsF-submission-tags clearfix">
            <?php
            // Show if any tag exists in the system.  
            $tags = jsForms()->label->get_tags();
            $sanitized_tags = jsForms()->label->get_tags(true);
            
            if(!empty($tags)){
                ?>
                <div class="jsF-assigned-labels">
                    <?php
                    if(!empty($submission['tags'])){
                        foreach($submission['tags'] as $selected_tag){
                            echo '<div class="jsF-label" style="background-color: '.$tags[$selected_tag].'">'.$selected_tag.'<span class="fa fa-times jsF-remove-label" data-val="'.$selected_tag.'">X</span></div>';
                        }
                    }else{
                        echo '<div class="jsF-no-label">'.__('No Label Assigned', 'jsForms').'</div>';
                    }
                    ?>
                </div>
            <div class="jsF-label-search">
                <input class="jsF-input-field" type="search" placeholder="Labels">
                <div class="jsF-label-list" style="display:none">
                    <div class="jsF-label-heading">Apply labels to this submission</div>
                    <?php
                    foreach ($tags as $key => $value) {
                        if(!in_array($key, $submission['tags'])){
                            echo '<div class="jsF-assign-label jsF-submission-label"><span class="label-color" style="background-color: ' . $value. ';"></span>' . $key . '</div>';
                        }
                    }
                    ?>
                    <div class="add-new-label jsF-submission-label"><a target="_blank"href="<?php echo admin_url('admin.php?page=jsForms-labels'); ?>"><span class="dashicons dashicons-plus"></span><?php _e('Create New Label', 'jsForms'); ?></a></div>
                </div>
            </div>
                <?php
            }
            ?>
        </div>
        <div id="jsF_admin_submission_details">
            <?php jsForms_admin_submission_table($submission); ?>
            <?php if (!empty($submission['plans'])) {
                    include('payment-part.php');
                  }
            ?>
            <div class="jsF-payment-info">

            </div>
        </div>    

        <?php if (!empty($notes) && is_array($notes)) : ?>
            <div class="jsF-notes">
                <div class="jsF-notes-title"><?php _e('Note(s)', 'jsForms'); ?></div>
                <div class="jsF-notes-wrap">
                    <?php foreach ($notes as $note) : ?>
                        <div class="jsF-note-row">
                            <p>
                                <?php echo $note['text']; ?>
                                <span class="jsF-note-info"> 
                                    <?php _e('By', 'jsForms'); ?>
                                    <?php echo $note['by']; ?> on
                                    <?php echo $note['time']; ?>
                                </span>
                                <?php if(!empty($note['recipients'])): ?>
                                    <span class="jsF-note-info">
                                         <?php _e('Email sent to','jsForms'); ?>  
                                         <?php echo $note['recipients']; ?>
                                    </span>
                                <?php endif; ?>
                            </p>
                        </div>  
                    <?php endforeach; ?>
                </div>
            </div>    
        <?php endif; ?>


        <div id="jsF_submission_add_note_dialog" class="jsF_dialog" style="display: none;">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title"><?php _e('ADD  NOTE', 'jsForms'); ?></h5>
                        <button type="button" class="close jsF_close_dialog">
                            <span>×</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <div class="jsF-form-name">
                            <?php _e('Note', 'jsForms'); ?>
                            <textarea name="note_text" id="jsF_submission_note_text" class="jsF-input-field"></textarea>
                            <input type="hidden" name="add_note" />
                            <p class="description">
                                <?php printf(__('Email content to be sent to the user. Create personalized message using <a href="%s" target="_blank">jsF short tags</a> to dynamicaly replace the values. Email template can be changed from <a target="_blank" href="%s">here</a>.','jsForms'),admin_url('admin.php?page=jsForms-field-shortcodes&form_id='.$form['id']),admin_url('admin.php?page=jsForms-settings&tab=notifications&type=note_to_user')); ?>
                            </p>
                        </div>
                        <?php if(!empty($options['en_note_user_email'])): ?>

                            <div class="jsF-row">
                                <div class="jsF-control-label jsF-has-child">
                                    <label><input type="checkbox" value='1' name="notify_user"/> <?php _e('Send Email', 'jsForms'); ?></label>
                                </div>
                            </div>

                            <div class="jsF-child-rows clearfix" style="display: none">
                                    <label><?php _e('Recipient(s)', 'jsForms'); ?></label>
                                
                                    <?php 
                                            $recipient=''; 
                                            if(!empty($submission['user'])){
                                                $recipient= $submission['user']['user_email'];
                                            }
                                            else if(!empty($submission['primary_field_val'])){
                                                $recipient=$submission['primary_field_val'];
                                            }
                                    ?>
                                    <input class="jsF-input-field" type="text" value="<?php echo esc_attr($recipient); ?>"  name="note_recipients" />
                                    <p class="decsription"><?php _e('Multiple emails can be given using comma(,) sepration.') ?></p> 
                            </div>

                            <div class="jsF-row">
                                <div class="jsF-control-label">
                                    <label><input type="checkbox" value='1' name="save_note" checked/> <?php _e('Save', 'jsForms'); ?></label>
                                    <p class="description"><?php _e('Uncheck if you do not want to save this note. Useful if only email has to be sent.') ?></p>
                                </div>
                            </div>

                        <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <input type="submit" class="button button-primary" value="<?php _e('Save', 'jsForms'); ?>" />
                    </div>
                </form>
            </div>
        </div>


        <?php if (is_array($submissions) && !empty($submissions)): ?>
            <hr class="jsF-divider">
            <div class="jsF-history-submissions">
                <h1><?php _e('Other Submissions', 'jsForms'); ?></h1>
                <?php
                foreach ($submissions as $temp_sub) {
                    jsForms_admin_submission_table($temp_sub);
                }
                ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<script>
    jQuery(document).ready(function () {
        $ = jQuery;
        var sanitized_tags = <?php echo json_encode($sanitized_tags); ?>;
        if (!$.isEmptyObject(sanitized_tags)) {
            $.each(sanitized_tags, function (name, color) {
                $('.jsF-label-' + name).attr('style', 'background-color:' + color);
            });
        }
        /*
         * Submission tag related
         */
        $(document).on('click', function (e) {
            if ($(e.target).closest(".jsF-label-search").length === 0) {
                $('.jsF-label-list').css('display','none');
            }else{
                $('.jsF-label-list').css('display','block');
            }
        });
        $('.jsF-label-search input').keyup(function(){
            $('.jsF-label-list .jsF-assign-label').hide();
            $('.jsF-label-list .jsF-assign-label:contains("'+$(this).val()+'")').show();
        });
        
        $('.jsF-assign-label').on('click', function (e) {
            var data = {
                'action': 'jsF_assign_label',
                'name': $(this).text(),
                'sub_id': <?php echo $submission['id']; ?>
            };
            $.post(ajaxurl, data, function (response) {
                if (response.success) {
                    location.reload();
                }else{
                    alert('<?php _e('Unable to connect to server.', 'jsForms'); ?>');
                }
            });
        });
        
        $('.jsF-remove-label').on('click', function (e) {
            var data = {
                'action': 'jsF_remove_sub_label',
                'name': $(this).attr('data-val'),
                'sub_id': <?php echo $submission['id']; ?>
            };
            $.post(ajaxurl, data, function (response) {
                if (response.success) {
                    location.reload();
                }else{
                    alert('<?php _e('Unable to connect to server.', 'jsForms'); ?>');
                }
            });
        });

    });
</script>
