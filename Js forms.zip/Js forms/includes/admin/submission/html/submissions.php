<?php 
    $form_id = isset($_GET['jsForm_id']) ? absint($_GET['jsForm_id']) : 0;
    $form= false;
    if(empty($form_id)){
        $forms = jsForms()->form->get('',array('orderby'=>'ID','order'=>'DESC'));
        if(!empty($forms)){
            $form = jsForms()->form->get_form($forms[0]->ID);
        }
    }
    else
        $form = jsForms()->form->get_form($form_id);
        
?>
<div class="jsF-wrapper wrap">
    <div id="jsForms-submission" class="jsForms-admin-wrap">
        <div class="jsF-page-title">
            <h1 class="page-title">
                <?php _e('Submissions Overview', 'jsForms'); ?>
                <a href="javascript:void(0)" id="jsF_submissions_change_columns" class="alignright"><span class="dashicons dashicons-admin-generic"></span></a>
            </h1>
           
            
        </div>
        <?php
        $submisson_table = new jsForms_Submission_Table;
        $submisson_table->prepare_items();
        ?>

        <div class="jsForms-admin-content">
                     </div>
            <form id="jsForms_submission_table" method="get" action="<?php echo esc_attr(admin_url('admin.php?page=jsForms-submission')); ?>">
                <input type="hidden" name="page" value="jsForms-submissions" />
                <?php $submisson_table->views(); ?>
                <?php $submisson_table->display(); ?>
            </form>
        </div>
    </div>
</div>

<?php if(!empty($form)): ?>
    <div id="jsF_change_subs_cols_dialog" class="jsF_dialog" style="display: none;">
        <div class="modal-dialog">    
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php _e('Change Columns','jsForms'); ?></h5>
                    <button type="button" class="close jsF_close_dialog">
                        <span>×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="">
                        <span><?php _e('Select Columns','jsForms'); ?></span>
                        <select id="jsF_sub_columns" multiple="" class="jsF-input-field">
                            <?php if(!empty($form['enable_unique_id'])): ?>
                                <option <?php echo in_array('unique_id',$form['sub_columns']) ? 'selected' : ''; ?> value="unique_id"><?php _e('Unique ID','jsForms'); ?></option>
                            <?php endif; ?>
                            <?php 
                                $fields= jsForms_get_form_input_fields($form['id']); 
                                foreach($fields as $field):
                            ?>
                            <option <?php echo in_array($field['name'],$form['sub_columns']) ? 'selected' : ''; ?> value="<?php echo esc_attr($field['name']); ?>"><?php echo $field['label']; ?></option>
                            <?php endforeach; ?>
                        </select>
                        <span><a href="javascript:void(0)" id="jsF_clear_sub_columns" class="button"><?php _e('Clear','jsForms'); ?></a></span>
                    </div>
                    
                </div>
                <div class="modal-footer">
                    <button type="button" id="jsF_change_sub_cols_btn" data-form-id="<?php echo esc_attr($form['id']); ?>" class="button button-primary"><?php _e('Save','jsForms'); ?></button>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- Labels -->
<?php 
    $labels= jsForms()->label->get_labels();
    if(!empty($labels)):
?>
<div class="jsF-legends wrap">
    <div class="jsF-legends-heading">
        <?php _e('Legends','jsForms'); ?></div>
    <div class="jsF-legends-wrap flex-s-e">
        <?php foreach($labels as $label): ?>
                <div class="jsF-legend"><span style="background-color: #<?php echo $label['color']; ?>">&nbsp;</span><?php echo $label['name']; ?></div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<?php $sanitized_tags= jsForms()->label->get_tags(true); ?>
<script>
    jQuery(document).ready(function(){
        $= jQuery;
        var sanitized_tags= <?php echo json_encode($sanitized_tags); ?>;
        if(!$.isEmptyObject(sanitized_tags)){
            $.each(sanitized_tags, function(name,color) {
               $('.jsF-label-' + name).attr('style','background-color:' + color);
            });
        }
        
        $("#jsForms_submission_table").submit(function(event){
            var text_helpers = jsF_admin_data.text_helpers;
            var action = $(this).find('#bulk-action-selector-top').val();
            if(action==='delete'){
                var selected_sub = [];
                $(this).find(".jsF-sub-cb:checked").each(function(){
                    selected_sub.push($(this).val());
                });
                if(selected_sub.length>0){
                    if(confirm(text_helpers.sub_del_prompt)){
                        return true;
                    }
                    event.preventDefault();
                }
            }
        });
    });
</script>    