<?php 
    wp_enqueue_script('jquery');
    wp_enqueue_script('jsF-util-functions', jsFORMS_PLUGIN_URL . 'assets/js/utility-functions.js');
    wp_enqueue_script ('jsF-admin' ,jsFORMS_PLUGIN_URL.'assets/admin/js/admin.js'); 

    wp_enqueue_style('jsF-admin-style');
?>
<script type="text/javascript">
    jQuery(document).ready(function () {

        var deactivationLink;
        // Shows feedback dialog     
        jQuery('#the-list').find('[data-slug="easy-registration-forms"] span.deactivate a').click(function (event) {
            deactivationLink= jQuery(this).attr('href');
            jQuery("#jsF_uninstall_feedback_dialog").show();
            event.preventDefault();
        });

        jQuery(".jsF-submit-btn").click(function () {
            var selectedVal= jQuery('[name=jsF_feedback_key]:checked').val();
            if(!selectedVal)
            {
                location.href= deactivationLink;
                return;
            }
            var message= '';
            var messageElement= jQuery('#jsF_' + selectedVal);
            switch(selectedVal){
                case 'plugin_broke_site': message= 'Plugin broke my site. <br> Reason :'; if(messageElement.length>0) { message= message + messageElement.val();} break;
                case 'feature_not_available':  message= messageElement.length>0 ? 'Feature not available. <br>' + messageElement.val() : 'Feature not available'; break;
                case 'different_plugin': message= messageElement.length>0 ? 'Different Plugin. <br> Plugin Name :' + messageElement.val() : 'Different Plugin '; break;
                case 'other':message= messageElement.length>0 ? 'Other. <br> Reason :' + messageElement.val() : 'Other :'; break; 
            }
            
            var data = {
                'action': 'jsF_send_uninstall_feedback',
                'msg': message

            };
            jQuery(this).addClass('jsF-progress');
            jQuery.post(ajaxurl, data, function (response) {
                location.href= deactivationLink;
            });
            
        });

        jQuery(".jsF-cancel-button,.jsF-modal-close").click(function () {
            jQuery("#jsF_uninstall_feedback_dialog").hide();
        });

        // Show hide child parent options
        jQuery('.jsF-child-rows').slideUp();
        
        jQuery('.jsF-dialog-input').change(function(){
            jQuery('.jsF-child-rows').hide();
            if(jQuery(this).is(':checked')){
                var child= jQuery(this).data('child-row');
                jQuery('#' + child).slideDown();
            }
        });
    });




</script>
<div id="jsF_uninstall_feedback_dialog" class="jsF_dialog" style="display:none;">

    <div class="modal-content">
        <div class="modal-header"><h5><?php _e('JS Forms Feedback','jsForms'); ?></h5>
            <button type="button" class="close jsF_close_dialog">
                <span>×</span>
            </button>
        </div>


        <div class="modal-body">
            <div class="jsF-content-row jsF-content-heading">
                If you have a moment, please share why you are deactivating JS Forms
            </div>

            <div class="jsF-row jsF-content-row">    
                <div class="jsF-control">
                    <input data-child-row="jsF_feedback_broken" id="jsF_fb_key_broke" class="jsF-dialog-input" type="radio" name="jsF_feedback_key" value="plugin_broke_site">
                    <label for="jsF_fb_key_broke" class="jsF-dialog-label">Plugin broke my Site.</label>
                </div>
            </div>

            <div class="jsF-child-rows"  id="jsF_feedback_broken">
                <div class="jsF-row">
                    <input class="jsF-input-field" type="text" id="jsF_plugin_broke_site" name="jsF_plugin_broke_site" placeholder="Issue Details">
                    <p class="description"><b>Apologies for the inconveineince caused. We request you to send the details <a href="mail:jexclusive23@gmail.com" target="_blank">here</a>, We will get back to you at the earliest.</b></p>
                </div>
            </div>

            <div class="jsF-row jsF-content-row">    
                <div class="jsF-control">
                    <input data-child-row="jsF_feedback_feature" id="jsF_fb_key_na" class="jsF-dialog-input" type="radio" name="jsF_feedback_key" value="feature_not_available">
                    <label for='jsF_fb_key_na' class="jsF-dialog-label">Doesn't have the feature I need</label>
                </div>
            </div>

            <div class="jsF-child-rows" id="jsF_feedback_feature">
                <div class="jsF-row">
                    <input class="jsF-input-field" type="text" id="jsF_feature_not_available" name="jsF_feature_not_available" placeholder="Please let us know the missing feature...">
                </div>
            </div>

            <div class="jsF-row jsF-content-row">    
                <div class="jsF-control">
                    <input data-child-row="jsF_feedback_plugin" id="jsF_fb_key_diferent" class="jsF-dialog-input" type="radio" name="jsF_feedback_key" value="different_plugin">
                    <label for="jsF_fb_key_diferent" class="jsF-dialog-label">Moved to a different plugin.</label>
                </div>
            </div>

            <div class="jsF-child-rows" id="jsF_feedback_plugin">
                <div class="jsF-row">
                    <input class="jsF-input-field" type="text" id="jsF_different_plugin" name="jsF_different_plugin" placeholder="<?php _e('Plugin Name', 'jsForms'); ?>">
                </div>
            </div>

            <div class="jsF-row jsF-content-row">    
                <div class="jsF-control">
                    <input data-child-row="jsF_feedback_other" id="jsF_fb_key_other" class="jsF-dialog-input" type="radio" name="jsF_feedback_key" value="other">
                    <label for="jsF_fb_key_other" class="jsF-dialog-label"><?php _e('Other', 'jsForms'); ?></label>
                </div>
            </div>

            <div class="jsF-child-rows" id="jsF_feedback_other">
                <div class="jsF-row">
                    <input class="jsF-input-field" type="text" id="jsF_other" name="jsF_other" placeholder="<?php _e('Reason', 'jsForms'); ?>">
                </div>
            </div>

        </div>
        <div class="modal-footer">
            <div class="jsF-modal-button-wrap">
                <button type="button" class="jsF-cancel-button button button-danger" role="button">
                    <span class="jsF-modal-button-text"><?php _e('Cancel', 'jsForms'); ?></span>
                </button>
                <button type="button" class="jsF-submit-btn button button-primary" role="button">
                    <span class="jsF-modal-button-text"><?php _e('Submit', 'jsForms'); ?></span>
                </button>
            </div>
        </div>

    </div>
</div>
