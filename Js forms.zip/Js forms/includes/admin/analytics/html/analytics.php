<div class="jsf-wrapper wrap">
    <div class="jsf-page-title">
        <h1 class="wp-heading-inline"><?php _e('Analytics', 'jsforms') ?></h1>
    </div>
    <div class="jsf_analytics_wrap jsforms-admin-content">
        <div class="jsf_chart_filters">
            <form id="jsf_analytics_form" method="get">
                 <input type="hidden" name="page" value="jsforms-analytics" />
                <?php echo jsforms()->form->get_posts_dropdown(array('name'=>'form_id','selected'=>$form_id)); ?>

                <select name="period">
                    <option <?php echo $period=='7' ? 'selected' : ''; ?> value="7"><?php _e('Last 7 Days','jsforms'); ?></option>
                    <option <?php echo $period=='30' ? 'selected' : ''; ?> value="30"><?php _e('Last 30 Days','jsforms'); ?></option>
                    <option <?php echo $period=='60' ? 'selected' : ''; ?> value="60"><?php _e('Last 60 Days','jsforms'); ?></option>
					<option <?php echo $period=='90' ? 'selected' : ''; ?> value="90"><?php _e('Last 0 Days','jsforms'); ?></option>
					<option <?php echo $period=='120' ? 'selected' : ''; ?> value="120"><?php _e('Last 120 Days','jsforms'); ?></option>
                </select>



            </form>    

        </div>
        <div id="jsf_analytics_chart_container">
            <?php if(empty($chart_data)) : ?>
                <div class="jsf_empty"><?php _e('No Data Available.','jsforms'); ?></div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php if(!empty($chart_data)): ?>
    <script>
        function jsf_draw_form_chart(){
            var data = google.visualization.arrayToDataTable([<?php echo $chart_data;  ?>]);

                var options = {
                  title: 'Submissions',
                  curveType: 'function',
                  legend: { position: 'bottom' }
                };



            // Instantiate and draw our chart, passing in some options.
            var chart = new google.visualization.LineChart(document.getElementById('jsf_analytics_chart_container'));
            chart.draw(data,options);

            }

            jQuery(document).ready(function(){
                if(typeof google != 'undefined'){
                    google.charts.load('current', {'packages': ['corechart', 'bar']});
                    if (typeof jsf_draw_form_chart == 'function'){
                        google.charts.setOnLoadCallback(jsf_draw_form_chart);
                    }
                } 
                
                jQuery('#jsf_analytics_form :input').change(function(){
                   jQuery('#jsf_analytics_form').submit();
                });
        });
    </script>   
<?php endif; ?> 
    
    <script>
        jQuery(document).ready(function(){
            jQuery('#jsf_analytics_form :input').change(function(){
                   jQuery('#jsf_analytics_form').submit();
            });
        });
    </script>    