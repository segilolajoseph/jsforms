<div id="jsForms-overview" class="wrap jsForms-admin-wrap jsForms-overview jsF-wrapper jsF-wrapper-bg">
    <?php
        $form_cards = new jsForms_Form_Cards;
        $form_cards->prepare_items();
    ?>
       
    <?php if(isset($options['consent_allowed']) && $options['consent_allowed']==2): ?>
    <div class="updated settings-error notice is-dismissible">
        <form method="post">
  
        </form>
    </div>
    <?php endif; ?>
    <form id="jsForms-overview-table" method="get" action="<?php echo admin_url('admin.php?page=jsForms-overview'); ?>">
        <div class="jsF-page-title">
            <h1 class="wp-heading clearfix">
                <?php _e('Created Forms', 'jsForms'); ?>
                <div class="jsF-search-form">
                    <?php $search = isset($_GET['filter_key']) ? esc_attr(urldecode(wp_unslash($_GET['filter_key']))) : ''; ?>
                    <label><input class="jsF-input-field" type="text" value="<?php echo esc_attr($search); ?>" name="filter_key" placeholder="<?php _e('Search Form','jsForms'); ?>"></label>
                </div>
            </h1>
        </div>
        <input type="hidden" name="page" value="jsForms-overview" />
        <input type="submit" style="display:none"/>
    </form>    
    <div class="jsForms-admin-content">
        <div class="jsF-card-wrap">
            <?php $form_cards->views(); ?>
            <?php $form_cards->display(); ?>
        </div>
    </div>

</div>



<div id="jsF_overview_add_form_dialog" class="jsF_dialog" style="display: none;">
    <div class="modal-dialog">    
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php _e('NEW FORM','jsForms'); ?></h5>
                <button type="button" class="close jsF_close_dialog">
                    <span>×</span>
                </button>
            </div>

            <div class="modal-body">
                <div class="jsF-form-name">
                    <?php _e('Name','jsForms'); ?>
                    <input type="text" id="jsF_overview_input_form_name" class="jsF-input-field"/></div>
                <div id="jsF_overview_add_form_response"></div>
                <div class="jsF-ajax-progress" style="display:none"></div>

                <div class="jsF-form-type">
                    <div class="jsF-form-type-head">
                        <input value="reg" type="radio" name="jsF_overview_input_form_type" id="registration-form" checked/>
                        <label for="registration-form"><?php _e('Registration Form','jsForms'); ?></label>
                    </div>
                </div>
                <?php do_action('jsF_form_type'); ?>
                <div class="jsF-form-type">
                    <div class="jsF-form-type-head">
                        <input type="radio" name="jsF_overview_input_form_type" value="contact" id="contact-form"/>
                        <label for="contact-form"><?php _e('Contact Form','jsForms'); ?></label> 
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <input type="button" id="jsF_overview_add_form_btn" class="button button-primary" value="<?php _e('Save','jsForms'); ?>" />
            </div>
        </div>
    </div>
</div>


<div id="jsF_overview_delete_form_dialog" class="jsF_dialog" style="display: none;">
    <div class="modal-content">
        <div class="modal-header">
            <h5><?php _e('Are you sure you want to delete?','jsForms'); ?></h5>
            <button type="button" class="close jsF_close_dialog">
                <span>×</span>
            </button>
        </div>
        <div class="modal-body">
            <?php _e('All submissions will be deleted.','jsForms'); ?>
        </div>
        <div class="modal-footer">
            <input type="button" class="button button-primary jsF-close-btn" value="<?php _e('Close','jsForms'); ?>" />
            <input type="button" class="button button-danger jsF-confirm-btn" value="<?php _e('Confirm','jsForms'); ?>" />
        </div>                                
    </div>
</div>


<script>
    window.addEventListener('click', function(e){ 
        $=jQuery;
        var target= $(e.target);
        if(!target.hasClass('menu-icon')){
            $('.jsF-card-actions').addClass('jsForm-hidden');
        }
    });
</script>    