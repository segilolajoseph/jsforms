<?php
/**
 * Generates card view for Form Manager page
 *
 * @package    jsForms
 * @author     jsForms
 * @since      1.0.0
*/
class jsForms_Form_Cards extends jsForms_List_Cards {

	/**
	 * Number of forms to show per page.
	 *
	 * @since 1.0.0
	 */
	public $per_page;

	/**
	 * Primary class constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {

		// Bring globals into scope for parent.
		global $status, $page;

		// Utilize the parent constructor to build the main class properties.
		parent::__construct(
			array(
				'singular' => 'form',
				'plural'   => 'forms',
				'ajax'     => false,
			)
		);

		// Default number of forms to show per page
		$this->per_page = apply_filters( 'jsForms_overview_per_page', 10 );
	}

	/**
	 * Render the checkbox column.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_Post $form
	 *
	 * @return string
	 */
	public function column_cb( $form ) {
		return '<input type="checkbox" name="form_id[]" value="' . absint( $form->ID ) . '" />';
	}

	/**
	 * Message to be displayed when there are no forms.
	 *
	 * @since 1.0.0
	 */
	public function no_items() {
		printf( __( 'Whoops, you haven\'t created a form yet.', 'jsForms' ), admin_url( 'admin.php?page=jsForms-dashboard' ) );
	}

	/**
	 * Fetch and setup the final data
	 *
	 * @since 1.0.0
	 */
	public function prepare_items() {
                $_SERVER['REQUEST_URI'] = remove_query_arg( '_wp_http_referer', $_SERVER['REQUEST_URI'] );
		
                $this->process_bulk_actions();

		// Define which columns can be sorted - form name, date
		$sortable = array(
			'form_name' => array( 'title', false ),
			'created'   => array( 'date', false ),
		);
                $search = isset($_GET['filter_key']) ? sanitize_text_field(urldecode(wp_unslash($_GET['filter_key']))) : '';
		// Get forms
		
		$page     = $this->get_pagenum();
		$order    = isset( $_GET['order'] ) ? sanitize_text_field(wp_unslash($_GET['order'])) : 'DESC';
		$orderby  = isset( $_GET['orderby'] ) ? sanitize_text_field(wp_unslash($_GET['orderby'])) : 'ID';
		$per_page = $this->get_items_per_page( 'jsForms_forms_per_page', $this->per_page );
                $post_query= array(
                                                        'orderby'        => $orderby,
                                                        'order'          => $order,
                                                        'nopaging'       => false,
                                                        'posts_per_page' => $per_page,
                                                        'paged'          => $page,
                                                        'no_found_rows'  => false,
                                                        's'=>$search,
                              );
                
		$data     = jsForms()->form->get('',$post_query);
                
                // Fetch total forms
                unset($post_query['posts_per_page']);
                $post_query['nopaging']= true;
                $total_data = jsForms()->form->get('',$post_query);
                $total    = count($total_data);
                
		// Giddy up
		$this->items = $data;

		// Finalize pagination
		$this->set_pagination_args(
			array(
				'total_items' => $total,
				'per_page'    => $per_page,
				'total_pages' => ceil( $total / $per_page ),
			)
		);
	}
        
        public function before_first_card(){
            echo '<div class="jsF-form-card-wrap jsF-add-form-card">
                            <div class="jsF-form-card"><div class="jsF-card-content">
                            	<a href="javascript:void(0)" id="jsF_overview_add_form"><span class="dashicons dashicons-plus"></span></a>
                            	<span class="jsF-add-pop">' . __('Add New Form','jsForms') .'</span>

                  </div></div></div>';
        }
        
        public function card_actions($form){
                $options= jsForms()->options->get_options();
		$out = '<a href="javascript:void(0)" class="jsF-card-menu jsF-form-card-menu" id="jsF-card-menu"><span class="menu-icon"></span></a>';
                $out .= '<ul class="jsF-card-actions jsForm-hidden">';
                $out .= '<li class="jsF-action"><a href="'.admin_url('/admin.php?page=jsForms-dashboard&form_id='.$form->ID.'&tab=build').'"><img src="'.jsFORMS_PLUGIN_URL.'/assets/admin/images/edit-card.png"><span>'.__('Fields','jsForms').'</span></a></li>';
                $out .= '<li class="jsF-action"><a href="'.admin_url('/admin.php?page=jsForms-dashboard&form_id='.$form->ID).'"><img  src="'.jsFORMS_PLUGIN_URL.'/assets/admin/images/settings-card.png"><span>'.__('Dashboard','jsForms').'</span></a></li>';
                $out .= '<li class="jsF-action"><a target="_blank" href="'.add_query_arg(array('jsForm_id'=>$form->ID),get_permalink($options['preview_page'])).'"><img src="'.jsFORMS_PLUGIN_URL.'/assets/admin/images/preview-card.png"><span>'.__('Preview','jsForms').'</span></a></li>';
                $duplicate_url= wp_nonce_url(
				add_query_arg(
					array(
						'action'  => 'duplicate',
						'form_id' => $form->ID,
					),
					admin_url( 'admin.php?page=jsForms-overview' )
				),
				'jsForms_duplicate_form_nonce'
			);
                $out .= '<li class="jsF-action"><a href="'.$duplicate_url.'"><img src="'.jsFORMS_PLUGIN_URL.'/assets/admin/images/duplicate-card.png"><span>'.__('Duplicate','jsForms').'</span></a></li>';
                $delete_url= wp_nonce_url(
				add_query_arg(
					array(
						'action'  => 'delete',
						'form_id' => $form->ID,
					),
					admin_url( 'admin.php?page=jsForms-overview' )
				),
				'jsForms_delete_form_nonce'
			);
                $out .= '<li class="jsF-action"><a class="jsF_overview_delete_form_btn jsF-delete" data-delete-url="'.$delete_url.'"><img src="'.jsFORMS_PLUGIN_URL.'/assets/admin/images/delete-card.png"><span>'.__('Delete','jsForms').'</span></a></li>';
                
                $out .= '</ul>';
		return $out;
	
        }
        
        
        public function card_body($post){
		$out = '<div class="jsF-card-content">';
                $form= jsForms()->form->get_form($post->ID);
                $out .= '<div class="jsF-form-type-indicator jsF-pop-wrap">';
                  if($form['type']=='reg'){
                    $out .=  '<span class="jsF-form-type-icon dashicons dashicons-admin-users"></span><span class="jsF-pop-title">'. __('Registration Form','jsForms') .'</span>';
                  }else{

                    $out .= '<span class="jsF-form-type-icon dashicons dashicons-smartphone"></span><span class="jsF-pop-title">'. __('Contact Form','jsForms') .'</span>';
                  }
                $out .= '</div>';
                $out .= '<div class="post-title jsF-card-title jsF-pop-wrap"><a href="'.admin_url('/admin.php?page=jsForms-dashboard&form_id='.$post->ID).'" title="' . $post->post_title .'">'.$post->post_title.'</a></div>';
                $shortcode = '[jsForms id="'.$post->ID.'"]';
                $out .= "<div class='jsF-short-code-wrap jsF-pop-wrap'><input type='text' class='jsF-shortcode' value='"."$shortcode"."' readonly><span style='display: none;' class='copy-message'>Copied to Clipboard</span><span class='jsF-pop-title'>" . __('Click to copy','jsForms') ."</span></div>";
                $total= jsForms()->submission->get_submissions_by_form($form['id']);  
                $out .= '<div class="jsF-submission-count"><a href="'.admin_url("/admin.php?page=jsForms-submissions&jsForm_id=".$form['id']).'"> '.count($total).' <span class="jsF-detail-title"><small>'.__('Submissions','jsForms').'</small></span></a></div>';
                $out .= '</div>';
                return $out;
	
        }
        
        public function process_bulk_actions() {

		$ids = isset( $_GET['form_id'] ) ? $_GET['form_id'] : array();
  
		if ( ! is_array( $ids ) ) {
			$ids = array( $ids );
		}

		$ids    = array_map( 'absint', $ids );
		$action = ! empty( $_REQUEST['action'] ) ? sanitize_text_field($_REQUEST['action']) : false;

		if ( empty( $ids ) || empty( $action ) ) {
			return;
		}

		// Delete one or multiple forms - both delete links and bulk actions
		if ( 'delete' === $this->current_action() ) {

			if (
				wp_verify_nonce(wp_unslash($_GET['_wpnonce']), 'bulk-forms' ) ||
				wp_verify_nonce(wp_unslash($_GET['_wpnonce']), 'jsForms_delete_form_nonce' )
			) {
				foreach ( $ids as $id ) {
					jsForms()->form->delete( $id );
				}
				?>
				<div class="notice updated">
					<p>
						<?php
						if ( count( $ids ) === 1 ) {
							_e( 'Form was successfully deleted.', 'jsForms' );
						} else {
							_e( 'Forms were successfully deleted.', 'jsForms' );
						}
						?>
					</p>
				</div>
				<?php
			} else {
				?>
				<div class="notice updated">
					<p>
						<?php _e( 'Security check failed. Please try again.', 'jsForms' ); ?>
					</p>
				</div>
				<?php
			}
		}

		// Duplicate form - currently just delete links (no bulk action at the moment)
		if ( 'duplicate' === $this->current_action() ) {
                        
			if ( wp_verify_nonce(wp_unslash($_GET['_wpnonce']), 'jsForms_duplicate_form_nonce' ) ) {
				foreach ( $ids as $id ) {
					jsForms()->form->duplicate( $id );
				}
				?>
				<div class="notice updated">
					<p>
						<?php
						if ( count( $ids ) === 1 ) {
							_e( 'Form was successfully duplicated.', 'jsForms' );
						} else {
							_e( 'Forms were successfully duplicated.', 'jsForms' );
						}
						?>
					</p>
				</div>
				<?php
			} else {
				?>
				<div class="notice updated">
					<p>
						<?php _e( 'Security check failed. Please try again.', 'jsForms' ); ?>
					</p>
				</div>
				<?php
			}
		}
	}
}

