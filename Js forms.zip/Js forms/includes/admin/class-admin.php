<?php
/**
 * Register menu elements.
 *
 * @package    jsForms
 * @author     jsForms
 * @since      1.0.0
 */
class jsForms_Admin {

	/**
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
            // Let's make some menus.
            add_action('admin_menu',array( $this, 'register_menus' ),9);
            add_action('admin_head', array($this,'admin_head') );
            add_action('admin_footer', array($this,'uninstall_dialog'));
            add_action('admin_enqueue_scripts', array($this,'load_scripts'));
	}
        
        /*
         * Load stuff in admin head for tinymce form add plugin
         */
        public function admin_head(){
            global $pagenow;
            $screen = get_current_screen();
            if(!empty($screen) && ($screen->id == 'post' || $screen->id == 'page')) {
                // check if WYSIWYG is enabled
                if ( get_user_option('rich_editing') == 'true') {
                    add_filter("mce_external_plugins", array($this,'embed_forms_button_js'));
                    add_filter('mce_buttons', array($this,'register_forms_button'));
                }
                $forms= jsForms_get_forms_tinymce();
        ?>
                <script>
                    var jsF_form_names= <?php echo $forms; ?>;
                </script>
        <?php
            }
        }
        
        /*
         * Enqueues JS file as external plugin in TinyMCE
         */
        public function embed_forms_button_js($plugin_array){
            $plugin_array['jsF_forms_button'] = jsFORMS_PLUGIN_URL.'assets/admin/js/tinymce/forms-button.js';
            return $plugin_array;
        }
        
        /*
         * Registers Add Field button in TinyMCE
         */
        function register_forms_button($buttons) {
            array_push($buttons, "jsF_forms_button");
            return $buttons;
        }
        
	/**
	 * Registering menus.
	 *
	 * @since 1.0.0
	 */
	function register_menus() {
                
		$menu_cap = apply_filters( 'jsForms_manage_cap', 'manage_options' );

		// Default Forms top level menu item.
		add_menu_page(
			__( 'jsForms', 'jsForms' ),
			__( 'jsForms', 'jsForms' ),
			$menu_cap,
			'jsForms-overview',
			array( $this, 'admin_page' ),
			'dashicons-feedback',
			apply_filters( 'jsForms_menu_position', '57.7' )
		);

		// All Forms sub menu item.
		add_submenu_page(
			'jsForms-overview',
			__( 'jsForms', 'jsForms' ),
			__( 'All Forms', 'jsForms' ),
			$menu_cap,
			'jsForms-overview',
			array( $this, 'admin_page' )
		);
                
                // Add New sub menu item.
		add_submenu_page(
			null,
			__( 'jsForms Dashboard', 'jsForms' ),
			__( 'Add New', 'jsForms' ),
			$menu_cap,
			'jsForms-dashboard',
			array( $this, 'admin_page' )
		);               

		// Submissions sub menu item.
		add_submenu_page(
			'jsForms-overview',
			__( 'Form Submissions', 'jsForms' ),
			__( 'Submissions', 'jsForms' ),
			$menu_cap,
			'jsForms-submissions',
			array( $this, 'admin_page' )
		);
                
                add_submenu_page(
			'jsForms-submissions',
			__( 'Form Submission', 'jsForms' ),
			__( 'Submission', 'jsForms' ),
			$menu_cap,
			'jsForms-submission',
			array( $this, 'admin_page' )
		);
                
                add_submenu_page(
			'jsForms-overview',
			__( 'Labels', 'jsForms' ),
			__( 'Labels', 'jsForms' ),
			$menu_cap,
			'jsForms-labels',
			array( $this, 'admin_page' )
		);

		// Settings sub menu item.
		add_submenu_page(
			'jsForms-overview',
			__( 'jsForms Settings', 'jsForms' ),
			__( 'Global Settings', 'jsForms' ),
			$menu_cap,
			'jsForms-settings',
			array( $this, 'admin_page' )
		);
                
                // Analytics sub menu item.
		add_submenu_page(
			'jsForms-overview',
			__( 'jsForms Analytics', 'jsForms' ),
			__( 'Analytics', 'jsForms' ),
			$menu_cap,
			'jsForms-analytics',
			array( $this, 'admin_page' )
		);
                
                // Plans sub menu item.
                add_submenu_page(
                        'jsForms-overview',
                        __( 'Plans', 'jsForm' ),
                        __( 'Plans', 'jsForm' ),
                        $menu_cap,
                        'jsForms-plans',
                        array( $this, 'admin_page' )
                );

                add_submenu_page(
                        'jsForms-plans',
                        __( 'Plan', 'jsForm' ),
                        __( 'Plan', 'jsForm' ),
                        $menu_cap,
                        'jsForms-plan',
                        array( $this, 'admin_page' )
                );
                
                add_submenu_page(
                    'jsForms-overview',
                    __( 'jsForms', 'jsForms'),
                    __( 'Form Import/Export', 'jsForms'),
                    $menu_cap,
                    'jsForms-tools',
                    array($this, 'admin_page')
                );
                
                do_action('jsF_admin_menus',$this,$menu_cap);
                add_submenu_page(
			'jsForms-overview',
			__( 'Help', 'jsForms' ),
			__( 'Help', 'jsForms' ),
			$menu_cap,
			'jsForms-field-shortcodes',
			array( $this, 'admin_page' )
		);
                add_submenu_page(
			'jsForms-overview',
			__( 'Extensions', 'jsForms' ),
			__( 'Addons', 'jsForms' ),
			$menu_cap,
			'jsForms-addon',
			array( $this, 'admin_page' )
		);
	}

	/**
	 * Wrapper for the hook to render our custom settings pages.
	 *
	 * @since 1.0.0
	 */
	public function admin_page() {
            if(jsForms_is_admin_page()){
                wp_enqueue_script('jquery');
                wp_enqueue_script('jquery-ui-core');
                wp_enqueue_style ('wp-jquery-ui-dialog');
                wp_enqueue_script('jsF-util-functions');
                wp_enqueue_script ('jsF-admin');         
                wp_enqueue_style('jsF-admin-style');
                do_action( 'jsF_admin_global_enqueues' );
            }
            do_action( 'jsForms_admin_page' );
	}
        
        function load_scripts(){
            wp_register_script('jsF-util-functions', jsFORMS_PLUGIN_URL . 'assets/js/utility-functions.js',array(),jsFORMS_VERSION);
            wp_register_script ('jsF-admin' ,jsFORMS_PLUGIN_URL.'assets/admin/js/admin.js',
                        array('jquery-ui-dialog'),jsFORMS_VERSION);
            wp_register_script('jsF-print-submission', jsFORMS_PLUGIN_URL . 'assets/js/printThis.js',array('jquery'));
            wp_register_style('jsF-admin-style',jsFORMS_PLUGIN_URL.'assets/admin/css/style.css','',jsFORMS_VERSION);
            wp_localize_script('jsF-admin','jsF_admin_data',array('text_helpers'=>jsForms_admin_text_helpers()));
            do_action('jsF_register_admin_scripts');
        }
        
        public function uninstall_dialog(){
            $screen = get_current_screen();
            if(!is_admin() || !isset($screen->id))
                return;

            if (!in_array($screen->id, array('plugins', 'plugins-network' )))
                return;
            
            require_once 'utils/uninstall_dialog.php';
        }

}
new jsForms_Admin;
