<?php
// Enqueue scripts  
wp_enqueue_script('jsf-font-awesome-icon-picker');
wp_enqueue_script('jsf-masked-input');
wp_enqueue_script('vuejs_sortable');
wp_enqueue_script('vuejs_draggable');
wp_enqueue_script('jsf-builder');

// Enqueue Styles
wp_enqueue_style('jsf-font-awesome-css');
wp_enqueue_style('jsf-font-awesome-icon-picker');
wp_enqueue_style('jsf-builder-style');

require('fields/field_option_tags.html');
require('fields/field_tag.html');
?>
<div class="jsf-form-builder-wrapper" id="jsf_fb_app">
    <input type="text" class="jsf-input-field jsf-input-field-title" v-model="title" id="jsforms-form-title" placeholder="<?php echo __('Title', 'jsforms'); ?>" />
    <div class="jsf-feature-request">
        <p class="description jsf-form-code"><?php _e('Paste the following shortcode inside a post or page.', 'jsforms'); ?> <input id="form-code" title="Copy Shortcode" type="text" readonly value='[jsforms id="<?php echo $form_id; ?>"]'> <span style="display:none" id="copy-message"><?php _e('Copied to Clipboard', 'jsforms'); ?></span></p>
    </div>
    
    <div id="jsf_progress" style="display:none"><div class="loader">
            <img src="<?php echo jsfORMS_PLUGIN_URL.'/assets/admin/images/loader.svg' ?>">
        </div></div>
    <div class="jsf-form-builder">
         <div class="jsf-field-type-container">
             <h4 class="jsf-field-heading"><?php _e('Available Fields', 'jsforms'); ?></h4>
        <div class="jsf-field-types">
            <div class="jsf-field-group" @click="showInputFields= !showInputFields" v-bind:class="{ 'jsf-right-arrow': !showInputFields,'jsf-down-arrow':showInputFields }">
                <?php _e('Input Fields','jsforms'); ?>
            </div>
            <vuedraggable  v-if="showInputFields" class="dragArea list-group"
                          :sort="false"
                          :list="inputFields" 
                          :group="{name:'fields',pull:'clone',put:false }"
                          :clone="cloneField">
                <div class="list-group-item jsf-field-type" v-for="field in inputFields" :key="field.key">
                  <a href="javascript:void(0)"><span class="jsf-drag-handle"></span>{{field.label}}</a>
                </div>
            </vuedraggable>
        </div>
         
        <div class="jsf-field-types">
            <div class="jsf-field-group" @click="showDisplayFields= !showDisplayFields" v-bind:class="{ 'jsf-right-arrow': !showDisplayFields,'jsf-down-arrow':showDisplayFields }">
                <?php _e('Display Fields','jsforms'); ?>
                <span></span>
            </div>
            <vuedraggable v-if="showDisplayFields" class="dragArea list-group"
                          :sort="false"
                          :list="displayFields" 
                          :group="{name:'fields',pull:'clone',put:false }"
                          :clone="cloneField">
                <div class="list-group-item jsf-field-type" v-for="field in displayFields" :key="field.key">
                  <a href="javascript:void(0)"><span class="jsf-drag-handle"></span>{{field.label}}</a>
                </div>
            </vuedraggable>
        </div>
             
        <div class="jsf-field-types">
            <div class="jsf-field-group" @click="showFunctionFields= !showFunctionFields" v-bind:class="{ 'jsf-right-arrow': !showFunctionFields,'jsf-down-arrow':showFunctionFields }">
                <?php _e('Function Fields','jsforms'); ?>
                <span></span>
            </div>
            <vuedraggable v-if="showFunctionFields" class="dragArea list-group"
                          :sort="false"
                          :list="functionFields" 
                          :group="{name:'fields',pull:'clone',put:false }"
                          :clone="cloneField">
                <div class="list-group-item jsf-field-type" v-for="field in functionFields" :key="field.key">
                  <a href="javascript:void(0)"><span class="jsf-drag-handle"></span>{{field.label}}</a>
                </div>
            </vuedraggable>
        </div>     
         
         </div>
         
        <div class="jsf-form-fields">
            <vuedraggable 
                draggable=".jsf-field-row" 
                @change="onDragDrop($event)" 
                :disabled="dragDisabled"
                class="dragArea list-group jsf-fields-container"
                :list="fields"
                group="fields">
                <div v-for="field, index in fields" class="jsf-field-row" v-bind:key="field.uniqueID" v-bind:class="{ 'invalid-field': hasErrors(field) }">
                    <jsf_select_field
                        v-if="field.type=='select' || field.type=='radio-group' || field.type=='checkbox-group' || field.type=='state' || field.type=='country'"
                        v-bind:prop-attrs="field" 
                        v-bind:field-index="index" 
                        v-on:label-change="onLabelChange"
                        v-on:update="onUpdate"
                        v-on:option-update="onOptionUpdate"
                        v-on:option-add="onOptionAdd"
                        v-on:edit="onEditField"
                        v-on:duplicate="onDuplicateField"
                        v-on:delete="onDeleteField"
                        v-on:hide-edit="onHideEdit"
                        v-on:option-remove="onOptionRemove">
                    </jsf_select_field>

                    <jsf_field  
                        v-else
                        v-bind:prop-attrs="field" 
                        v-bind:field-index="index"
                        v-on:update="onUpdate"
                        v-on:label-change="onLabelChange"
                        v-on:option-add="onOptionAdd"
                        v-on:edit="onEditField"
                        v-on:duplicate="onDuplicateField"
                        v-on:delete="onDeleteField"
                        v-on:hide-edit="onHideEdit"
                        v-on:option-remove="onOptionRemove">
                    </jsf_field>
                </div>
            </vuedraggable>   
        </div>
     </div>   
    <p class="form_error" v-if="invalidForm"> Errors on the form!!!. Please fix them.</p>
    <p class="submit">
        <input type="button" @click="saveForm()" value="<?php _e('Save', 'jsforms'); ?>" class="button button-primary" id="jsforms-form-save-btn" /> 
        <input type="button" @click="saveForm(true)" value="<?php _e('Close', 'jsforms'); ?>" class="button button-primary" id="jsforms-form-save-close-btn" />
    </p>
</div>
