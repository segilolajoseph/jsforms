<?php
wp_enqueue_style('timepicker');
wp_enqueue_script('timepicker');

$index = isset($_REQUEST['index']) ? absint($_REQUEST['index']) : 0;
$report = null;
if (isset($form['reports'][$index]) && isset($_REQUEST['index'])) {
    $nonce = isset($_REQUEST['nonce']) ? sanitize_text_field($_REQUEST['nonce']) : '';
    if (!wp_verify_nonce($nonce, 'jsF-report-edit-nonce')) {
        die('Invalid security token, Please go tp Reports page and try again.');
    }
    $report = $form['reports'][$index];
}
?>
<div class="jsF-form-report-wrapper">
    <form method="POST" action="<?php echo admin_url('?page=jsForms-dashboard&form_id=' . $form_id . '&tab=reports'); ?>">
        <fieldset>
            <h1><?php _e('Add/Edit Report','jsForms'); ?></h1>
            <div class="jsF-row">
                <div class="jsF-control-label">
                    <label><?php _e('Name', 'jsForms'); ?><sup>*</sup></label>
                </div>
                <div class="jsF-control">
                    <input type="text" class="jsF-input-field" name="name" required value="<?php echo isset($report['name']) ? esc_attr($report['name']) : ''; ?>"/>
                    <p class="description"><?php _e('Report Name.', 'jsForms'); ?></p>
                </div>  
            </div>

            <div class="jsF-row">
                <div class="jsF-control-label">
                    <label><?php _e('Description', 'jsForms'); ?></label>
                </div>
                <div class="jsF-control">
                    <textarea class="jsF-input-field" name="description"><?php echo isset($report['description']) ? esc_textarea($report['description']) : ''; ?></textarea>
                    <p class="description"><?php _e('Report Description.', 'jsForms'); ?></p>
                </div>  
            </div>

            <!-- Sortable Field -->
            <div class="jsForms_sortable_fields-wrap">
                <ul id="jsForms_sortable_fields">
                    <?php
                    $fields = jsForms_get_report_fields($form_id);
                    $form_fields = jsForms()->form->get_fields_dropdown($form_id);
                    $form_field_names = array_keys($form_fields);
                    $df_sub_fields = jsForms_get_default_submission_fields();
                    ?>
                    <?php if (!empty($report) && !empty($report['fields'])): ?>
                        <?php foreach ($report['fields'] as $name => $field): ?>
                            <?php
                            if (isset($form_fields[$name])) {
                                unset($form_fields[$name]);
                            }

                            if (!in_array($name, $form_field_names) && !in_array($name, $df_sub_fields))
                                continue; // Making sure to exclude deleted fields
                            ?>
                            <li class="ui-state-default" id="<?php echo esc_attr($name); ?>">
                                <div class="group-wrap">
                                    <div class="jsF-report-field-label"><div class="field-arrow"><span class="dashicons dashicons-move"></span></div> <?php echo $field['label']; ?></div>

                                    <div class="jsF-report-field-options" style="display:none">
                                        <div class="jsF-row">
                                            <div class="jsF-control-label">
                                                <label><?php _e('Alias', 'jsForms'); ?></label>
                                            </div>
                                            <div class="jsF-control">
                                                <input type="text" class="jsF-input-field" name="<?php echo $name; ?>_alias" value="<?php echo esc_attr($field['alias']); ?>"/>
                                            </div>  
                                        </div>

                                        <div class="jsF-row">
                                            <div class="jsF-control-label">
                                                <label><?php _e('Include in report', 'jsForms'); ?></label>
                                            </div>
                                            <div class="jsF-control">
                                                <input  type="checkbox" name="<?php echo $name; ?>_included" value="1" <?php echo empty($field['included']) ? '' : 'checked'; ?>>
                                            </div>  
                                        </div>
                                    </div>
                                </div>
                            </li>  

                        <?php endforeach; ?>
                    <?php else : ?> 
                        <?php foreach ($fields as $name => $label) : ?>
                            <li class="ui-state-default" id="<?php echo $name; ?>">
                                <div class="group-wrap">
                                    <div class="jsF-report-field-label"><div class="field-arrow"><span class="dashicons dashicons-move"></span></div> <?php echo $label; ?></div>

                                    <div class="jsF-report-field-options" style="display:none">
                                        <div class="jsF-row">
                                            <div class="jsF-control-label">
                                                <label><?php _e('Alias', 'jsForms'); ?></label>
                                            </div>
                                            <div class="jsF-control">
                                                <input type="text" class="jsF-input-field" name="<?php echo $name; ?>_alias" value="<?php echo esc_attr($label); ?>"/>
                                            </div>  
                                        </div>


                                        <div class="jsF-row">
                                            <div class="jsF-control-label">
                                                <label><?php _e('Include in report', 'jsForms'); ?></label>
                                            </div>
                                            <div class="jsF-control">
                                                <input type="checkbox" name="<?php echo $name; ?>_included" value="1" checked>
                                            </div>  
                                        </div>
                                    </div>
                                </div>
                            </li>

                        <?php endforeach; ?>      
                    <?php endif; ?>

                    <?php if (!empty($report)): ?>             
                        <?php foreach ($form_fields as $fn => $fl): //Printing new fields from dropdown ?>  
                            <li class="ui-state-default" id="<?php echo $fn; ?>">
                                <div class="group-wrap">
                                    <div class="jsF-report-field-label"><div class="field-arrow"><span class="dashicons dashicons-move"></span></div> <?php echo $fl; ?></div>

                                    <div class="jsF-report-field-options" style="display:none">
                                        <div class="jsF-row">
                                            <div class="jsF-control-label">
                                                <label><?php _e('Alias', 'jsForms'); ?></label>
                                            </div>
                                            <div class="jsF-control">
                                                <input type="text" class="jsF-input-field" name="<?php echo $fn; ?>_alias" value="<?php echo esc_attr($fl); ?>"/>
                                            </div>  
                                        </div>

                                        <div class="jsF-row">
                                            <div class="jsF-control-label">
                                                <label><?php _e('Include in report', 'jsForms'); ?></label>
                                            </div>
                                            <div class="jsF-control">
                                                <input  type="checkbox" name="<?php echo $fn; ?>_included" value="1">
                                            </div>  
                                        </div>
                                    </div>
                                </div>
                            </li> 
                        <?php endforeach; ?>  
                    <?php endif; ?>               

                </ul>
            </div>
            <!-- Sortable Fields area ends here -->

            <div class="jsF-row">
                <div class="jsF-control-label">
                    <label><?php _e('Receipents', 'jsForms'); ?></label>
                </div>
                <div class="jsF-control">
                    <input type="text" class="jsF-input-field" name="receipents" value="<?php echo isset($report['receipents']) ? $report['receipents'] : ''; ?>"/>
                    <p class="description"><?php echo __('Email where you want to receive the report. Multiple emails can be given using comma(,) sepration. In case this value is empty, system will send the notification to site admin ', 'jsForms') . '(' . get_option('admin_email') . ')'; ?></p>
                </div>  
            </div>

            <div class="jsF-row">
                <div class="jsF-control-label">
                    <label><?php _e('Email Subject', 'jsForms'); ?></label>
                </div>
                <div class="jsF-control">
                    <input type="text" class="jsF-input-field" required name="email_subject" value="<?php echo isset($report['email_subject']) ? esc_attr($report['email_subject']) : $form['title'] . ' Report'; ?>"/>
                    <p class="description"><?php echo __('Subject of the email.', 'jsForms'); ?></p>
                </div>  
            </div>

            <div class="jsF-row">
                <div class="jsF-control-label">
                    <label><?php _e('Email Message', 'jsForms'); ?></label>
                </div>
                <div class="jsF-control">
                    <?php
                    $email_message = isset($report['email_message']) ? $report['email_message'] : 'Please find the attached report.';
                    echo wp_editor($email_message, 'email_message');
                    ?>
                </div>  
            </div>

            <div class="jsF-row">
                <div class="jsF-control-label">
                    <label><?php _e('Status', 'jsForms'); ?></label>
                </div>
                <div class="jsF-control">
                    <select name="active" class="jsF-input-field">
                        <option <?php echo isset($report['active']) && $report['active'] == '1' ? 'selected' : ''; ?> value="1"><?php _e('Active', 'jsForms'); ?></option>
                        <option <?php echo isset($report['active']) && $report['active'] == '0' ? 'selected' : ''; ?> value=""><?php _e('Deactive', 'jsForms'); ?></option>
                    </select>
                    <p class="description"><?php _e('Activate/Deactivate the report. Report will not be sent for Deactivated status.', 'jsForms'); ?></p>
                </div>  
            </div>

            <div class="jsF-row">
                <div class="jsF-control-label">
                    <label><?php _e('Start Date', 'jsForms'); ?><sup>*</sup></label>
                </div>
                <div class="jsF-control">
                    <input required="" id="jsF_report_start_date" value="<?php echo isset($report['start_date']) ? esc_attr($report['start_date']) : ''; ?>" name="start_date" type="text" class="jsF-input-field">
                    <p class="description"><?php _e('The first Date that you want the event to occur.','jsForms'); ?></p>
                </div>  
            </div>
            
            <div class="jsF-row">
                <div class="jsF-control-label">
                    <label><?php _e('Start Time', 'jsForms'); ?><sup>*</sup></label>
                </div>
                <div class="jsF-control">
                    <input value="<?php echo isset($report['time']) ? esc_attr($report['time']) : ''; ?>" id="jsForms_time" required="" name="time" type="text" class="time ui-timepicker-input jsF-input-field" autocomplete="off">
                    <p class="description"><?php _e('The first Time that you want the event to occur.','jsForms'); ?></p>
                </div>  
            </div>
            
            <div class="jsF-row">
                <div class="jsF-control-label">
                    <label><?php _e('Recurrence', 'jsForms'); ?></label>
                </div>
                <div class="jsF-control">
                    <select name="recurrence" class="jsF-input-field">
                        <option <?php echo (isset($report['recurrence']) && $report['recurrence'] == 'twicedaily') ? 'selected' : ''; ?> value="twicedaily"><?php _e('Twice Daily', 'jsForms'); ?></option>
                        <option <?php echo (isset($report['recurrence']) && $report['recurrence'] == 'daily') ? 'selected' : ''; ?> value="daily"><?php _e('Daily', 'jsForms'); ?></option>
                        <option <?php echo (isset($report['recurrence']) && $report['recurrence'] == 'weekly') ? 'selected' : ''; ?> value="weekly"><?php _e('Weekly', 'jsForms'); ?></option>
                        <option <?php echo (isset($report['recurrence']) && $report['recurrence'] == 'monthly') ? 'selected' : ''; ?> value="monthly"><?php _e('Monthly', 'jsForms'); ?></option>
                    </select>
                    <p class="description"><?php _e('How often the report should send.', 'jsForms'); ?></p>
                </div>  
            </div>
            <?php
            $field_names = array();
            if (!empty($report) && !empty($report['fields'])) {
                $field_names = array_keys($report['fields']);
            }
            // jsForms_debug($field_names);
            foreach ($field_names as $name_index => $fn) {
                if (!in_array($fn, $form_field_names) && !in_array($fn, $df_sub_fields)) {
                    unset($field_names[$name_index]);
                }
            }
            // jsForms_debug($field_names); die;
            ?>
            <input type="hidden" name="field_names" id="jsF_field_names" value="<?php echo empty($field_names) ? '' : implode(',', $field_names); ?>" />
            <input type="hidden" name="created" value="<?php echo isset($report['created']) ? $report['created'] : '' ?>" />
            <input type="hidden" name="index" value="<?php echo empty($report) ? -1 : $index; ?>" />
            <input type="hidden" name="jsF_save_report" value="1" />
            <input type="hidden" id="jsF_report_offset" name="time_offset" />
            
            <p class="submit">
                <input type="submit" class="button button-primary" value="<?php _e('Save', 'jsForms'); ?>" name="save" /> 
            </p>
        </fieldset>
    </form>


<?php wp_enqueue_script('jquery-ui-sortable'); ?>
    <script>
        jQuery(document).ready(function () {
            $ = jQuery;

            $('#jsForms_sortable_fields').sortable({
                stop: function (e, ui) {
                    var fieldName = $(this).sortable('toArray', {attribute: 'id'});
                    console.log(fieldName);
                    $('#jsF_field_names').val(fieldName);
                }
            });
            $("#jsForms_sortable_fields").disableSelection();

            // Timepicker
            $('#jsForms_time').timepicker();

            $('.jsF-report-field-label').click(function () {
                var optionsContainer = $(this).next('.jsF-report-field-options');
                optionsContainer.slideToggle();
            });
            
            $('#jsF_report_start_date').datepicker({ dateFormat: 'yy-mm-dd', minDate: new Date()-1});
            $('#jsF_report_offset').val(new Date().getTimezoneOffset()/60);
        });
    </script>
</div>
</div>