<?php
    $active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : '';
    $form_id = isset($_GET['form_id']) ? absint($_GET['form_id']) : 0;
    $form= jsForms()->form->get_form($form_id);
    $options= jsForms()->options->get_options();
    if(empty($form))
        return;
?>
<div class="jsF-wrapper wrap">
    <div class="jsF-page-title">
        <?php
            switch($active_tab){
                case 'build': $title = __('Build', 'jsForms') ; break;
                case 'configure': $title = __('Configure', 'jsForms') ; break;
                case 'report': $title = __('Report', 'jsForms') ; break;
                case 'reports': $title = __('Reports', 'jsForms') ; break;
                case 'notifications': $title = __('Notifications', 'jsForms') ; break;
                default : $title = __('Form Settings', 'jsForms') ;
             }
             $title= apply_filters('jsF_dashboard_tab_title', $title, $active_tab);
            ?> 
        <h1 class="wp-heading-inline">
            <?php echo ucwords($form['title']); ?> - <?php echo $title ?>
        </h1>
            <ul class="jsF-nav">
                    <li class="jsF-nav-item">
                        <a href="?page=jsForms-overview">
                            <img width="24" src="<?php echo jsFORMS_PLUGIN_URL?>assets/admin/images/edit_submission.png">
                            <?php _e('All Forms', 'jsForms'); ?>
                        </a>
                    </li>
                <?php if(!empty($active_tab)): ?>
                    <li class="jsF-nav-item">
                        <a href="?page=jsForms-dashboard&form_id=<?php echo $form_id; ?>">
                            <img width="24" src="<?php echo jsFORMS_PLUGIN_URL?>assets/admin/images/configuration/display-icon.png">
                            <?php _e('Dashboard', 'jsForms'); ?>
                        </a>
                    </li>
                <?php endif; ?>
                <li class="jsF-nav-item">
                    <a target="_blank" href="<?php echo add_query_arg(array('jsForm_id'=>$form_id),get_permalink($options['preview_page'])); ?>">
                        <img width="24" src="<?php echo jsFORMS_PLUGIN_URL?>assets/admin/images/preview-link.png">
                        <?php _e('Preview', 'jsForms'); ?>
                    </a>
                </li>    
            </ul>
        
    </div>
    <div class="jsForms-new-form clearfix">
        <?php if (empty($active_tab)): ?>
            <div class="jsF-form-dashboard">
                <div class="jsF-dashboard-section">
                    <div class="jsF-section-title"><?php _e('Manage','jsForms'); ?></div>
                    <div class="jsF-section-item-container">
                        <div class="jsF-section-item">
                            <a href="?page=jsForms-dashboard&form_id=<?php echo $form_id; ?>&tab=build">
                                <div>
                                    <img title="<?php _e('Create, edit and manage fields.','jsForms'); ?>" src="<?php echo jsFORMS_PLUGIN_URL?>assets/admin/images/manage.png"><span><?php _e('Fields', 'jsForms'); ?></span>
                                </div>
                            </a>
                        </div>
                        <div class="jsF-section-item">
                            <a href="?page=jsForms-submissions&jsForm_id=<?php echo $form_id; ?>">
                                <div>
                                    <img title="<?php _e('Shows list of all the submissions. Allows to filter/export submission records.','jsForms'); ?>" src="<?php echo jsFORMS_PLUGIN_URL?>assets/admin/images/submissions.png"><span><?php _e('Submissions', 'jsForms'); ?></span>
                                </div>
                            </a>
                        </div>

                        <div class="jsF-section-item">
                            <a href="?page=jsForms-dashboard&form_id=<?php echo $form_id; ?>&tab=attachments">
                                <div>
                                    <img title="<?php _e('Enable email notifications. Modify email contents with mail merge feature.','jsForms'); ?>" src="<?php echo jsFORMS_PLUGIN_URL?>assets/admin/images/attachments.png">
                                    <span><?php _e('Attachments', 'jsForms'); ?></span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="jsF-dashboard-section">
                    <div class="jsF-section-title"><?php _e('Configure','jsForms'); ?></div>
                    <div class="jsF-section-item-container">
                        <?php $menus= jsForms_form_configuration_menus($form['type']); ?>
                        <?php foreach($menus as $slug=>$menu): ?>
                        <div class="jsF-section-item">
                            <a href="?page=jsForms-dashboard&form_id=<?php echo $form['id']; ?>&tab=configure&type=<?php echo $slug; ?>">
                                <img title="<?php echo implode(',',$menu['desc']);  ?>" src="<?php echo jsFORMS_PLUGIN_URL?>assets/admin/images/configuration/<?php echo $slug; ?>-icon.png">
                                <span><?php echo $menu['label'];  ?></span>                       
                            </a>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="jsF-dashboard-section">
                    <div class="jsF-section-title"><?php _e('Notifications','jsForms'); ?></div>
                    <div class="jsF-section-item-container">
                        <?php $notifications= jsForms_system_form_notifications($form['type']); ?> 
                        <?php foreach($notifications as $type=>$label): $notification= jsForms_system_form_notification_by_type($type,$form); ?>
                        <div class="jsF-section-item">
                            <a  href="?page=jsForms-dashboard&form_id=<?php echo $form_id; ?>&tab=notifications&type=<?php echo $type; ?>">
                                <img title="<?php echo $notification['help'] ?>" src="<?php echo jsFORMS_PLUGIN_URL?>assets/admin/images/<?php echo $label; ?>.png">
                                <span><?php echo $label; ?></span>    
                            </a>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                
                <div class="jsF-dashboard-section">
                    <div class="jsF-section-title"><?php _e('Reports','jsForms'); ?></div>
                    <div class="jsF-section-item-container">
                        <div class="jsF-section-item">
                            <a  href="?page=jsForms-dashboard&form_id=<?php echo $form_id; ?>&tab=reports">
                                <div><img title="<?php _e("Reports allows you to relay information (Submissions) to interested parties in a periodic manner. You can create multiple reports to share different submitted information with people.For each report, System will generate a CSV file containing the submitted information (which is selected by you) and will send an email to all it's recipients. In short <b>Report</b> allows you to share selected information from the submission to multiple people.",'jsForms'); ?>" src="<?php echo jsFORMS_PLUGIN_URL?>assets/admin/images/scheduled-reports.png">
                                    <span><?php _e('Scheduled Reports', 'jsForms'); ?></span>
                                </div>
                            </a>
                        </div>
                        <div class="jsF-section-item">
                            <a  href="?page=jsForms-analytics&form_id=<?php echo $form_id; ?>">
                                <div><img title="<?php _e("Graph view of submissions over time.",'jsForms'); ?>" src="<?php echo jsFORMS_PLUGIN_URL?>assets/admin/images/analytics.png">
                                      <span><?php _e('Analytics', 'jsForms'); ?></span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="jsF-dashboard-section">
                    <div class="jsF-section-title"><?php _e('Add-ons','jsForms'); ?></div>
                    <div class="jsF-section-item-container"><?php do_action('jsF_dashboard_addons_section', $form, $active_tab); ?></div>
                </div>
            </div>
        <div class="dashboard-sidebar">
            <div class="jsF-sidebar-column-wrap short-code-column">
    <div class="jsF-section-title"><?php _e('Shortcode','jsForms'); ?></div>
    <div class="jsF-section-body">
        <div class='jsF-short-code-wrap jsF-pop-wrap'>
            <?php
            $shortcode = '[jsForms id="'.$form_id.'"]';
            ?>
            <input type='text' class='jsF-shortcode' value='<?php echo $shortcode; ?>' readonly>
            <span style='display: none;' class='copy-message'><?php _e('Copied to Clipboard','jsForms'); ?></span>
        </div>
    </div>
</div>
<div class="jsF-sidebar-column-wrap">
            </div>
        <?php else: ?>
            <?php
                switch($active_tab){
                    case 'build': include('build.php'); break;
                    case 'configure': include('configure.php'); break;
                    case 'report': include('report.php'); break;
                    case 'reports': include('reports.php'); break;
                    case 'notifications': include('notifications.php'); break;
                    case 'attachments': include('attachments.php'); break;
                    case 'submission_attachments': include('submission_attachments.php'); break;
                }
                do_action('jsF_dashboard_tabs', $form, $active_tab);
            ?>    
        <?php endif; ?>
    </div>    
</div>

