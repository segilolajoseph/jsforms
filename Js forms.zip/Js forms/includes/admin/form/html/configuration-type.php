<?php
$auto_login = empty($form['auto_login']) ? '' : 'checked';
$recaptcha_enabled = $form['recaptcha_enabled'];
$auto_user_activation = empty($form['auto_user_activation']) ? '' : 'checked';
$en_role_choices = empty($form['en_role_choices']) ? '' : 'checked';
wp_enqueue_style('timepicker');
wp_enqueue_script('timepicker');
$fields = jsForms()->form->get_fields_dropdown($form['id'], jsForms_non_editable_fields());
?>
<div class="jsF-form-conf-wrapper">
    <form action="" method="post" id="jsF_configuration_form">
        <fieldset class="jsF-config-wrap">

            <!-- General Settings -->
            <div style="<?php echo $type == 'general' ? '' : 'display:none' ?>">
                <div class="group-title">
                    <?php _e('General Settings', 'jsForms'); ?>
                </div>

                <div class="group-wrap">

                    <?php if (!empty($options['recaptcha_configured'])) : ?>
                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Enable Recaptcha', 'jsForms'); ?></label>
                            </div>
                            <div class="jsF-control">
                                <input class="jsF_toggle"  type="checkbox" name="recaptcha_enabled" value="1" <?php echo empty($recaptcha_enabled) ? '' : 'checked'; ?>>
                                <label></label>
                                <p class="description"><?php _e('Shows recaptcha above the submit button. Helps to protect from spam submissions.', 'jsForms'); ?></p>
                            </div>  
                        </div>
                    <?php else : ?>
                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Enable Recaptcha', 'jsForms'); ?></label>
                            </div>
                            <div class="jsF-control">
                                <input class="jsF_toggle"  type="checkbox" disabled="">
                                <label></label>
                                <p class="description"><?php printf(__('Recapctha can not be enabled. Please enable and configure keys from <a target="_blank" href="%s">here</a>.', 'jsForms'),'?page=jsForms-settings&tab=external'); ?></p>
                            </div>  
                        </div>
                    <?php endif; ?>

                    <?php if ($form['type'] == 'reg'): ?>
                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Enable Login Form', 'jsForms'); ?></label>
                            </div>
                            <div class="jsF-control jsF-has-child">
                                <input class="jsF_toggle"  type="checkbox" name="enable_login_form" value="1" <?php echo $form['enable_login_form'] ? 'checked' : '' ?>>
                                <label></label>
                                <p class='description'><?php _e('Shows Login Form.', 'jsForms') ?></p>
                            </div>  
                        </div>
                        <div class="jsF-child-rows" style="<?php echo !empty($form['enable_login_form']) ? '' : 'display:none'; ?>">
                            <div class="jsF-row">
                                    <div class="jsF-control-label">
                                        <label><?php _e('Show Registration Form first', 'jsForms'); ?></label>
                                    </div>
                                    <div class="jsF-control">
                                        <input class="jsF_toggle" id="jsF_show_before_login_form"  type="checkbox" name="show_before_login_form" value="1" <?php echo $form['show_before_login_form'] ? 'checked' : '' ?>>
                                        <label></label>
                                        <p class='description'><?php _e('If enabled Registration Form will be displayed followed by Login Form.', 'jsForms') ?></p>
                                    </div>  
                            </div>
                            
                            <div class="jsF-row">
                                <div class="jsF-control-label">
                                    <label><?php _e('Show both forms together', 'jsForms'); ?></label>
                                </div>
                                <div class="jsF-control jsF-has-child">
                                    <input class="jsF_toggle"  type="checkbox" id="jsF_login_and_register" name="login_and_register" value="1" <?php echo $form['login_and_register'] ? 'checked' : '' ?>>
                                    <label></label>
                                    <p class='description'><?php _e('Displays Login and Registration forms side by side.', 'jsForms') ?></p>
                                </div>  
                            </div>
                            
                        </div>
                    
                    <?php endif; ?>

                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Unique ID', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control jsF-has-child">
                            <input class="jsF_toggle"  type="checkbox" value="1" id="enable_unique_id" name="enable_unique_id" data-has-child="1" <?php echo $form['enable_unique_id'] == '1' ? 'checked' : ''; ?> />
                            <label></label>
                            <p class="description"><?php _e('Generates Unique token for each submission.', 'jsForms') ?></p>
                        </div>  
                    </div>
                    
                    <div class="jsF-child-rows" style="<?php echo !empty($form['enable_unique_id']) ? '' : 'display:none'; ?>">

                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Generation Method', 'jsForms'); ?></label>
                            </div>
                            <div class="jsF-control jsF-has-child">
                                <input type="radio" checked value="auto" name="unique_id_gen_method" data-child-index="-1" <?php echo $form['unique_id_gen_method'] == 'auto' ? 'checked' : '' ?>/> Auto
                                <input type="radio" value="configure" name="unique_id_gen_method"  data-child-index="1" <?php echo $form['unique_id_gen_method'] == 'configure' ? 'checked' : '' ?> /> Configure
                            </div>  
                        </div>

                        <div class="jsF-child-rows jsF-dummy-child">

                        </div>

                        <div class="jsF-child-rows" style="<?php echo $form['unique_id_gen_method']=='configure' ? '' : 'display:none'; ?>">
                            
                            <div class="jsF-row">
                                <div class="jsF-control-label">
                                    <label><?php _e('Current Index', 'jsForms'); ?></label>
                                </div>
                                <div class="jsF-control">
                                    <input class="jsF-input-field" type="number" value="<?php echo esc_attr($form['unique_id_index']); ?>"  name="unique_id_index" />
                                </div>  
                            </div>

                            <div class="jsF-row">
                                <div class="jsF-control-label">
                                    <label><?php _e('Prefix', 'jsForms'); ?></label>
                                </div>
                                <div class="jsF-control">
                                    <input class="jsF-input-field" type="text" value="<?php echo esc_attr($form['unique_id_prefix']); ?>"  min="1" name="unique_id_prefix" />
                                </div>  
                            </div>

                            <div class="jsF-row">
                                <div class="jsF-control-label">
                                    <label><?php _e('Number Padding', 'jsForms'); ?></label>
                                </div>
                                <div class="jsF-control">
                                    <input class="jsF-input-field" type="number" value="<?php echo esc_attr($form['unique_id_padding']); ?>" min="0" name="unique_id_padding" />
                                    <p class="description"><?php _e('If you need your IDs to be of the same length. Leave to 0 if you don\'t want fixed length IDs.','jsForms'); ?></p>
                                </div>  
                            </div>
                            
                            <div class="jsF-row">
                                <div class="jsF-control-label">
                                    <label><?php _e('Number Offset', 'jsForms'); ?></label>
                                </div>
                                <div class="jsF-control">
                                    <input class="jsF-input-field" type="number" value="<?php echo esc_attr($form['unique_id_offset']); ?>" min="0" name="unique_id_offset" />
                                    <p class="description"><?php _e('Sets the interval between consecutive submissions.', 'jsForms') ?></p>
                                </div>  
                            </div>
                            <div class="jsF-feature-request"><p class="description"><?php _e('Looking for help setting up Unique ID, checkout our blog <a target="_blank" href="http://www.easyregistrationforms.com/add-custom-unique-ids-to-your-form-submissions-in-wordpress/">here</a>.', 'jsForms') ?></p></div>
                        </div>

                    </div>
                    
                    <?php if($form['type']=='contact'): ?>
                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Primary Email Field', 'jsForms'); ?></label>
                            </div>
                            <div class="jsF-control">
                                <select name="primary_field" class="jsF-input-field">
                                    <option value=""><?php _e('Select Field','jsForms'); ?></option>
                                    <?php 
                                          $input_fields= jsForms_get_form_input_fields($form['id']); 
                                          foreach($input_fields as $temp_field): 
                                              if($temp_field['type']!='email')
                                                  continue;
                                    ?>
                                            <option value="<?php echo esc_attr($temp_field['name']); ?>" <?php echo $form['primary_field']==$temp_field['name'] ? 'selected' : ''; ?>><?php echo $temp_field['label']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="description"><?php _e('Selected field value will be used as primary contact. Useful when user does not exists in WordPress. Value won\'t be used if user is logged in.', 'jsForms') ?></p>
                            </div>  
                        </div>
                    
                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Primary Contact Name Field', 'jsForms'); ?></label>
                            </div>
                            <div class="jsF-control">
                                <select name="primary_contact_name_field"  class="jsF-input-field">
                                    <option value=""><?php _e('Select Field','jsForms'); ?></option>
                                    <?php foreach($input_fields as $temp_field): ?>
                                            <option value="<?php echo esc_attr($temp_field['name']); ?>" <?php echo $form['primary_contact_name_field']==$temp_field['name'] ? 'selected' : ''; ?>><?php echo $temp_field['label']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="description"><?php _e('Selected field value will be used as contact name in Payment status notifications. Useful when user does not exists in WordPress. Value won\'t be used if user is logged in.', 'jsForms') ?></p>
                            </div>  
                        </div>
                    <?php endif; ?>

                    
                    <?php if (jsForms_show_opt_in()): ?>
                                <div class="jsF-row">
                                    <div class="jsF-control-label">
                                        <label><?php _e('Enable opt-in checkbox', 'jsForms'); ?></label>
                                    </div>
                                    <div class="jsF-control jsF-has-child">.
                                        <input type="checkbox"  class="jsF_toggle" name="opt_in" <?php echo!empty($form['opt_in']) ? 'checked' : ''; ?>/>
                                        <label></label>
                                        <p class="description"><?php _e('Allow users to opt-in for subscription.', 'jsForms'); ?></p>        
                                    </div> 
                                </div>

                                <div class="jsF-child-rows" style="<?php echo !empty($form['opt_in']) ? '' : 'display:none'; ?>">
                                    <div class="jsF-row">
                                        <div class="jsF-control-label">
                                            <label><?php _e('Checkbox Text', 'jsForms'); ?></label>
                                        </div>
                                        <div class="jsF-control">
                                            <input class="jsF-input-field" type="text" name="opt_text" value="<?php echo esc_attr($form['opt_text']); ?>" />
                                            <p class="description"><?php _e('Text will appear with checkbox.', 'jsForms'); ?></p>
                                        </div>  
                                    </div>

                                    <div class="jsF-row">
                                        <div class="jsF-control-label">
                                            <label><?php _e('Default State', 'jsForms'); ?></label>
                                        </div>
                                        <div class="jsF-control">
                                            <input type="radio" name="opt_default_state" value="1" <?php echo!empty($form['opt_default_state']) ? 'checked' : ''; ?>/><?php _e('Checked', 'jsForms'); ?>
                                            <input type="radio" name="opt_default_state" value="0" <?php echo empty($form['opt_default_state']) ? 'checked' : ''; ?>/><?php _e('Unchecked', 'jsForms'); ?>
                                            <p class="description"><?php _e('Default state of the checkbox.', 'jsForms'); ?></p>
                                        </div>  
                                    </div>
                                </div>   
                    <?php endif; ?>
                    
                    <?php do_action('jsF_form_config_user_general'); ?>

                </div>

            </div>

            <div style="<?php echo $type == 'user_account' ? '' : 'display:none' ?>">
                <?php if ($form['type'] == "reg") : ?>
                    <!-- User Account Settings -->
                    <div class="group-title">
                        <?php _e('User Account Settings', 'jsForms'); ?>
                    </div>

                    <div class="group-wrap">
                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Assign User Role', 'jsForms'); ?></label>
                            </div>
                            <div class="jsF-control">
                                <?php $default_role = isset($form['default_role']) ? $form['default_role'] : get_option('default_role'); ?>
                                <select name="default_role" class="jsF-input-field">
                                    <option value=""><?php _e('Inherit from Form', 'jsForms'); ?></option>
                                    <?php wp_dropdown_roles($default_role); ?>
                                </select>
                                <p class='description'><?php _e('User Role that will be assigned to the user after successful registration. If "Inherit from Form" option selected, Form has to provide role information. Role option can be allowed for Radio Group field by enabling "User Role" option.', 'jsForms'); ?></p>
                            </div>  
                        </div>
                        
                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Auto User Activation', 'jsForms'); ?></label>
                            </div>
                            <div class="jsF-control jsF-has-child">
                                <input class="jsF_toggle" type="checkbox" data-has-child="1" name="auto_user_activation" value="1" <?php echo $auto_user_activation; ?>>
                                <label></label>
                                <p class="description"><?php printf(__("Activates user's account after submission. Notifications can be configured from <a target='_blank' href='%s'>here</a>.", 'jsForms'), '?page=jsForms-dashboard&form_id=' . $form_id . '&tab=notifications&type=user_activation'); ?></p>
                            </div>  
                        </div>

                        <div class="jsF-child-rows" style="<?php echo !empty($form['auto_user_activation']) ? '' : 'display:none'; ?>">
                            <div class="jsF-row">
                                <div class="jsF-control-label">
                                    <label><?php _e('Log in', 'jsForms'); ?></label>
                                </div>

                                <div class="jsF-control">
                                    <input class="jsF_toggle" type="checkbox" name="auto_login" value="1" <?php echo $auto_login; ?>>
                                    <label></label>
                                    <p class="description"><?php _e('Logs in user after submission.', 'jsForms'); ?></p>
                                </div>  
                            </div>
                        </div>



                        <div class="jsF-row" id="verification_link">
                            <div class="jsF-control-label">
                                <label><?php _e('Send Verification Link', 'jsForms'); ?></label>
                            </div>
                            <div class="jsF-control jsF-has-child">
                                <input class="jsF_toggle" type="checkbox" data-has-child="1" name="en_email_verification" value="1" <?php echo empty($form['auto_user_activation']) ? '' : 'disabled'; ?> <?php echo!empty($form['en_email_verification']) ? 'checked' : '' ?>>
                                <label></label>
                                <p class="description"><?php printf(__('After successful form submission, user will receive an email with account verification link. Clicking the link will activate the account. Make sure <b>Auto User Activation</b> is disabled. Otherwise it won\'t work. To change the notification content, Please click <a target="_blank" href="%s">here</a>', 'jsForms'), '?page=jsForms-dashboard&form_id=' . $form_id . '&tab=notifications&type=user_verification'); ?></p>
                            </div>  
                        </div>

                        <div class="jsF-child-rows" style="<?php echo !empty($form['en_email_verification']) ? '' : 'display:none'; ?>">
                            <div class="jsF-row">
                                <div class="jsF-control-label">
                                    <label><?php _e('Account Activation Message', 'jsForms'); ?></label>
                                </div>

                                <div class="jsF-control">
                                    <?php
                                    $editor_id = 'user_acc_verification_msg';
                                    $settings = array('editor_class' => 'jsF-editor');
                                    wp_editor($form['user_acc_verification_msg'], $editor_id, $settings);
                                    ?>
                                    <p class="desription"><?php _e('Message will appear on successful account activation. Here you can add any plugin shortcode to show login box or any other elements.', 'jsForms') ?></p>
                                </div>
                            </div>

                            <div class="jsF-row">
                                <div class="jsF-control-label">
                                    <label><?php _e('Account Verification Page', 'jsForms'); ?><sup>*</sup></label>
                                </div>

                                <div class="jsF-control">
                                    <?php wp_dropdown_pages(array('selected' => $form['after_user_ver_page'], 'show_option_none' => 'Select Page', 'option_none_value' => 0, 'name' => 'after_user_ver_page', 'class' => 'jsF-input-field')); ?>
                                    <p class="desription"><?php printf(__("This Page's link will be sent to User for account re-verification. Make sure to add <code>%s</code> shortcode on the selected page.", 'jsForms'), '[jsForms_account_verification]') ?></p>
                                </div>
                            </div>

                            <div class="jsF-row">
                                <div class="jsF-control-label">
                                    <label><?php _e('Auto login after verification', 'jsForms'); ?></label>
                                </div>

                                <div class="jsF-control">
                                    <input class="jsF_toggle" type="checkbox" name="auto_login_after_ver" value="1"  <?php echo!empty($form['auto_login_after_ver']) ? 'checked' : '' ?>>
                                    <label></label>
                                    <p class="desription"><?php _e('Logs in User after successful vjsFication. In case <b>After Login Redirection</b> or <b>Role Based Login Redirection</b> (Under Global Settings) is enabled, User will be directed to corresponding page.', 'jsForms'); ?></p>
                                </div>
                            </div>

                        </div>
                        <?php do_action('jsF_form_config_user_account'); ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Form Restriction Setting -->
            <div style="<?php echo $type == 'restrictions' ? '' : 'display:none' ?>">
                <div class="group-title">
                    <?php _e('Restrictions', 'jsForms'); ?>
                </div>

                <div class="group-wrap">
                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Allowed User Roles', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control">
                            <?php echo jsForms_get_roles_checkbox('access_roles', $form['access_roles']); ?>
                            <p class='description'><?php _e('Only users with above roles will be allowed to view form. By default it will allow all the users.', 'jsForms') ?></p>
                        </div>  
                    </div>

                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Access Denied Note', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control">
                            <textarea class="jsF-input-field" name="access_denied_msg"><?php echo esc_textarea($form['access_denied_msg']); ?></textarea>
                            <p class="description"><?php _e('Users will see this message when they are not allowed to access the form.', 'jsForms') ?></p>
                        </div>  
                    </div>

                    <?php if ($form['type'] == 'reg') : ?>
                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Allow submission from Logged in Users', 'jsForms'); ?></label>
                            </div>
                            <div class="jsF-control">
                                <input class="jsF_toggle"  type="checkbox" name="allow_re_register" value="1" <?php echo $form['allow_re_register'] ? 'checked' : '' ?>>
                                <label></label>
                                <p class='description'><?php _e('If checked form will be visible to logged in users. Helpful in case you want to re-register the users.', 'jsForms') ?></p>
                            </div>  
                        </div>
                    <?php else : ?>
                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Allow only logged in users ', 'jsForms'); ?></label>
                            </div>
                            <div class="jsF-control">
                                <input class="jsF_toggle"  type="checkbox" name="allow_only_registered" value="1" <?php echo $form['allow_only_registered'] ? 'checked' : '' ?>>
                                <label></label>
                                <p class='description'><?php _e('If checked only logged in users will be able to submit the form.', 'jsForms') ?></p>
                            </div>  
                        </div>
                    <?php endif; ?>

                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Password', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control jsF-has-child">
                            <input class="jsF_toggle"  type="checkbox" name="en_pwd_restriction" value="1" <?php echo $form['en_pwd_restriction'] ? 'checked' : ''; ?> />
                            <label></label>
                            <p class='description'><?php _e('System will ask users to enter a password before accessing form.', 'jsForms'); ?>
                        </div>  
                    </div>

                    <div class="jsF-child-rows" style="<?php echo !empty($form['en_pwd_restriction']) ? '' : 'display:none'; ?>">

                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Description', 'jsForms'); ?></label>
                            </div>

                            <div class="jsF-control">
                                <input type="text" class="jsF-input-field" name="pwd_res_description" value="<?php echo esc_attr($form['pwd_res_description']); ?>">
                                <p class="description"><?php _e('Description about the restriction. It will be displayed above the form.', 'jsForms'); ?></p>
                            </div>  
                        </div>

                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Question', 'jsForms'); ?></label>
                            </div>

                            <div class="jsF-control">
                                <input type="text" class="jsF-input-field" name="pwd_res_question" value="<?php echo esc_attr($form['pwd_res_question']); ?>">
                                <p class="description"><?php _e('This question will be asked to user.', 'jsForms'); ?></p>
                            </div>  
                        </div>

                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Password/Answer'); ?></label>
                            </div>

                            <div class="jsF-control">
                                <input type="text" class="jsF-input-field" name="pwd_res_answer" value="<?php echo esc_attr($form['pwd_res_answer']); ?>">
                                <p class="description"><?php _e('Password/Answer that must be given by user to access the form.', 'jsForms'); ?></p>
                            </div>  
                        </div>

                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Error Message'); ?></label>
                            </div>

                            <div class="jsF-control">
                                <input type="text" class="jsF-input-field" name="pwd_res_err" value="<?php echo esc_attr($form['pwd_res_err']); ?>">
                                <p class="description"><?php _e('It will be displayed when user enters wrong password/answer.', 'jsForms'); ?></p>
                            </div>  
                        </div>

                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Enable For Logged in Users'); ?></label>
                            </div>

                            <div class="jsF-control">
                                <input  class="jsF_toggle" type="checkbox" name="pwd_res_en_logged_in" value="1" <?php echo empty($form['pwd_res_en_logged_in']) ? '' : 'checked'; ?>>
                                <label></label>
                                <p class="description"><?php _e('If enabled, Logged in users will have to answer the security question before accessing the form.', 'jsForms'); ?></p>
                            </div>  
                        </div>

                    </div>

                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Limit Submissions', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control jsF-has-child">
                            <input class="jsF_toggle"  type="checkbox" name="enable_limit" data-has-child="1" value="1" <?php echo $form['enable_limit'] ? 'checked' : ''; ?> />
                            <label></label>
                            <p class='description'><?php _e('Removes the form after required number of submissions or a specific date. ', 'jsForms'); ?>
                        </div>  
                    </div>

                    <div class="jsF-child-rows" style="<?php echo !empty($form['enable_limit']) ? '' : 'display:none'; ?>">
                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('By Date/ By Number', 'jsForms'); ?></label>
                            </div>
                            <div class="jsF-control jsF-has-child">
                                <input checked type="radio" name="limit_type" data-has-child="1"  value="date" /> <?php _e('Date', 'jsForms'); ?>
                                <input type="radio" name="limit_type" data-has-child="1" data-child-index="1" value="number" <?php echo $form['limit_type'] == 'number' ? 'checked' : ''; ?>/> <?php _e('Number', 'jsForms'); ?>
                                <input type="radio" name="limit_type" data-has-child="1" data-child-index="0" value="both" <?php echo $form['limit_type'] == 'both' ? 'checked' : ''; ?>/> <?php _e('Both(Whichever is earlier)', 'jsForms'); ?>
                            </div>  
                        </div>

                        <div class="jsF-child-rows" style="<?php echo ($form['limit_type']=='date' || $form['limit_type']=='both') ? '' : 'display:none'; ?>">
                            <div class="jsF-row">
                                <div class="jsF-control-label">
                                    <label><?php _e('Date', 'jsForms'); ?></label>
                                </div>
                                <div class="jsF-control">
                                    <input type="text" class="jsF-input-field" id="jsF_configure_limit_by_date" name="limit_by_date" data-has-child="1" value="<?php echo esc_attr($form['limit_by_date']); ?>" />
                                    <p class="description"><?php _e('Last date on which this form will appear for users.', 'jsForms') ?></p>
                                </div>  
                            </div>
                            
                            <div class="jsF-row">
                                <div class="jsF-control-label">
                                    <label><?php _e('Time', 'jsForms'); ?></label>
                                </div>
                                <div class="jsF-control">
                                    <input value="<?php echo isset($form['limit_time']) ? esc_attr($form['limit_time']) : ''; ?>" id="form_limit_time" name="limit_time" type="text" class="time ui-timepicker-input jsF-input-field" autocomplete="off">
                                </div>  
                            </div>
                        </div>

                        <div class="jsF-child-rows" style="<?php echo ($form['limit_type']=='number' || $form['limit_type']=='both') ? '' : 'display:none'; ?>">
                            <div class="jsF-row">
                                <div class="jsF-control-label">
                                    <label><?php _e('Number of Submissions', 'jsForms'); ?></label>
                                </div>
                                <div class="jsF-control">
                                    <input type="number" class="jsF-input-field" name="limit_by_number" data-has-child="1" value="<?php echo esc_attr($form['limit_by_number']); ?>" />
                                    <p class="description"><?php _e('Form will not be visible after this number is reached.', 'jsForms') ?></p>
                                </div>  
                            </div>
                        </div>

                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Display message', 'jsForms'); ?></label>
                            </div>
                            <div class="jsF-control">
                                <textarea class="jsF-input-field" name="limit_message"><?php echo esc_textarea($form['limit_message']); ?></textarea>
                                <p class="description"><?php _e('This message will be shown when accessing the form after limit expired.', 'jsForms') ?></p>
                            </div>  
                        </div>

                    </div>
                    
                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Disable multiple Submissions','jsForms'); ?></label>
                        </div>

                        <div class="jsF-control jsF-has-child">
                            <input  class="jsF_toggle" type="checkbox" name="dis_mul_sub" value="1" <?php echo empty($form['dis_mul_sub']) ? '' : 'checked'; ?>>
                            <label></label>
                            <p class="description"><?php _e('Restrict multiple submissions from same user.', 'jsForms'); ?></p>
                        </div>  
                    </div>
                    
                    <div class="jsF-child-rows" style="<?php echo !empty($form['dis_mul_sub']) ? '' : 'display:none'; ?>">
                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Message', 'jsForms'); ?></label>
                            </div>
                            <div class="jsF-control">
                                <textarea class="jsF-input-field" name="mul_sub_denial_msg"><?php echo esc_textarea($form['mul_sub_denial_msg']); ?></textarea>
                                <p class="description"><?php _e('Users will see this message if they already have submission(s) on the form.', 'jsForms') ?></p>
                            </div>
                        </div>
                    </div>
                    
                    <?php do_action('jsF_form_config_restrictions'); ?>
                </div>
            </div>
            <!-- Restriction settings ends here -->

            <div style="<?php echo $type == 'plans' ? '' : 'display:none' ?>">
                <?php wp_enqueue_script('jquery-ui-sortable'); ?>
                <!-- Plan Settings -->
                    <div class="group-title">
                        <?php _e('Plan Settings', 'jsForms'); ?>
                    </div>

                    <div class="group-wrap">
                        <?php if (empty($options['payment_methods'])) : ?>
                        <p class="description" style="color:red"><?php printf(__('It appears none of the Payment Method is enabled. Please click <a target="_blank" href="%s">here</a> to configure it.','jsForms'),admin_url('admin.php?page=jsForms-settings&tab=payments')); ?></p>
                        <?php endif; ?>
                        <?php if($form['type']=='contact' && empty($form['primary_field'])): ?>
                            <div class="jsF-warning"><?php printf(__('It is recommended to configure <b>Primary Email</b> field for payment related notifications. You can configure it from <a href="%s" target="_blank">here</a>.','jsForms'),admin_url('admin.php?page=jsForms-dashboard&form_id='.$form['id'].'&tab=configure&type=general')); ?></div>
                        <?php endif; ?>
                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Enable Payment', 'jsForms'); ?></label>
                            </div>
                            <div class="jsF-control jsF-has-child">
                                <input class="jsF_toggle"  type="checkbox" value="1" name="plan_enabled" data-has-child="1" <?php echo $form['plan_enabled'] == "1" ? 'checked' : ''; ?>/>
                                <label></label>
                                <?php if($form['type']=='contact'): ?>
                                    <p class="description"></p>
                                <?php endif; ?>    
                            </div>  
                        </div>


                        <div class="jsF-child-rows" style="<?php echo !empty($form['plan_enabled']) ? '' : 'display:none'; ?>">
                            <div class="jsF-row">
                                <div class="jsF-control-label">
                                    <label><?php _e('Payment header', 'jsForms'); ?></label>
                                </div>
                                <div class="jsF-control">
                                    <input type="text" class="jsF-input-field" name="payment_header" value="<?php echo esc_attr($form['payment_header']); ?>" />
                                    <p class="description"><?php _e('Above text will appear before payment options','jsForms'); ?></p>
                                </div>  
                            </div>
                            
                            <div class="jsF-row">
                                <div class="jsF-control-label">
                                    <label><?php _e('Select Plan(s)', 'jsForms'); ?></label>
                                </div>
                                <div class="jsF-control">
                                    <table class="wp-list-table widefat fixed striped jsF-plans-table">
                                        <thead>
                                            <th></th>
                                            <th><?php _e('Enable','jsForms'); ?></th>
                                            <th><?php _e('Plan Name','jsForms'); ?></th>
                                            <th><?php _e('Type','jsForms'); ?></th>
                                            <th><?php _e('Required','jsForms'); ?></th>
                                        </thead>    
                                        <tbody class="jsF-plan-sortable">
                                            <?php 
                                                // Showing all active plans
                                                foreach($form['plans']['enabled'] as $p_id):
                                                    $plan= jsForms()->plan->get_plan($p_id);
                                                    if(empty($plan))
                                                        continue;
                                            ?>
                                            <tr>
                                                <td><span class="dashicons dashicons-move"></span></td>
                                                <td><input <?php if(isset($form['plans']['enabled']) && in_array($plan['id'],$form['plans']['enabled'])) echo 'checked'; ?> class="jsF_toggle" value="<?php echo $plan['id']; ?>" name="plans[enabled][]" type="checkbox" /><label></label></td>
                                                <td><?php echo $plan['name']; ?></td>
                                                <td><?php echo $plan['type']=='user' ? __('User','jsForms') : __('Product','jsForms'); ?></td>
                                                <td><input <?php if(isset($form['plans']['required']) && in_array($plan['id'],$form['plans']['required'])) echo 'checked'; ?> class="jsF_toggle" value="<?php echo $plan['id']; ?>" name="plans[required][]" type="checkbox" /><label></label></td>
                                            </tr>
                                            <?php endforeach;?>
                                            
                                            <?php 
                                                // Showing disabled plan at once
                                                $plans= jsForms()->plan->get_plans();
                                                foreach($plans as $plan):
                                                    if(in_array($plan['id'],$form['plans']['enabled']))
                                                            continue;
                                            ?>
                                                <tr>
                                                    <td><span class="dashicons dashicons-move"></span></td>
                                                    <td><input <?php if(isset($form['plans']['enabled']) && in_array($plan['id'],$form['plans']['enabled'])) echo 'checked'; ?> class="jsF_toggle" value="<?php echo $plan['id']; ?>" name="plans[enabled][]" type="checkbox" /><label></label></td>
                                                    <td><?php echo $plan['name']; ?></td>
                                                    <td><?php echo $plan['type']=='user' ? __('User','jsForms') : __('Product','jsForms'); ?></td>
                                                    <td><input <?php if(isset($form['plans']['required']) && in_array($plan['id'],$form['plans']['required'])) echo 'checked'; ?> class="jsF_toggle" value="<?php echo $plan['id']; ?>" name="plans[required][]" type="checkbox" /><label></label></td>
                                                    
                                                </tr>
                                            <?php  endforeach; ?>
                                        </tbody>
                                    </table> 
                                    <p class="description"><?php _e('Selected plans are appended in the end of the form. <b>Required</b> plans will appear first and will be followed by other plans.','jsForms'); ?></p>
                                </div>  
                            </div>
                            <div class="jsF-row">
                                <div class="jsF-control-label">
                                    <label><?php _e('Allow single selection', 'jsForms'); ?></label>
                                </div>
                                <div class="jsF-control">
                                    <input class="jsF_toggle" type="checkbox" name="allow_single_plan" value="1" <?php echo!empty($form['allow_single_plan']) ? 'checked' : ''; ?>>
                                    <label></label>
                                    <p class="description"><?php _e('This will group all the required plans and user will be able to choose only one plan out of multiple payment options.') ?></p>
                                </div>
                            </div>    

                        </div>
                                <script>
                                    jQuery(document).ready(function(){
                                        $= jQuery;
                                        $('.jsF-plan-sortable').sortable();
                                    })
                                </script>    
                        <?php do_action('jsF_form_config_plans'); ?>    
                    </div>
            </div>

            <!-- Edit Submission Settings -->
            <div style="<?php echo $type == 'edit_sub' ? '' : 'display:none' ?>">
                <div class="group-wrap">

                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Enable Edit Submission', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control jsF-has-child">
                            <input class="jsF_toggle" type="checkbox" data-has-child="1" name="en_edit_sub" value="1" <?php echo!empty($form['en_edit_sub']) ? 'checked' : ''; ?>>
                            <label></label>
                            <p class="description"><?php _e("This will allow users' to edit/delete their submissions from front end My Account area <code>[jsForms_my_account]</code>", 'jsForms'); ?></p>
                        </div>  
                    </div>

                    <div class="jsF-child-rows" style="<?php echo !empty($form['en_edit_sub']) ? '' : 'display:none'; ?>">
                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Edit', 'jsForms'); ?></label>
                            </div>
                            <div class="jsF-control">
                                <div class="jsF-edit-fields-wrapper">
                                    <?php
                                    $field_names = array_keys($fields);
                                    foreach ($fields as $field_name => $field_label):
                                        ?>
                                        <label class="jsF-form-field">
                                            <input  name="edit_fields[]" type="checkbox" value="<?php echo esc_attr($field_name); ?>" <?php echo in_array($field_name, $form['edit_fields']) ? 'checked' : ''; ?>>

                                            <span><?php echo $field_label; ?></span>
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                                <br>
                                <p class="description"><?php printf(__("Only above selected field's data are allowed to edit. Notifications can be configured <a target='_blank' href='%s'>here</a>", 'jsForms'), '?page=jsForms-dashboard&form_id=' . $form_id . '&tab=notifications&type=edit_submission'); ?></p>
                            </div>  
                        </div>

                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('Delete', 'jsForms'); ?></label>
                            </div>
                            <div class="jsF-control jsF-has-child">
                                <div class="jsF-control">
                                    <input class="jsF_toggle" type="checkbox" data-has-child="1" name="allow_sub_deletion" value="1" <?php echo!empty($form['allow_sub_deletion']) ? 'checked' : ''; ?>>
                                    <label></label>
                                    <p class="description"><?php printf(__("Allows users to delete their submission(s).  Notifications can be configured <a target='_blank' href='%s'>here</a>", 'jsForms'), '?page=jsForms-dashboard&form_id=' . $form_id . '&tab=notifications&type=delete_submission'); ?></p>
                                </div>    

                            </div>  
                        </div>
                    </div>

                    <?php do_action('jsF_form_config_edit_sub'); ?>
                </div>
            </div>
            <!-- Edit Submission ends here -->


            <!-- Form Layout -->
            <div style="<?php echo $type == 'display' ? '' : 'display:none' ?>">
                <div class="group-title">
                    <?php _e('Display Settings', 'jsForms'); ?>
                </div>
                <div class="group-wrap">
                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Form Layout', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control">
                            <select name="layout"  class="jsF-input-field">
                                <option <?php echo $form['layout'] == "one-column" ? 'selected' : ''; ?> value="one-column"><?php _e('One Column', 'jsForms'); ?></option>
                               
                            </select>  
                            <p class="description"><?php printf(__("We recommend you to use Field's width proprty to create multi column view. This option is just for backward compatibility. You can change field's width from the <a href='%s' target='_blank'>Fields</a>.",'jsForms'),admin_url('admin.php?page=jsForms-dashboard&form_id='.$form_id.'&tab=build')); ?></p>
                        </div>  
                    </div>
                    
                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Field Style', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control">
                            <select name="field_style"  class="jsF-input-field">
                                <option <?php echo $form['field_style'] == "flat" ? 'selected' : ''; ?> value="flat"><?php _e('Flat', 'jsForms'); ?></option>
                                <option <?php echo $form['field_style'] == "rounded" ? 'selected' : ''; ?> value="rounded"><?php _e('Rounded', 'jsForms'); ?></option>
                            </select>    
                        </div>  
                    </div>

                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Label Position','jsForms'); ?></label>
                        </div>
                        <div class="jsF-control">
                            <select name="label_position"  class="jsF-input-field">
                                <option <?php echo $form['label_position'] == "top" ? 'selected' : ''; ?> value="top"><?php _e('Top', 'jsForms'); ?></option>
                                <option <?php echo $form['label_position'] == "inline" ? 'selected' : ''; ?> value="inline"><?php _e('Inline', 'jsForms'); ?></option>
                                <option <?php echo $form['label_position'] == "no-label" ? 'selected' : ''; ?> value="no-label"><?php _e('No Label', 'jsForms'); ?></option>
                            </select>    
                        </div>  
                    </div>

                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Content Above The Form', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control">
                            <?php
                            $editor_id = 'before_form';
                            $settings = array('editor_class' => 'jsF-editor');
                            wp_editor($form['before_form'], $editor_id, $settings);
                            ?>
                            <p class="desription">
                                <?php _e('This will be displayed above the form. Inbuilt shortcode:', 'jsForms') ?><br/>
                                <ul>
                                </ul>
                            </p>
                        </div>  
                    </div>
                    <?php do_action('jsF_form_config_display_settings', $form); ?>
                </div>
            </div>


            <!-- User -->
            <div style="<?php echo $type == 'post_sub' ? '' : 'display:none' ?>">
                <div class="group-title">
                    <?php _e('Post Submission', 'jsForms'); ?>
                </div>
                <div class="group-wrap">

                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Redirection', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control">
                            <input type="url" class="jsF-input-field" name="redirect_to" value="<?php echo esc_attr($form['redirect_to']); ?>">
                            <?php if ($form['type'] == 'reg') : ?>
                                <p class='description'><?php _e('URL where the user will be redirected after submission.', 'jsForms'); ?></p>
                            <?php else: ?>
                                <p class='description'><?php _e('URL where the user will be redirected after submission.', 'jsForms'); ?></p>
                            <?php endif; ?>    
                        </div>  
                    </div>

                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Success Message', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control">
                            <?php
                            $editor_id = 'success_msg';
                            $settings = array('editor_class' => 'jsF-editor');
                            wp_editor($form['success_msg'], $editor_id, $settings);
                            ?>
                            <p class="description">
                                <?php printf(__('Content to be displayed after successful submission. Create personalized message using <a href="%s" target="_blank">jsF short tags</a> to dynamicaly replace the values. You can use <code>[jsForms_resend_verification_link label="here"]</code> shortcode to insert <b>Resend Verification</b> link. Make sure to enable notification from <a target="_blank" href="%s">here</a>.','jsForms'),admin_url('admin.php?page=jsForms-field-shortcodes&form_id='.$form['id']),admin_url('admin.php?page=jsForms-dashboard&form_id='.$form['id'].'&tab=notifications&type=user_verification')); ?>
                            </p>
                        </div>  
                    </div>

                    <div class="jsF-row">
                        <div class="jsF-control-label">
                            <label><?php _e('Post to External URL', 'jsForms'); ?></label>
                        </div>
                        <div class="jsF-control jsF-has-child">
                            <input class="jsF_toggle"  type="checkbox" value="1" name="enable_external_url" data-has-child="1" <?php echo $form['enable_external_url'] == '1' ? 'checked' : ''; ?> />
                            <label></label>
                            <p class="description"><?php _e('Posts submission data to external API. Useful for synchronizing submission data on other applications.', 'jsForms') ?></p>
                        </div>  
                    </div>

                    <div class="jsF-child-rows" style="<?php echo !empty($form['enable_external_url']) ? '' : 'display:none'; ?>">
                        <div class="jsF-row">
                            <div class="jsF-control-label">
                                <label><?php _e('URL', 'jsForms'); ?></label>
                            </div>
                            <div class="jsF-control">
                                <input type="text" class="jsF-input-field" name="external_url" value="<?php echo esc_attr($form['external_url']); ?>" />
                                <p class='description'><?php _e('API URL which handles submission data.', 'jsForms'); ?>
                            </div>  
                        </div>
                    </div>

                    <?php do_action('jsF_form_config_post_sub'); ?>
                </div>
            </div>


            <?php do_action('jsF_form_configuration', $form,$type); ?>
        </fieldset>

        <p class="submit">
            <input type="hidden" name="jsF_save_configuration" />
            <input type="submit" class="button button-primary" value="<?php _e('Save', 'jsForms'); ?>" name="save" />
            <input type="submit" value="<?php _e('Save & Close', 'jsForms'); ?>" class="button button-primary" name="savec"/>
        </p>
    </form>  
</div>    

<script>
    jQuery(document).ready(function () {
        $ = jQuery;
        var auto_act = $('[name=auto_user_activation]');
        var email_verification = $('[name=en_email_verification]');
        auto_act.change(function () {
            if ($(this).is(':checked')) {
                email_verification.attr('disabled', 'disabled');
                return;
            }
            email_verification.removeAttr('disabled');
        });
        
        $(document).bind('jsF_parent_row_changed', function (ev, element) {
            if(element.prop('name')=='limit_type' && element.val()=='both'){
                $('.jsF-row [name=limit_by_number]').closest('.jsF-child-rows').slideDown();
            }
        });
        
        $('#form_limit_time').timepicker();
        var show_before_login_form= $('#jsF_show_before_login_form');
        var login_register= $("#jsF_login_and_register");
        login_register.change(function(){
           if($(this).prop("checked")){
               show_before_login_form.prop("checked",false);
           } 
        });
        
        show_before_login_form.change(function(){
            if($(this).prop("checked")){
               login_register.prop("checked",false);
           }
        });
    });
</script>
