<!-- Copy of the My Account template -->
<div class="jsF-container">
    <div class="jsF-my-account clearfix">
        <div class="jsF-my-account-content">

            <!-- My Submissions -->
            <div class="jsF-my-account-profile-tab">
                <div class="jsF-my-account-submissions">
                    <div class="jsF-my-account-titles">   
                        <div class="jsF-my-account-title jsF-my-account-col-sr"><?php _e('#', 'jsForms'); ?></div>
                        <div class="jsF-my-account-title jsF-my-account-col-form-name"><?php _e('Form', 'jsForms'); ?></div>
                        <div class="jsF-my-account-title jsF-my-account-col-date"><?php _e('Date', 'jsForms'); ?></div>
                        <div class="jsF-my-account-title jsF-my-account-col-edit"><?php _e('Action(s)', 'jsForms'); ?></div> 
                    </div>    
                    <div class="jsF-my-account-details-wrap">
                        <?php
                        $sub_id = isset($_GET['sub_id']) ? absint($_GET['sub_id']) : 0;
                        if (!empty($submissions)) {
                            foreach ($submissions as $index => $submission) :
                                $form = jsForms()->form->get_form($submission['form_id']);
                                ?>
                                <div class="jsF-my-account-details">

                                    <div class="jsF-my-account-detail jsF-my-account-col-sr">
                                        <?php echo $index + 1; ?>
                                    </div>
                                    <div class="jsF-my-account-detail jsF-my-account-col-form-name" data-submission-id="<?php echo esc_attr($submission['id']); ?>">
                                        <a data-form-id="<?php echo $form['id']; ?>" data-submission-id="<?php echo esc_attr($submission['id']); ?>" class="jsF-load-submission-row" href="javascript:void(0)"><?php echo $form['title']; ?></a>
                                        <div  style="display:none" class="jsF-modal">
                                            <div class="jsF-submission-info">
                                                <div class="jsF-modal-header">
                                                    <button type="button" class="jsF-modal-close">X</button>
                                                    <?php echo $form['title']; ?>
                                                    <button class="jsF-print-submission"><i class="fa fa-print"></i></button>
                                                </div>
                                                <div class="jsF-modal-body">
                                                </div>
                                            </div>
                                        </div>
                                        <?php if (!empty($sub_id) && $sub_id == $submission['id']): ?>
                                            <div id="jsF_submission_<?php echo $submission['id'] ?>" class="jsF-edit-submission">
                                                <?php echo do_shortcode('[jsForms layout_options="0" id="' . $submission['form_id'] . '"]') ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>

                                    <div class="jsF-my-account-detail jsF-my-account-col-date">
                                        <?php echo $submission['created_date']; ?>
                                    </div>
                                    <div class="jsF-my-account-detail jsF-my-account-col-edit">
                                        <a class="jsF-edit-submission-row <?php echo !jsForms_edit_permission($form,$submission) ? 'jsF-link-disabled' : ''; ?>" data-form-id="<?php echo esc_attr($form['id']); ?>" data-submission-id="<?php echo esc_attr($submission['id']); ?>" href="javascript:void(0)"><?php _e('Edit', 'jsForms');  ?></a>
                                        <a class="jsF-delete-submission-row <?php echo !jsForms_delete_permission($form,$submission) ? 'jsF-link-disabled' : ''; ?>" data-form-id="<?php echo esc_attr($form['id']); ?>" data-submission-id="<?php echo esc_attr($submission['id']); ?>" href="javascript:void(0)"><?php _e('Delete', 'jsForms');  ?></a>
                                         
                                            
                                        <div class="jsF-modal" style="display: none;">
                                            <div class="jsF-modal-header">
                                                <button type="button" class="jsF-modal-close">X</button>
                                                <?php _e('Edit Submission','jsForms') ?>
                                            </div>
                                            <div class="jsF-modal-body jsF-edit-submission-form">
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach;
                        } else { ?>
                            <div class="jsF-message-info">
                                <?php _e('No submission yet.', 'jsForms'); ?>	
                            </div>
                        <?php } ?>
                    </div>
                </div>
                <div class="jsF-account-pagination clearfix">
                    <?php if ($show_prev): ?>
                    <a href="<?php echo home_url(add_query_arg(array('jsF_paged' => $paged - 1), $wp->request)); ?>" class="jsF-pagination jsF-prev"><?php _e('Prev', 'jsForms'); ?></a>
                    <?php endif; ?>

                    <?php if ($show_next): ?>
                        <a href="<?php echo home_url(add_query_arg(array('jsF_paged' => $paged + 1), $wp->request)); ?>" class="jsF-pagination jsF-next"><?php _e('Next', 'jsForms'); ?></a>
                    <?php endif; ?>
                </div>
            </div>
            <!-- Pagination -->
        </div>
    </div>
</div>
