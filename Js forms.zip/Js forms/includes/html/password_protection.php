<div class="jsF-password-protected jsF-container">
    <form method="POST" class="jsF-form">
        <?php if(!empty($form['pwd_res_description'])): ?>
                <div class="jsF-description form-group">
                    <h4><?php echo $form['pwd_res_description']; ?></h4>
                </div>
        <?php endif; ?>
        
        
        <div class="jsF-question form-group">
            <label><?php echo $form['pwd_res_question']; ?></label>
        </div>

         <div class="jsF-answer form-group">
             <input type="text" class="form-control" name="jsF_answer" />
             <input type="hidden" name="jsForm_id" value="<?php echo esc_attr($form['id']); ?>" />
        </div>
        
        <?php if($password_error): ?>
                <div class="jsF-error-row jsF-error form-group">
                    <?php echo $form['pwd_res_err']; ?>
                </div> 
        <?php endif; ?>
        <div class="jsF-submit-button clearfix">   
            <div class="form-group">
                <button type="submit">Submit</button>
            </div>
        </div>
    </form>    
    
</div>