<div class="jsF-container">
    <div class="jsF-my-account clearfix">

        <div class="jsF-my-account-nav">
            <ul class="clearfix">
                <li class="jsF-my-account-navigation-link jsF-my-account-navigation-link-active">
                    <a href="javascript:void(0);" data-tag="profile"><?php _e('Profile', 'jsForms'); ?></a>
                </li>
                <li class="jsF-my-account-navigation-link">
                    <a href="javascript:void(0);" data-tag="submissions"><?php _e('Submissions', 'jsForms'); ?></a>
                </li>
                <li class="jsF-my-account-navigation-link">
                    <a href="javascript:void(0);" data-tag="reset-password"><?php _e('Change Password','jsForms'); ?></a>
                </li>
            </ul>
        </div>
        <div class="jsF-my-account-content">
            <div class="jsF-my-account-profile-tab" id="profile">
                <h3 class="jsF-profile-welcome"><?php echo __('Welcome, ', 'jsForms') . $current_user->display_name; ?></h3>
                <div class="jsF-profile-details-wrap">
                    <div class="jsF-profile-image">
                        <?php echo get_avatar($current_user->ID, 128, '', '', array('class' => 'jsF-avatar')); ?>
                    </div>
                    <div class="jsF-profile-details">

                        <!-- Personal Details -->
                        <div class="jsF-profile-details-row jsF-flex">
                            <div class="jsF-profile-detail-title"><?php _e('Email', 'jsForms'); ?> </div>
                            <div class="jsF-profile-detail-content"><?php echo $current_user->user_email; ?></div>
                        </div>
                        <div class="jsF-profile-details-row jsF-flex">
                            <div class="jsF-profile-detail-title"><?php _e('First Name', 'jsForms'); ?> </div>
                            <div class="jsF-profile-detail-content"><?php echo $current_user->first_name; ?></div>
                        </div>
                        <div class="jsF-profile-details-row jsF-flex">
                            <div class="jsF-profile-detail-title"><?php _e('Last Name', 'jsForms'); ?></div>
                            <div class="jsF-profile-detail-content"><?php echo $current_user->last_name; ?></div>
                        </div>
                        <div class="jsF-profile-details-row jsF-flex">
                            <div class="jsF-profile-detail-title"><?php _e('Bio', 'jsForms'); ?> </div>
                            <div class="jsF-profile-detail-content"><?php echo $current_user->description; ?></div>
                        </div>
                        <div class="jsF-profile-details-row jsF-flex">
                            <div class="jsF-profile-detail-title"><?php _e('Nick Name', 'jsForms'); ?> </div>
                            <div class="jsF-profile-detail-content"><?php echo $current_user->nickname; ?></div>
                        </div>
                        
                        <?php do_action('jsF_my_account_profile'); ?>
                        
                        <div class="jsF-profile-logout">
                            <button onClick="location.href='<?php echo jsForms_logout_url(); ?>'"><?php _e('Logout','jsForms'); ?></button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- My Submissions -->
            <div class="jsF-my-account-profile-tab jsF-hidden" id="submissions">
                <div class="jsF-my-account-submissions">
                    <div class="jsF-my-account-titles">   
                        <div class="jsF-my-account-title jsF-my-account-col-sr"><?php _e('#', 'jsForms'); ?></div>
                        <div class="jsF-my-account-title jsF-my-account-col-form-name"><?php _e('Form', 'jsForms'); ?></div>
                        <div class="jsF-my-account-title jsF-my-account-col-date"><?php _e('Date', 'jsForms'); ?></div>
                        <div class="jsF-my-account-title jsF-my-account-col-edit"><?php _e('Action(s)', 'jsForms'); ?></div> 
                    </div>    
                    <div class="jsF-my-account-details-wrap">
                        <?php
                        $sub_id = isset($_GET['sub_id']) ? absint($_GET['sub_id']) : 0;
                        if (!empty($submissions)) {
                            foreach ($submissions as $index => $submission) :
                                $form = jsForms()->form->get_form($submission['form_id']);
                                ?>
                                <div class="jsF-my-account-details">

                                    <div class="jsF-my-account-detail jsF-my-account-col-sr">
                                        <?php echo $index + 1; ?>
                                    </div>
                                    <div class="jsF-my-account-detail jsF-my-account-col-form-name" data-submission-id="<?php echo esc_attr($submission['id']); ?>">
                                        <a data-form-id="<?php echo $form['id']; ?>" data-submission-id="<?php echo esc_attr($submission['id']); ?>" class="jsF-load-submission-row" href="javascript:void(0)"><?php echo $form['title']; ?></a>
                                        <div  style="display:none" class="jsF-modal">
                                            <div class="jsF-submission-info">
                                                <div class="jsF-modal-header">
                                                    <button type="button" class="jsF-modal-close">X</button>
                                                    <?php echo $form['title']; ?>
                                                    <button class="jsF-print-submission"><i class="fa fa-print"></i></button>
                                                </div>
                                                <div class="jsF-modal-body">
                                                </div>
                                            </div>
                                        </div>
                                        <?php if (!empty($sub_id) && $sub_id == $submission['id']): ?>
                                            <div id="jsF_submission_<?php echo $submission['id'] ?>" class="jsF-edit-submission">
                                                <?php echo do_shortcode('[jsForms layout_options="0" id="' . $submission['form_id'] . '"]') ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>

                                    <div class="jsF-my-account-detail jsF-my-account-col-date">
                                        <?php echo $submission['created_date']; ?>
                                    </div>
                                    <div class="jsF-my-account-detail jsF-my-account-col-edit">
                                        <a class="jsF-edit-submission-row <?php echo !jsForms_edit_permission($form,$submission) ? 'jsF-link-disabled' : ''; ?>" data-form-id="<?php echo esc_attr($form['id']); ?>" data-submission-id="<?php echo esc_attr($submission['id']); ?>" href="javascript:void(0)"><?php _e('Edit', 'jsForms');  ?></a>
                                        <a class="jsF-delete-submission-row <?php echo !jsForms_delete_permission($form,$submission) ? 'jsF-link-disabled' : ''; ?>" data-form-id="<?php echo esc_attr($form['id']); ?>" data-submission-id="<?php echo esc_attr($submission['id']); ?>" href="javascript:void(0)"><?php _e('Delete', 'jsForms');  ?></a>
                                         
                                            
                                        <div class="jsF-modal" style="display: none;">
                                            <div class="jsF-modal-header">
                                                <button type="button" class="jsF-modal-close">X</button>
                                                <?php _e('Edit Submission','jsForms') ?>
                                            </div>
                                            <div class="jsF-modal-body jsF-edit-submission-form">
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach;
                        } else { ?>
                            <div class="jsF-message-info">
                                <?php _e('No submission yet.', 'jsForms'); ?>	
                            </div>
                        <?php } ?>
                    </div>
                </div>
                <div class="jsF-account-pagination clearfix">
                    <?php if ($show_prev): ?>
                    <a href="<?php echo home_url(add_query_arg(array('jsF_paged' => $paged - 1), $wp->request)); ?>" class="jsF-pagination jsF-prev"><?php _e('Prev', 'jsForms'); ?></a>
                    <?php endif; ?>

                    <?php if ($show_next): ?>
                        <a href="<?php echo home_url(add_query_arg(array('jsF_paged' => $paged + 1), $wp->request)); ?>" class="jsF-pagination jsF-next"><?php _e('Next', 'jsForms'); ?></a>
                    <?php endif; ?>
                </div>
            </div>
            <!-- Pagination -->
            
            <div class="jsF-my-account-profile-tab jsF-hidden" id="reset-password">
                
                <form class="jsF-form jsF-change-password" data-parsley-validate="" novalidate="true" autocomplete="off" method="POST">
                    <div class="jsF-errors">
                        <div class="jsF-error-row"></div>
                    </div>
                    <div class="jsF-message"></div>
                    <div class="fb-text form-group">
                            <label for="password_current"><?php _e('Current password','jsForms'); ?></label>
                            <input required="" type="password" class="form-control" name="password_current">
                    </div>
                    <?php $uid= uniqid(); ?>
                    <div class="fb-text form-group">
                            <label for="password_1"><?php _e('New password','jsForms'); ?></label>
                            <input required="" minlength="5" type="password" class="form-control jsF-password" name="password_1" id="jsF_my_account_password_<?php echo $uid ?>">
                    </div>
                    <div class="fb-text form-group">
                            <label for="password_2"><?php _e('Confirm new password','jsForms'); ?></label>
                            <input required="" type="password" class="form-control" data-parsley-confirm-password="jsF_my_account_password_<?php echo $uid ?>" name="password_2">
                    </div>
                    <div class="fb-text form-group">
                        <input type="hidden" name="action" value="jsF_change_password" />
                        <input type="hidden" name="jsForm_change_pwd_nonce" value="<?php echo wp_create_nonce('jsForm_change_pwd_nonce'); ?>" />
                        <button type="submit" name="change_password" value="<?php _e('Change Password','jsForms'); ?>"><?php _e('Change Password','jsForms'); ?></button>
                    </div>
                </form>

            </div>
            
        </div>
    </div>
</div>
