<?php
if (!empty($attr['form_id'])) {
    $form = jsForms()->form->get_form($attr['form_id']);
    if (!empty($form)) {
        $attr['label_position'] = $form['label_position'];
        $attr['field_style'] = $form['field_style'];
        $attr['layout'] = $form['layout'];
    }
}
$options = jsForms()->options->get_options();
if ($options['allow_login_from'] == 'username') {
    $username_label = __('Username', 'jsForms');
} elseif ($options['allow_login_from'] == 'email') {
    $username_label = __('Email', 'jsForms');
} else {
    $username_label = __('Username/Email', 'jsForms');
}
?>
<div class="<?php echo empty($attr['form_id']) ? 'jsF-container' : ''; ?>">
    <div class="jsF-login-container jsF-label-<?php echo $attr['label_position']; ?> jsF-style-<?php echo $attr['field_style']; ?> jsF-layout-<?php echo $attr['layout']; ?>" style="<?php echo !empty($attr['hide']) ? 'display:none' : ''; ?>">     
        <div class="jsF-message"></div>

        <?php if (!is_user_logged_in()) : ?>
            <form action="" method="post" class="jsF-login-form jsF-form">
                <div class="fb-text form-group">
                    <label for="jsF_username" class="fb-text-label">
                        <?php echo $username_label; ?><span class="jsF-required">*</span>
                    </label>

                    <input required="" placeholder="<?php echo $attr['label_position'] == 'no-label' ? $username_label : ''; ?>" value="" type="text" class="form-control" id="jsF_username" name="jsF_username">
                </div>

                <div class="fb-text form-group">
                    <label for="jsF_password" class="fb-text-label">
                        <?php _e('Password', 'jsForms') ?><span class="jsF-required">*</span>
                    </label>

                    <input placeholder="<?php echo $attr['label_position'] == 'no-label' ? __('Password', 'jsForms') : ''; ?>" type="password" value="" required="" class="form-control" id="jsF_password" name="jsF_password">
                </div>

                <div class="fb-text form-group">

                    <label for="rememberme" class="fb-text-label">
                        <input name="rememberme" <?php echo isset($_POST['rememberme']) ? 'checked' : ''; ?> type="checkbox" id="jsF_rememberme" value="forever">
                        <?php _e('Remember', 'jsForms') ?>
                    </label>
                </div>


                <input type="hidden" name="action" value="jsF_login_user"  />
                <input type="hidden" name="jsF_login_nonce" id="jsF_login_nonce" value="<?php echo wp_create_nonce('jsF_login_nonce'); ?>" />

                <div class="jsF-before-login-btn">
                    <?php do_action('jsForms_before_login_button'); ?>
                </div>   

                <div class="jsF-external-form-elements">
                    <?php if (jsForms_login_captcha_enabled()) : ?>
                        <!-- Show reCaptcha if configured -->
                        <?php if($this->options['recaptcha_version']==2): ?>
                            <div class="g-recaptcha jsF-recaptcha clearfix" data-sitekey="<?php echo esc_attr($this->options['rc_site_key']); ?>"></div>
                        <?php else: ?>
                            <div class="g-recaptcha jsF-recaptcha clearfix"></div>
                        <?php endif; ?>    
                        <!-- reCaptcha ends here -->
                    <?php endif; ?>
                </div>   
                <div class="jsF-error"></div>
                <div class="jsF-submit-button jsF-clearfix">    
                    <div class="fb-button form-group">
                        <button type="submit" class="btn btn-default" style="default"><?php _e('Login', 'jsForms') ?></button>
                    </div>
                </div>
                <?php if (!empty($attr['form_id']) && empty($form['login_and_register'])) : ?>
                    <div class="jsF-account-switch">
                        <a class="jsF-show-register" href="javascript:void(0)"><?php _e('Register', 'jsForms') ?></a>
                        <a class="jsF-show-lost-password"  href="javascript:void(0)" title="<?php _e('Lost/Forgot Password?', 'jsForms') ?>"><?php _e('Lost Password?', 'jsForms') ?></a>
                    </div>
                <?php else: ?>
                    <div class="jsF-account-switch">
                        <a class="jsF-show-lost-password"  href="javascript:void(0)" title="<?php _e('Lost/Forgot Password?', 'jsForms') ?>"><?php _e('Lost Password?', 'jsForms') ?></a>
                    </div>
                <?php endif; ?>

            </form>

            <form id="jsF_login_reload_form" method="POST">

            </form>

        <?php else: ?>
            <div>   
                <?php _e('You are already logged in.', 'jsForms') ?><br><br>
                <button onClick="location.href = '<?php echo jsForms_logout_url(); ?>'" class="btn btn-default"><?php _e('Logout', 'jsForms'); ?></button>
            </div>
        <?php endif; ?>
    </div>
    <?php
    /*
     * 1. If Login widget is not configured within Registration Form.
     * 2. If Login widget is configured to appear together with Registeration Form
     */

    if (empty($attr['form_id']) || (!empty($form)) && !empty($form['login_and_register']))
        include 'lost_password.php';
    ?>
</div>    
<?php
/*
 * 1. If Login widget is configured within Registration Form.
 * 2. If Login widget is configured not to appear together with Registeration Form
 */
if (!empty($attr['form_id']) && (!empty($form)) && empty($form['login_and_register']))
    include 'lost_password.php';