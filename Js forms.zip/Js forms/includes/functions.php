<?php

/**
 * PjsForms json_decode and unslash.
 *
 * @since 1.0.0
 *
 * @param string $data
 *
 * @return array|bool
 */
function jsForms_decode($data) {

    if (!$data || empty($data)) {
        return false;
    }

    return wp_unslash(json_decode($data, true));
}

/**
 * PjsForms json_encode and wp_slash.
 *
 * @since 1.3.1.3
 *
 * @param mixed $data
 *
 * @return string
 */
function jsForms_encode($data = false) {

    if (empty($data)) {
        return false;
    }

    return wp_slash(wp_json_encode($data));
}

function jsForms_dropdown_forms($selected = '') {
    $r = '';
    $forms = jsForms()->form->get();
    foreach ($forms as $form) {
        if ($selected == $form->ID) {
            $r .= "\n\t<option selected='selected' value='" . $form->ID . "'>$form->post_title</option>";
        } else {
            $r .= "\n\t<option value='" . $form->ID . "'>$form->post_title</option>";
        }
    }
    echo $r;
}

function jsForms_primary_field_types() {
    return array('user_email', 'password');
}

/*
 * Filters user related fields from submission data
 */

function jsForms_filter_user_fields($form_id, $data = array()) {
    $form = jsForms()->form->get_form($form_id);

    $field_map = array();
    foreach ($form['fields'] as $field_data) {
        if (!empty($field_data['addUsjsField']) && !empty($field_data['addUsjsFieldMap'])) {
            $field_map[$field_data['name']] = $field_data['addUsjsFieldMap'];
        }

        if (in_array($field_data['type'], jsForms_primary_field_types())) {
            $field_map[$field_data['type']] = $field_data['name'];
        }
        if (jsForms_is_username_field($field_data)) {
            $field_map['username'] = $field_data['name'];
        }
    }
    return $field_map;
}

function jsForms_is_username_field($field) {
    if ($field['type'] == 'username') {
        return true;
    }
    return false;
}

/*
 * Sanitizes request data as per field schema
 */

function jsForms_sanitize_request_data($fields = array(), $req_type = 'POST') {
    $data = $_POST;
    // Overriding with sanitized values based on the field type
    foreach ($fields as $field) {
        jsForms_sanitize_field_data($field, $data);
    }
    return $data;
}

function jsForms_sanitize_field_data($field, &$data) {
    if (empty($field))
        return false;

    $field = (object) $field;
    $type = strtolower($field->type);
    switch ($type) {
        case 'user_email':
        case 'email': $data[$field->name] = isset($_POST[$field->name]) ? sanitize_email(wp_unslash($_POST[$field->name])) : '';
            break;
        case 'tel':
        case 'text':
        case 'country':
        case 'zip':
        case 'state':
        case 'city':
        case 'street1':
        case 'street2':
        case 'username':
        case 'date':
        case 'hidden':
        case 'radio-group':
        case 'password': $data[$field->name] = isset($_POST[$field->name]) ? sanitize_text_field(wp_unslash($_POST[$field->name])) : '';
            break;
        case 'textarea': $data[$field->name] = isset($_POST[$field->name]) ? sanitize_textarea_field(wp_unslash($_POST[$field->name])) : '';
            break;
        case 'number': $data[$field->name] = isset($_POST[$field->name]) ? jsForms_get_numeric(wp_unslash($_POST[$field->name])) : 0;
            break;
        case 'url': $data[$field->name] = isset($_POST[$field->name]) ? esc_url_raw(wp_unslash($_POST[$field->name])) : '';
            break;
        case 'checkbox-group': if (isset($_POST[$field->name])) {
                $data[$field->name] = wp_unslash($_POST[$field->name]);
                if (is_array($data[$field->name])) {
                    $data[$field->name] = array_map('sanitize_text_field', $data[$field->name]);
                } else {
                    $data[$field->name] = sanitize_text_field($data[$field->name]);
                }
            } else {
                $data[$field->name] = array();
            }
            break;
        case 'select': if (isset($_POST[$field->name])) {
                $data[$field->name] = wp_unslash($_POST[$field->name]);
                if (is_array($data[$field->name])) {
                    $data[$field->name] = array_map('sanitize_text_field', $data[$field->name]);
                } else {
                    $data[$field->name] = sanitize_text_field($data[$field->name]);
                }
            } else {
                $data[$field->name] = !empty($field->multiple) ? array() : '';
            }
            break;
    }

    return $data;
}

function jsForms_sample_reg_form() {
    $r1 = wp_generate_password(6, false, false);
    $r2 = wp_generate_password(6, false, false);
    $r3 = wp_generate_password(6, false, false);
    $r4 = wp_generate_password(6, false, false);
    $r5 = wp_generate_password(6, false, false);
    return array
        (
        'settings' => array
            (
            'form_desc' => '',
            'notifications' => ''
        ),
        'fields' => '[{"type":"text","value":"","label":"First Name","advance":"+ Advanced Settings","className":"form-control","name":"text-' . $r1 . '","addUsjsField":true,"addUsjsFieldMap":"first_name,display_name"},{"type":"text","value":"","label":"Last Name","advance":"+ Advanced Settings","className":"form-control","name":"text-' . $r2 . '","addUsjsField":true,"addUsjsFieldMap":"last_name"},{"type":"user_email","required":true,"value":"","label":"User Email","advance":"+ Advanced Settings","className":"form-control","name":"text-' . $r3 . '"},{"type":"password","required":true,"value":"","label":"Password","advance":"+ Advanced Settings","placeholder":"","className":"form-control","name":"text-' . $r4 . '"},{"type":"button","subtype":"submit","label":"Register","className":"btn btn-default","name":"button-' . $r5 . '","style":"default"}]',
    );
}

function jsForms_sample_contact_form() {
    $r1 = wp_rand(3541231, 314431431631);
    $r2 = wp_rand(3541231, 314431431631);
    $r3 = wp_rand(3541231, 31443431631);
    $r4 = wp_rand(3541233, 31443431631);
    $r5 = wp_rand(3541233, 31443431631);
    return array
        (
        'settings' => array
            (
            'form_title' => '',
            'form_desc' => '',
            'notifications' => ''
        ),
        'fields' => '[{"type":"text","maxlength":"50","required":true,"label":"First Name","advance":"+ Advanced Settings","placeholder":"","className":"form-control","name":"text-' . $r1 . '"},{"type":"text","required":true,"label":"Last Name","maxlength":"50","advance":"+ Advanced Settings","className":"form-control","name":"text-' . $r2 . '"},{"type":"email","required":true,"label":"Email","advance":"+ Advanced Settings","className":"form-control","name":"text-' . $r3 . '"},{"type":"textarea","maxlength":"500","rows":"5","required":true,"label":"Message","className":"form-control","name":"textarea-' . $r4 . '"},{"type":"button","label":"Send","subtype":"submit","className":"btn btn-default","name":"button-' . $r5 . '","style":"default"}]'
    );
}

function jsForms_default_form_meta($form_type) {
    $meta_input = array('type' => $form_type);

    $meta_input['default_role'] = get_option('default_role');
    $meta_input['auto_user_activation'] = 1;
    $meta_input['access_roles'] = array();
    $meta_input['auto_reply'] = __('Thank you for registering with us. You will soon receive an account activation email. After that you can log into our website through login page.', 'jsForms');
    $meta_input['enable_external_url'] = 0;
    $meta_input['external_url'] = '';
    $meta_input['enable_limit'] = 0;
    $meta_input['auto_login'] = 0;
    $meta_input['limit_by_date'] = '';
    $meta_input['limit_by_number'] = 0;
    $meta_input['limit_type'] = 'date';
    $meta_input['enable_login_form'] = 0;
    $meta_input['login_and_register'] = 0;
    $meta_input['enabled_auto_reply'] = 1;
    $meta_input['enable_admin_notification'] = 1;
    $meta_input['admin_notification_msg'] = 'Hello Admin,<br> You have received a new submission. Here are the details: <br><br> {{REGISTRATION_DATA}}';
    $meta_input['enable_act_notification'] = 1;
    $meta_input['user_act_subject'] = 'Account Activation';
    $meta_input['user_act_msg'] = 'Your account has been activated successfully.';

    $meta_input['auto_reply_subject'] = 'Registration';
    $meta_input['admin_notification_from'] = '';
    $meta_input['admin_notification_from_name'] = '';
    $meta_input['unique_id_gen_method'] = 'auto';
    $meta_input['unique_id_padding'] = 0;
    $meta_input['unique_id_offset'] = 1;
    $meta_input['unique_id_index'] = 1;
    $meta_input['unique_id_prefix'] = '';
    $meta_input['recaptcha_enabled'] = 0;
    $meta_input['enable_unique_id'] = 0;
    $meta_input['redirect_to'] = '';
    $meta_input['label_position'] = 'top';
    $meta_input['layout'] = 'one-column';
    $meta_input['field_style'] = 'rounded-corner';
//$meta_input['success_msg']= "Thank you for registering with us!"; // changing success msg
    $meta_input['access_denied_msg'] = 'You are not authorised to access this form.';
    $meta_input['plan_enabled'] = 0;
    $meta_input['limit_message'] = 'Form submission limit reached.';
    $meta_input['admin_notification_to'] = '';
    $meta_input['en_pwd_restriction'] = 0;
    $meta_input['pwd_res_description'] = 'Please answer the question to access the form.';
    $meta_input['pwd_res_question'] = 'Your Password';
    $meta_input['pwd_res_err'] = 'Incorrect password.';
    $meta_input['pwd_res_en_logged_in'] = 0;
    $meta_input['pwd_res_answer'] = '';
    $meta_input['auto_reply_from'] = '';
    $meta_input['auto_reply_from_name'] = '';
    $meta_input['reports'] = array();
    if ($form_type == "reg") {
        $meta_input['auto_reply_msg'] = 'Hello,<br>Thank you for registering with us.';
        $meta_input['admin_notification_subject'] = 'New Submission';
        $meta_input['before_form'] = 'Register with us by filling out the form below.';
        $meta_input['role_choices'] = array();
        $meta_input['role_choice_position'] = '';
        $meta_input['success_msg'] = "Thank you for registering with us!";

        $meta_input['user_act_from'] = '';
        $meta_input['user_act_from_name'] = '';
        $meta_input['allow_re_register'] = 1;
        $meta_input['en_email_verification'] = 0;
        //$meta_input['act_link_expiry']=0;
        $meta_input['user_acc_verification_msg'] = 'Your account has been verified. <br> [jsForms_my_account]';
        $meta_input['en_user_ver_msg'] = 0;
        $meta_input['user_ver_from'] = '';
        $meta_input['user_ver_from_name'] = '';
        $meta_input['user_ver_subject'] = 'Account Verification';
        $meta_input['user_ver_email_msg'] = 'Your account is not activated yet. Please follow below given link to activate your account : <br> {{verification_link}}';
        $meta_input['after_user_ver_page'] = 0;
        $meta_input['auto_login_after_ver'] = 0;
        $meta_input['show_before_login_form'] = 0;
    } else {
        $meta_input['auto_reply_msg'] = 'Hello,<br>Thank you for contacting us.';
        $meta_input['admin_notification_subject'] = 'New Contact Request';
        $meta_input['before_form'] = 'Contact us by filling out the form below.';
        $meta_input['success_msg'] = "Thank you for contacting us!";
        $meta_input['allow_only_registered'] = 0;
    }
    $meta_input['auto_reply_to'] = '';
    $meta_input['primary_field'] = '';
    $meta_input['primary_contact_name_field'] = '';
    $meta_input['allow_single_plan'] = 0;
    $meta_input['payment_header'] = __('Payment Details', 'jsForms');
    $meta_input['plans'] = array('enabled' => array(), 'required' => array());
    $meta_input['enable_edit_notifications'] = 0;
    $meta_input['edit_sub_user_email'] = __('Your submission edited successfully.');
    $meta_input['edit_sub_user_from'] = '';
    $meta_input['edit_sub_user_from_name'] = '';
    $meta_input['edit_sub_user_subject'] = 'Submission Edited';
    $meta_input['edit_sub_admin_email'] = __('Edit Submission Details are : {{registration_data}}');
    $meta_input['edit_sub_admin_from'] = '';
    $meta_input['edit_sub_admin_from_name'] = '';
    $meta_input['edit_sub_admin_subject'] = 'Submission Edited';
    $meta_input['edit_sub_admin_list'] = '';
    $meta_input['enable_delete_notifications'] = 0;
    $meta_input['delete_sub_user_email'] = __('Your submission deleted successfully.');
    $meta_input['delete_sub_user_from'] = '';
    $meta_input['delete_sub_user_from_name'] = '';
    $meta_input['delete_sub_user_subject'] = 'Submission Deleted';
    $meta_input['delete_sub_admin_email'] = __('Deleted Submission Details are : {{registration_data}}');
    $meta_input['delete_sub_admin_from'] = '';
    $meta_input['delete_sub_admin_from_name'] = '';
    $meta_input['delete_sub_admin_subject'] = 'Submission Deleted';
    $meta_input['delete_sub_admin_list'] = '';
    $meta_input['form_admin_list'] = '';
    $meta_input['en_edit_sub'] = 0;
    $meta_input['allow_sub_deletion'] = 0;
    $meta_input['edit_fields'] = array();
    $meta_input['opt_in'] = 0;
    $meta_input['opt_text'] = __('Subscribe for emails', 'jsForms');
    $meta_input['opt_default_state'] = 0;
    $meta_input['limit_time'] = '';
    $meta_input['sub_columns'] = array();
    $meta_input['dis_mul_sub'] = 0;
    $meta_input['mul_sub_denial_msg'] = __('You have already submitted this form.', 'jsForms');
    $meta_input = apply_filters('jsForms_default_form_meta', $meta_input, $form_type);
    return $meta_input;
}

function jsForms_non_input_fields() {
    return array('button', 'splitter', 'header', 'separator', 'richtext');
}

function jsForms_get_form_input_fields($form_id) {
    $form_id = absint($form_id);
    $form = jsForms()->form->get_form($form_id);
    $fields = array();

    $excluded_fields = jsForms_non_input_fields();
    if (is_array($form['fields'])) {
        foreach ($form['fields'] as $field) {
            if (in_array($field['type'], $excluded_fields) || ($field['type'] == 'password'))
                continue;
            array_push($fields, $field);
        }
    }

    return $fields;
}

function jsForms_get_fields_tinymce($form_id, $json = true) {
    $form_id = absint($form_id);
    $form = jsForms()->form->get_form($form_id);
    $fields = array();

    $excluded_fields = jsForms_non_input_fields();
    foreach ($form['fields'] as $field) {
        if (in_array($field['type'], $excluded_fields) || ($field['type'] == 'password'))
            continue;
        array_push($fields, array('text' => $field['label'], 'value' => $field['label']));
    }
    if (!empty($form['enable_unique_id'])) {
        array_push($fields, array('text' => 'UNIQUE_ID', 'value' => 'UNIQUE_ID'));
    }

    return $json ? json_encode($fields) : $fields;
}

function jsForms_validate_captcha($g_r_captcha) {
    $options = jsForms()->options->get_options();
    if (!empty($options['recaptcha_configured']) && !empty($options['rc_secret_key'])) {
        $url = 'https://www.google.com/recaptcha/api/siteverify';
        $response = wp_remote_get($url . "?secret=" . $options['rc_secret_key'] . "&response=" . $g_r_captcha . "&remoteip=" . $_SERVER['REMOTE_ADDR'], array('timeout' => 10));
        if (is_array($response)) {
            $response = json_decode($response['body']);
        } else {
            return false;
        }

        if (!empty($response) && !empty($response->success)) {
            return true;
        }
        return false;
    }
    return true;
}

/**
 * Helper function to determine if jsForms Admin Page
 *
 * @since 1.0.0
 * @return boolean
 */
function jsForms_is_admin_page() {
    $admin_pages = array('jsForms-dashboard', 'jsForms-overview', 'jsForms-submissions', 'jsForms-submission', 'jsForms-settings', 'jsForms-analytics', 'jsForms-labels', 'jsForms-plans', 'jsForms-plan', 'jsForms-tools', 'jsForms-help', 'jsForms-field-shortcodes');
    $admin_pages = apply_filters('jsF_admin_pages', $admin_pages);
    $page = isset($_REQUEST['page']) ? sanitize_text_field($_REQUEST['page']) : '';
    if (is_admin() && in_array($page, $admin_pages)) {
        return true;
    }

    return false;
}

function jsForms_error_strings() {
    $strings = array(
        'defaultMessage' => __('This value seems to be invalid.', 'jsForms'),
        'type' => array(
            'email' => __('This value should be a valid email.', 'jsForms'),
            'url' => __('This value should be a valid url.', 'jsForms'),
            'number' => __('This value should be a valid number.', 'jsForms'),
            'integer' => __('This value should be a valid integer.', 'jsForms'),
            'digits' => __('This value should be digits.', 'jsForms'),
            'alphanum' => __('This value should be alphanumeric.', 'jsForms')
        ),
        'notblank' => __('This value should not be blank.', 'jsForms'),
        'required' => __('This value is required.', 'jsForms'),
        'pattern' => __('This value seems to be invalid.', 'jsForms'),
        'min' => __('This value should be greater than or equal to %s.', 'jsForms'),
        'max' => __('This value should be lower than or equal to %s.', 'jsForms'),
        'range' => __('This value should be between %s and %s.', 'jsForms'),
        'minlength' => __('This value is too short. It should have %s characters or more.', 'jsForms'),
        'maxlength' => __('This value is too long. It should have %s characters or fewer.', 'jsForms'),
        'length' => __('This value length is invalid. It should be between %s and %s characters long.', 'jsForms'),
        'mincheck' => __('You must select at least %s choices.', 'jsForms'),
        'maxcheck' => __('You must select %s choices or fewer.', 'jsForms'),
        'check' => __('You must select between %s and %s choices.', 'jsForms'),
        'equalto' => __('This value should be the same.', 'jsForms'),
        'date' => __('Invalid date value', 'jsForms'),
        'confirmPassword' => __('These passwords are not similar to each other. Try again?', 'jsForms')
    );

    return $strings;
}

function jsForms_text_helpers() {
    $help_texts = array(
        'required' => __('Ensure that this field is completed before allowing the form to be submitted.', 'jsForms'),
        'label' => __('Label of the field as it appears on forms. Only Alphanumeric,Space,Underscores are allowed. Do not use any other special characters.', 'jsForms'),
        'description' => __('Show a helptext of this field on front end.', 'jsForms'),
        'dataDateFormat' => __('Accepted date format.', 'jsForms'),
        'placeholder' => __('A sample value or a short description of the expected value/format.', 'jsForms'),
        'className' => __('Add a custom CSS class.', 'jsForms'),
        'masking' => sprintf(__('Allows fixed width in a certain format (dates,phone numbers, etc). <a href="%s" target="_blank">More Details</a>', 'jsForms'), '/'),
        'maxlength' => __('Maximum length of the field.', 'jsForms'),
        'minlength' => __('Minimum length of the field.', 'jsForms'),
        'addUsjsField' => sprintf(__('Map field value with WordPress user meta. <a href="%s" target="_blank">More Details</a>', 'jsForms'), '/'),
        'addUsjsFieldMap' => __('Meta key(s) to map with User Account in WordPress. Use comma(,) to separate multiple keys.', 'jsForms'),
        'accept' => __('Specify supported file formats separated with single space. For eg. PNG JPG DOC', 'jsForms'),
        'min' => __('This specifies the minimum value of the field.', 'jsForms'),
        'max' => __('This specifies the maximum value of the field.', 'jsForms'),
        'enableUnique' => __('No two submission can have same value for this field.', 'jsForms'),
        'pattern' => sprintf(__('The pattern attribute specifies a regular expression that the &lt;input&gt; element\'s value is checked against.<a target="_blank" href="%s">More Details</a>', 'jsForms'), 'https://www.w3schools.com/tags/att_input_pattern.asp'),
        'confirmPassword' => __('Displays a confirm password field.', 'jsForms'),
        'user_roles' => __('Allow to show user role list to pick from. User will be registered under selected role. <br>*Note: Please do not forget to change "Assign User Role" to "Inherit from Form" in Configuration->User Account settings.', 'jsForms'),
        'other' => __('This allows to add any custom option from frontend.', 'jsForms'),
        'inline' => __('Displays all the options in one line.', 'jsForms'),
        'dataRefLabel' => __('This is for refering fields within the system and will not visible on front end. Length can not be greater than 40 characters.', 'jsForms'),
        'datajsFBtnPos' => __("Select where the button is placed.", 'jsForms'),
        'enableIntl' => sprintf(__('It adds a flag dropdown to the field to detects the user\'s country.<a target="_blank" href="%s">More Details</a>', 'jsForms'), 'https://www.jqueryscript.net/form/jQuery-International-Telephone-Input-With-Flags-Dial-Codes.html'),
        'icon' => __("Display an icon before the field's label.", 'jsForms'),
        'richtext' => __("Allows to show formatted HTML code.", 'jsForms'),
        'deleteFieldConfirm' => __("Are you sure you want to remove this field?", 'jsForms'),
        'width' => __('Sets the width of the element on the form row. Each row has a total width of 12.', 'jsForms'),
        'value' => __('Sets the default value for the input field.', 'jsForms'),
        'name' => __('This name attribute can be used to reference the element in HTML,Javascript or PHP integration.', 'jsForms'),
        'hide' => __('If checked, field will be hidden during form render.', 'jsForms'),
        'save' => __('If checked, field value will be saved into the database.', 'jsForms'),
    );
    return $help_texts;
}

function jsForms_admin_text_helpers() {
    $help_texts = array(
        'sub_del_prompt' => __("Are you sure to delete selected item(s)? Once deleted, you won't be able to recover the data.", 'jsForms'),
    );
    return $help_texts;
}

function jsForms_get_roles_checkbox($name, $selected) {
    global $wp_roles;

    if (!isset($wp_roles))
        $wp_roles = new WP_Roles();
    $roles = $wp_roles->get_names();
    if (empty($selected) || !is_array($selected))
        $selected = array();
    $html = '';
    foreach ($roles as $role_value => $role_name) {
        if (in_array($role_value, $selected))
            $html .= '<label class="jsF-user-roles"><input checked name="' . $name . '[]" type="checkbox" value="' . $role_value . '"><span>' . $role_name . '</span></label>';
        else
            $html .= '<label class="jsF-user-roles"><input name="' . $name . '[]" type="checkbox" value="' . $role_value . '"><span>' . $role_name . '</span></label>';
    }
    return $html;
}

function jsForms_get_forms_tinymce() {
    $forms = jsForms()->form->get();
    $form_names = array(array('text' => 'Login Form', 'value' => 'login_form'));
    foreach ($forms as $form) {
        array_push($form_names, array('text' => $form->post_title, 'value' => $form->ID));
    }
    return json_encode($form_names);
}

/*
 * Formatting submission data before sending to external URL
 */

function jsForms_format_submission_for_external($submission) {
    if (empty($submission))
        return array();

    return $submission;
}

function jsForms_admin_submission_table($submission, $exclude = array()) {
    if (!is_array($submission))
        return;
    ?>
    <table class="jsF-submission-table striped wp-list-table fixed widefat">
        <tbody>
            <tr><th colspan="2" class="jsF-submission-title"><?php _e('Submission Date', 'jsForms'); ?> : <?php echo $submission['created_date']; ?></th></tr>
    <?php if (!empty($submission['unique_id'])) : ?>
                <tr>
                    <th><?php _e('Unique Submission ID', 'jsForms'); ?></th>
                    <td><?php echo $submission['unique_id']; ?></td>
                </tr>
            <?php endif; ?>

    <?php
    $formatter = new jsForms_Submission_Formatter('html', $submission);
    $submission = $formatter->format();
    ?>
            <?php foreach ($submission['fields_data'] as $single): ?>
                <tr>
                <?php echo '<th><label>' . $single['f_label'] . '</label></th>'; ?>
                    <td><?php echo $single['f_val']; ?></td>    
                </tr>

            <?php endforeach; ?>
            <tr>
                <th><?php _e('Modified Date', 'jsForms'); ?></th>
                <td><?php echo $submission['modified_date']; ?></td>
            </tr>

            <?php if (!empty($submission['external_url'])) : $external_url = $submission['external_url']; ?>    

                <tr>
                    <th colspan="2"><?php _e('External Request Information', 'jsForms'); ?></th>
                </tr>

                <tr>
                    <th><?php _e('URL', 'jsForms'); ?></th>
                    <td><?php echo $external_url['url']; ?></td>
                </tr>

                <tr>
                    <th><?php _e('Status', 'jsForms'); ?></th>
                    <td><?php $external_url['status'] ? _e('Success', 'jsForms') : _e('Failure', 'jsForms'); ?></td>
                </tr>

        <?php if (!empty($external_url['error'])) : ?>
                    <tr>
                        <th><?php _e('Error', 'jsForms'); ?></th>
                        <td><?php echo $external_url['error']; ?></td>
                    </tr>
                <?php endif; ?>



    <?php endif; ?>    
        </tbody>
    </table>

    <?php
}

function jsForms_show_user_fields($user) {
    $active = jsForms()->user->get_meta($user->ID, 'active');
    ?>
    <h3><?php _e('Activate User', 'jsForms') ?></h3>
    <table class="form-table">
        <tr>
            <th><label for="user_status"><?php _e('Status', 'jsForms'); ?></label></th>

            <td>
                <select name="jsF_user_status" id="user_status">
                    <option <?php echo $active !== '0' ? 'selected' : '' ?> value="1"><?php _e('Active', 'jsForms') ?></option>
                    <option <?php echo $active === '0' ? 'selected' : '' ?> value="0"><?php _e('Deactive', 'jsForms') ?></option>
                </select>
                <p class="description"><?php _e("Deactivated users won't be able to login.", 'jsForms'); ?></p>
            </td>
        </tr>

    </table>
    <?php
}

function jsForms_js_strings() {
    return array('next' => __('Next', 'jsForms'), 'prev' => __('Previous', 'jsForms'),
        'loading_edit_form' => __('Loading Form...', 'jsForms'),
        'edit_form_load_error' => __('Unable to load form data.', 'jsForms'),
        'loading_submission_info' => __('Loading submission data...', 'jsForms'), 'delete_file' => __('Delete File', 'jsForms'), 'other' => __('Other', 'jsForms'));
}

function jsForms_map_integer($a) {
    return absint($a);
}

/**
 * Get full list of currency codes.
 *
 * @return array
 */
function jsForms_currencies() {
    return array(
        'AED' => __('United Arab Emirates dirham', 'jsForms'),
        'AFN' => __('Afghan afghani', 'jsForms'),
        'ALL' => __('Albanian lek', 'jsForms'),
        'AMD' => __('Armenian dram', 'jsForms'),
        'ANG' => __('Netherlands Antillean guilder', 'jsForms'),
        'AOA' => __('Angolan kwanza', 'jsForms'),
        'ARS' => __('Argentine peso', 'jsForms'),
        'AUD' => __('Australian dollar', 'jsForms'),
        'AWG' => __('Aruban florin', 'jsForms'),
        'AZN' => __('Azerbaijani manat', 'jsForms'),
        'BAM' => __('Bosnia and Herzegovina convertible mark', 'jsForms'),
        'BBD' => __('Barbadian dollar', 'jsForms'),
        'BDT' => __('Bangladeshi taka', 'jsForms'),
        'BGN' => __('Bulgarian lev', 'jsForms'),
        'BHD' => __('Bahraini dinar', 'jsForms'),
        'BIF' => __('Burundian franc', 'jsForms'),
        'BMD' => __('Bermudian dollar', 'jsForms'),
        'BND' => __('Brunei dollar', 'jsForms'),
        'BOB' => __('Bolivian boliviano', 'jsForms'),
        'BRL' => __('Brazilian real', 'jsForms'),
        'BSD' => __('Bahamian dollar', 'jsForms'),
        'BTC' => __('Bitcoin', 'jsForms'),
        'BTN' => __('Bhutanese ngultrum', 'jsForms'),
        'BWP' => __('Botswana pula', 'jsForms'),
        'BYR' => __('Belarusian ruble (old)', 'jsForms'),
        'BYN' => __('Belarusian ruble', 'jsForms'),
        'BZD' => __('Belize dollar', 'jsForms'),
        'CAD' => __('Canadian dollar', 'jsForms'),
        'CDF' => __('Congolese franc', 'jsForms'),
        'CHF' => __('Swiss franc', 'jsForms'),
        'CLP' => __('Chilean peso', 'jsForms'),
        'CNY' => __('Chinese yuan', 'jsForms'),
        'COP' => __('Colombian peso', 'jsForms'),
        'CRC' => __('Costa Rican col&oacute;n', 'jsForms'),
        'CUC' => __('Cuban convertible peso', 'jsForms'),
        'CUP' => __('Cuban peso', 'jsForms'),
        'CVE' => __('Cape Verdean escudo', 'jsForms'),
        'CZK' => __('Czech koruna', 'jsForms'),
        'DJF' => __('Djiboutian franc', 'jsForms'),
        'DKK' => __('Danish krone', 'jsForms'),
        'DOP' => __('Dominican peso', 'jsForms'),
        'DZD' => __('Algerian dinar', 'jsForms'),
        'EGP' => __('Egyptian pound', 'jsForms'),
        'ERN' => __('Eritrean nakfa', 'jsForms'),
        'ETB' => __('Ethiopian birr', 'jsForms'),
        'EUR' => __('Euro', 'jsForms'),
        'FJD' => __('Fijian dollar', 'jsForms'),
        'FKP' => __('Falkland Islands pound', 'jsForms'),
        'GBP' => __('Pound sterling', 'jsForms'),
        'GEL' => __('Georgian lari', 'jsForms'),
        'GGP' => __('Guernsey pound', 'jsForms'),
        'GHS' => __('Ghana cedi', 'jsForms'),
        'GIP' => __('Gibraltar pound', 'jsForms'),
        'GMD' => __('Gambian dalasi', 'jsForms'),
        'GNF' => __('Guinean franc', 'jsForms'),
        'GTQ' => __('Guatemalan quetzal', 'jsForms'),
        'GYD' => __('Guyanese dollar', 'jsForms'),
        'HKD' => __('Hong Kong dollar', 'jsForms'),
        'HNL' => __('Honduran lempira', 'jsForms'),
        'HRK' => __('Croatian kuna', 'jsForms'),
        'HTG' => __('Haitian gourde', 'jsForms'),
        'HUF' => __('Hungarian forint', 'jsForms'),
        'IDR' => __('Indonesian rupiah', 'jsForms'),
        'ILS' => __('Israeli new shekel', 'jsForms'),
        'IMP' => __('Manx pound', 'jsForms'),
        'INR' => __('Indian rupee', 'jsForms'),
        'IQD' => __('Iraqi dinar', 'jsForms'),
        'IRR' => __('Iranian rial', 'jsForms'),
        'IRT' => __('Iranian toman', 'jsForms'),
        'ISK' => __('Icelandic kr&oacute;na', 'jsForms'),
        'JEP' => __('Jersey pound', 'jsForms'),
        'JMD' => __('Jamaican dollar', 'jsForms'),
        'JOD' => __('Jordanian dinar', 'jsForms'),
        'JPY' => __('Japanese yen', 'jsForms'),
        'KES' => __('Kenyan shilling', 'jsForms'),
        'KGS' => __('Kyrgyzstani som', 'jsForms'),
        'KHR' => __('Cambodian riel', 'jsForms'),
        'KMF' => __('Comorian franc', 'jsForms'),
        'KPW' => __('North Korean won', 'jsForms'),
        'KRW' => __('South Korean won', 'jsForms'),
        'KWD' => __('Kuwaiti dinar', 'jsForms'),
        'KYD' => __('Cayman Islands dollar', 'jsForms'),
        'KZT' => __('Kazakhstani tenge', 'jsForms'),
        'LAK' => __('Lao kip', 'jsForms'),
        'LBP' => __('Lebanese pound', 'jsForms'),
        'LKR' => __('Sri Lankan rupee', 'jsForms'),
        'LRD' => __('Liberian dollar', 'jsForms'),
        'LSL' => __('Lesotho loti', 'jsForms'),
        'LYD' => __('Libyan dinar', 'jsForms'),
        'MAD' => __('Moroccan dirham', 'jsForms'),
        'MDL' => __('Moldovan leu', 'jsForms'),
        'MGA' => __('Malagasy ariary', 'jsForms'),
        'MKD' => __('Macedonian denar', 'jsForms'),
        'MMK' => __('Burmese kyat', 'jsForms'),
        'MNT' => __('Mongolian t&ouml;gr&ouml;g', 'jsForms'),
        'MOP' => __('Macanese pataca', 'jsForms'),
        'MRO' => __('Mauritanian ouguiya', 'jsForms'),
        'MUR' => __('Mauritian rupee', 'jsForms'),
        'MVR' => __('Maldivian rufiyaa', 'jsForms'),
        'MWK' => __('Malawian kwacha', 'jsForms'),
        'MXN' => __('Mexican peso', 'jsForms'),
        'MYR' => __('Malaysian ringgit', 'jsForms'),
        'MZN' => __('Mozambican metical', 'jsForms'),
        'NAD' => __('Namibian dollar', 'jsForms'),
        'NGN' => __('Nigerian naira', 'jsForms'),
        'NIO' => __('Nicaraguan c&oacute;rdoba', 'jsForms'),
        'NOK' => __('Norwegian krone', 'jsForms'),
        'NPR' => __('Nepalese rupee', 'jsForms'),
        'NZD' => __('New Zealand dollar', 'jsForms'),
        'OMR' => __('Omani rial', 'jsForms'),
        'PAB' => __('Panamanian balboa', 'jsForms'),
        'PEN' => __('Peruvian nuevo sol', 'jsForms'),
        'PGK' => __('Papua New Guinean kina', 'jsForms'),
        'PHP' => __('Philippine peso', 'jsForms'),
        'PKR' => __('Pakistani rupee', 'jsForms'),
        'PLN' => __('Polish z&#x142;oty', 'jsForms'),
        'PRB' => __('Transnistrian ruble', 'jsForms'),
        'PYG' => __('Paraguayan guaran&iacute;', 'jsForms'),
        'QAR' => __('Qatari riyal', 'jsForms'),
        'RON' => __('Romanian leu', 'jsForms'),
        'RSD' => __('Serbian dinar', 'jsForms'),
        'RUB' => __('Russian ruble', 'jsForms'),
        'RWF' => __('Rwandan franc', 'jsForms'),
        'SAR' => __('Saudi riyal', 'jsForms'),
        'SBD' => __('Solomon Islands dollar', 'jsForms'),
        'SCR' => __('Seychellois rupee', 'jsForms'),
        'SDG' => __('Sudanese pound', 'jsForms'),
        'SEK' => __('Swedish krona', 'jsForms'),
        'SGD' => __('Singapore dollar', 'jsForms'),
        'SHP' => __('Saint Helena pound', 'jsForms'),
        'SLL' => __('Sierra Leonean leone', 'jsForms'),
        'SOS' => __('Somali shilling', 'jsForms'),
        'SRD' => __('Surinamese dollar', 'jsForms'),
        'SSP' => __('South Sudanese pound', 'jsForms'),
        'STD' => __('S&atilde;o Tom&eacute; and Pr&iacute;ncipe dobra', 'jsForms'),
        'SYP' => __('Syrian pound', 'jsForms'),
        'SZL' => __('Swazi lilangeni', 'jsForms'),
        'THB' => __('Thai baht', 'jsForms'),
        'TJS' => __('Tajikistani somoni', 'jsForms'),
        'TMT' => __('Turkmenistan manat', 'jsForms'),
        'TND' => __('Tunisian dinar', 'jsForms'),
        'TOP' => __('Tongan pa&#x2bb;anga', 'jsForms'),
        'TRY' => __('Turkish lira', 'jsForms'),
        'TTD' => __('Trinidad and Tobago dollar', 'jsForms'),
        'TWD' => __('New Taiwan dollar', 'jsForms'),
        'TZS' => __('Tanzanian shilling', 'jsForms'),
        'UAH' => __('Ukrainian hryvnia', 'jsForms'),
        'UGX' => __('Ugandan shilling', 'jsForms'),
        'USD' => __('United States dollar', 'jsForms'),
        'UYU' => __('Uruguayan peso', 'jsForms'),
        'UZS' => __('Uzbekistani som', 'jsForms'),
        'VEF' => __('Venezuelan bol&iacute;var', 'jsForms'),
        'VND' => __('Vietnamese &#x111;&#x1ed3;ng', 'jsForms'),
        'VUV' => __('Vanuatu vatu', 'jsForms'),
        'WST' => __('Samoan t&#x101;l&#x101;', 'jsForms'),
        'XAF' => __('Central African CFA franc', 'jsForms'),
        'XCD' => __('East Caribbean dollar', 'jsForms'),
        'XOF' => __('West African CFA franc', 'jsForms'),
        'XPF' => __('CFP franc', 'jsForms'),
        'YER' => __('Yemeni rial', 'jsForms'),
        'ZAR' => __('South African rand', 'jsForms'),
        'ZMW' => __('Zambian kwacha', 'jsForms'),
    );
}

/**
 * Get Currency symbols.
 *
 * @param string $currency (default: '')
 * @return string
 */
function jsForms_currency_symbol($currency, $raw = true) {
    $symbols = array(
        'AED' => '&#x62f;.&#x625;',
        'AFN' => '&#x60b;',
        'ALL' => 'L',
        'AMD' => 'AMD',
        'ANG' => '&fnof;',
        'AOA' => 'Kz',
        'ARS' => '&#36;',
        'AUD' => '&#36;',
        'AWG' => 'Afl.',
        'AZN' => 'AZN',
        'BAM' => 'KM',
        'BBD' => '&#36;',
        'BDT' => '&#2547;&nbsp;',
        'BGN' => '&#1083;&#1074;.',
        'BHD' => '.&#x62f;.&#x628;',
        'BIF' => 'Fr',
        'BMD' => '&#36;',
        'BND' => '&#36;',
        'BOB' => 'Bs.',
        'BRL' => '&#82;&#36;',
        'BSD' => '&#36;',
        'BTC' => '&#3647;',
        'BTN' => 'Nu.',
        'BWP' => 'P',
        'BYR' => 'Br',
        'BYN' => 'Br',
        'BZD' => '&#36;',
        'CAD' => '&#36;',
        'CDF' => 'Fr',
        'CHF' => '&#67;&#72;&#70;',
        'CLP' => '&#36;',
        'CNY' => '&yen;',
        'COP' => '&#36;',
        'CRC' => '&#x20a1;',
        'CUC' => '&#36;',
        'CUP' => '&#36;',
        'CVE' => '&#36;',
        'CZK' => '&#75;&#269;',
        'DJF' => 'Fr',
        'DKK' => 'DKK',
        'DOP' => 'RD&#36;',
        'DZD' => '&#x62f;.&#x62c;',
        'EGP' => 'EGP',
        'ERN' => 'Nfk',
        'ETB' => 'Br',
        'EUR' => '&euro;',
        'FJD' => '&#36;',
        'FKP' => '&pound;',
        'GBP' => '&pound;',
        'GEL' => '&#x10da;',
        'GGP' => '&pound;',
        'GHS' => '&#x20b5;',
        'GIP' => '&pound;',
        'GMD' => 'D',
        'GNF' => 'Fr',
        'GTQ' => 'Q',
        'GYD' => '&#36;',
        'HKD' => '&#36;',
        'HNL' => 'L',
        'HRK' => 'Kn',
        'HTG' => 'G',
        'HUF' => '&#70;&#116;',
        'IDR' => 'Rp',
        'ILS' => '&#8362;',
        'IMP' => '&pound;',
        'INR' => '&#8377;',
        'IQD' => '&#x639;.&#x62f;',
        'IRR' => '&#xfdfc;',
        'IRT' => '&#x062A;&#x0648;&#x0645;&#x0627;&#x0646;',
        'ISK' => 'kr.',
        'JEP' => '&pound;',
        'JMD' => '&#36;',
        'JOD' => '&#x62f;.&#x627;',
        'JPY' => '&yen;',
        'KES' => 'KSh',
        'KGS' => '&#x441;&#x43e;&#x43c;',
        'KHR' => '&#x17db;',
        'KMF' => 'Fr',
        'KPW' => '&#x20a9;',
        'KRW' => '&#8361;',
        'KWD' => '&#x62f;.&#x643;',
        'KYD' => '&#36;',
        'KZT' => 'KZT',
        'LAK' => '&#8365;',
        'LBP' => '&#x644;.&#x644;',
        'LKR' => '&#xdbb;&#xdd4;',
        'LRD' => '&#36;',
        'LSL' => 'L',
        'LYD' => '&#x644;.&#x62f;',
        'MAD' => '&#x62f;.&#x645;.',
        'MDL' => 'MDL',
        'MGA' => 'Ar',
        'MKD' => '&#x434;&#x435;&#x43d;',
        'MMK' => 'Ks',
        'MNT' => '&#x20ae;',
        'MOP' => 'P',
        'MRO' => 'UM',
        'MUR' => '&#x20a8;',
        'MVR' => '.&#x783;',
        'MWK' => 'MK',
        'MXN' => '&#36;',
        'MYR' => '&#82;&#77;',
        'MZN' => 'MT',
        'NAD' => '&#36;',
        'NGN' => '&#8358;',
        'NIO' => 'C&#36;',
        'NOK' => '&#107;&#114;',
        'NPR' => '&#8360;',
        'NZD' => '&#36;',
        'OMR' => '&#x631;.&#x639;.',
        'PAB' => 'B/.',
        'PEN' => 'S/.',
        'PGK' => 'K',
        'PHP' => '&#8369;',
        'PKR' => '&#8360;',
        'PLN' => '&#122;&#322;',
        'PRB' => '&#x440;.',
        'PYG' => '&#8370;',
        'QAR' => '&#x631;.&#x642;',
        'RMB' => '&yen;',
        'RON' => 'lei',
        'RSD' => '&#x434;&#x438;&#x43d;.',
        'RUB' => '&#8381;',
        'RWF' => 'Fr',
        'SAR' => '&#x631;.&#x633;',
        'SBD' => '&#36;',
        'SCR' => '&#x20a8;',
        'SDG' => '&#x62c;.&#x633;.',
        'SEK' => '&#107;&#114;',
        'SGD' => '&#36;',
        'SHP' => '&pound;',
        'SLL' => 'Le',
        'SOS' => 'Sh',
        'SRD' => '&#36;',
        'SSP' => '&pound;',
        'STD' => 'Db',
        'SYP' => '&#x644;.&#x633;',
        'SZL' => 'L',
        'THB' => '&#3647;',
        'TJS' => '&#x405;&#x41c;',
        'TMT' => 'm',
        'TND' => '&#x62f;.&#x62a;',
        'TOP' => 'T&#36;',
        'TRY' => '&#8378;',
        'TTD' => '&#36;',
        'TWD' => '&#78;&#84;&#36;',
        'TZS' => 'Sh',
        'UAH' => '&#8372;',
        'UGX' => 'UGX',
        'USD' => '&#36;',
        'UYU' => '&#36;',
        'UZS' => 'UZS',
        'VEF' => 'Bs F',
        'VND' => '&#8363;',
        'VUV' => 'Vt',
        'WST' => 'T',
        'XAF' => 'CFA',
        'XCD' => '&#36;',
        'XOF' => 'CFA',
        'XPF' => 'Fr',
        'YER' => '&#xfdfc;',
        'ZAR' => '&#82;',
        'ZMW' => 'ZK'
    );
    if ($raw)
        $currency_symbol = isset($symbols[$currency]) ? ' (' . $symbols[$currency] . ') ' : '';
    else
        $currency_symbol = isset($symbols[$currency]) ? $symbols[$currency] : '';

    return $currency_symbol;
}

function jsForms_payment_method_title($type) {
    $methods = array('offline' => __('Offline', 'jsForms'), 'none' => __('None', 'jsForms'));
    $methods = apply_filters('jsF_payment_method_titles', $methods);
    $title = isset($methods[$type]) ? $methods[$type] : '';
    return $title;
}

function jsForms_status_options() {
    return array(jsFORMS_COMPLETED, jsFORMS_PENDING, jsFORMS_HOLD, jsFORMS_DECLINED);
}

function jsForms_redirect($url) {
    if (empty($url))
        return false;
    if (headers_sent()) {
        echo '<script>window.location.href="' . esc_url_raw($url) . '";</script>';
        exit();
    } else {
        wp_redirect($url);
        exit();
    }
}

function jsForms_wp_roles() {
    if (!function_exists('get_editable_roles')) {
        require_once ABSPATH . 'wp-admin/includes/user.php';
    }
    return get_editable_roles();
}

function jsForms_wp_roles_dropdown() {
    $editable_roles = jsForms_wp_roles();
    $roles = array();
    foreach ($editable_roles as $role => $details) {
        $sub['role'] = esc_attr($role);
        $sub['name'] = translate_user_role($details['name']);
        $roles[] = $sub;
    }
    return $roles;
}

function jsForms_get_selected_role($form_id, $data) {
    $form_model = jsForms()->form;
    $form = $form_model->get_form($form_id);
    $selected_role = '';
    foreach ($form['fields'] as $field) {
        if (!empty($field['user_roles'])) {
            if (is_array($field['values'])) {
                foreach ($field['values'] as $role) {
                    if ($data[$field['name']] == $role['value']) {
                        $selected_role = $role['value'];
                        break;
                    }
                }
            }
        }
    }
    return $selected_role;
}

function jsForms_submission_parsers() {
    return array('user_role');
}

function jsForms_schedule_report($time, $recurrence, $args) {
    $original_args = array('form_id' => (int) $args['form_id'], 'index' => (int) $args['index']);
    // Delete previously added scheduled report with same arguments   
    jsForms_delete_scheduled_report($original_args);
    wp_schedule_event($time, $recurrence, 'jsF_submission_report', $original_args);
}

function jsForms_delete_scheduled_report($args) {
    $timestamp = wp_next_scheduled('jsF_submission_report', $args);  // Passing values after conversion
    wp_unschedule_event($timestamp, 'jsF_submission_report', $args);
}

/**
 * Converts a period of time in seconds into a human-readable format representing the interval.
 *
 * Example:
 *
 *     echo self::interval( 90 );
 *     // 1 minute 30 seconds
 *
 * @param  int    $since A period of time in seconds.
 * @return string        An interval represented as a string.
 */
function jsForms_interval($since) {
// array of time period chunks
    $chunks = array(
        /* translators: 1: The number of years in an interval of time. */
        array(60 * 60 * 24 * 365, _n_noop('%s year', '%s years', 'wp-crontrol')),
        /* translators: 1: The number of months in an interval of time. */
        array(60 * 60 * 24 * 30, _n_noop('%s month', '%s months', 'wp-crontrol')),
        /* translators: 1: The number of weeks in an interval of time. */
        array(60 * 60 * 24 * 7, _n_noop('%s week', '%s weeks', 'wp-crontrol')),
        /* translators: 1: The number of days in an interval of time. */
        array(60 * 60 * 24, _n_noop('%s day', '%s days', 'wp-crontrol')),
        /* translators: 1: The number of hours in an interval of time. */
        array(60 * 60, _n_noop('%s hour', '%s hours', 'wp-crontrol')),
        /* translators: 1: The number of minutes in an interval of time. */
        array(60, _n_noop('%s minute', '%s minutes', 'wp-crontrol')),
        /* translators: 1: The number of seconds in an interval of time. */
        array(1, _n_noop('%s second', '%s seconds', 'wp-crontrol')),
    );

    if ($since <= 0) {
        return __('now', 'wp-crontrol');
    }

// we only want to output two chunks of time here, eg:
// x years, xx months
// x days, xx hours
// so there's only two bits of calculation below:

    $j = count($chunks);

// step one: the first chunk
    for ($i = 0; $i < $j; $i++) {
        $seconds = $chunks[$i][0];
        $name = $chunks[$i][1];

// finding the biggest chunk (if the chunk fits, break)
        $count = floor($since / $seconds);
        if ($count) {
            break;
        }
    }

// set output var
    $output = sprintf(translate_nooped_plural($name, $count, 'wp-crontrol'), $count);

// step two: the second chunk
    if ($i + 1 < $j) {
        $seconds2 = $chunks[$i + 1][0];
        $name2 = $chunks[$i + 1][1];
        $count2 = floor(( $since - ( $seconds * $count ) ) / $seconds2);
        if ($count2) {
// add to output var
            $output .= ' ' . sprintf(translate_nooped_plural($name2, $count2, 'wp-crontrol'), $count2);
        }
    }

    return $output;
}

function jsForms_get_default_submission_fields() {
    return array('created_date', 'unique_id', 'amount', 'payment_invoice', 'payment_status', 'user_active', 'user_role', 'modified_date', 'plans', 'edited', 'tags');
}

function jsForms_get_report_fields($form_id) {
    $form = jsForms()->form->get_form($form_id);
    $form_fields = jsForms()->form->get_fields_dropdown($form_id, array('submit', 'password'));

    $other_fields = array();
    // Adding internal fields 
    $other_fields['created_date'] = __('Created Date', 'jsForms');
    $other_fields['modified_date'] = __('Modified Date', 'jsForms');
    if (!empty($form['enable_unique_id'])) {
        $other_fields['unique_id'] = __('Unique Submission ID', 'jsForms');
    }

    if (!empty($form['plan_enabled'])) {
        $other_fields['amount'] = __('Amount', 'jsForms');
        $other_fields['payment_invoice'] = __('Invoice', 'jsForms');
        $other_fields['payment_status'] = __('Payment Status', 'jsForms');
        $other_fields['plans'] = __('Plan(s)', 'jsForms');
    }

    if ($form['type'] == 'reg') {
        $other_fields['user_active'] = __('User Status', 'jsForms');
        $other_fields['user_role'] = __('User Role', 'jsForms');
    }

    $other_fields['tags'] = __('Submission Label(s)', 'jsForms');
    $other_fields['edited'] = __('Edited', 'jsForms');
    return array_merge(array('id' => __('Submission ID', 'jsForms')), $form_fields, $other_fields);
}

function jsForms_debug($value) {
    echo '<pre>';
    print_r($value);
}

function jsForms_download_file($file, $mime_type, $delete = true) {
    if (ob_get_contents())
        ob_end_clean();

    if (file_exists($file)) {
        header('Content-Description: File Download');
        header('Content-Type:' . $mime_type);
        header('Content-Disposition: attachment; filename="' . basename($file) . '"');
        header('Expires: 0');
        readfile($file);
        if ($delete)
            @unlink($file);
    }
}

function jsForms_address_country() {

    $countries = array(
        '' => __('Select Country', 'jsForms'),
        'AF' => __('Afghanistan', 'jsForms'),
        'AX' => __('Aland Islands', 'jsForms'),
        'AL' => __('Albania', 'jsForms'),
        'DZ' => __('Algeria', 'jsForms'),
        'AS' => __('American Samoa', 'jsForms'),
        'AD' => __('Andorra', 'jsForms'),
        'AO' => __('Angola', 'jsForms'),
        'AI' => __('Anguilla', 'jsForms'),
        'AQ' => __('Antarctica', 'jsForms'),
        'AG' => __('Antigua and Barbuda', 'jsForms'),
        'AR' => __('Argentina', 'jsForms'),
        'AM' => __('Armenia', 'jsForms'),
        'AW' => __('Aruba', 'jsForms'),
        'AU' => __('Australia', 'jsForms'),
        'AT' => __('Austria', 'jsForms'),
        'AZ' => __('Azerbaijan', 'jsForms'),
        'BS' => __('Bahamas', 'jsForms'),
        'BH' => __('Bahrain', 'jsForms'),
        'BD' => __('Bangladesh', 'jsForms'),
        'BB' => __('Barbados', 'jsForms'),
        'BY' => __('Belarus', 'jsForms'),
        'BE' => __('Belgium', 'jsForms'),
        'PW' => __('Belau', 'jsForms'),
        'BZ' => __('Belize', 'jsForms'),
        'BJ' => __('Benin', 'jsForms'),
        'BM' => __('Bermuda', 'jsForms'),
        'BT' => __('Bhutan', 'jsForms'),
        'BO' => __('Bolivia', 'jsForms'),
        'BQ' => __('Bonaire, Saint Eustatius and Saba', 'jsForms'),
        'BA' => __('Bosnia and Herzegovina', 'jsForms'),
        'BW' => __('Botswana', 'jsForms'),
        'BV' => __('Bouvet Island', 'jsForms'),
        'BR' => __('Brazil', 'jsForms'),
        'IO' => __('British Indian Ocean Territory', 'jsForms'),
        'VG' => __('British Virgin Islands', 'jsForms'),
        'BN' => __('Brunei', 'jsForms'),
        'BG' => __('Bulgaria', 'jsForms'),
        'BF' => __('Burkina Faso', 'jsForms'),
        'BI' => __('Burundi', 'jsForms'),
        'KH' => __('Cambodia', 'jsForms'),
        'CM' => __('Cameroon', 'jsForms'),
        'CA' => __('Canada', 'jsForms'),
        'CV' => __('Cape Verde', 'jsForms'),
        'KY' => __('Cayman Islands', 'jsForms'),
        'CF' => __('Central African Republic', 'jsForms'),
        'TD' => __('Chad', 'jsForms'),
        'CL' => __('Chile', 'jsForms'),
        'CN' => __('China', 'jsForms'),
        'CX' => __('Christmas Island', 'jsForms'),
        'CC' => __('Cocos (Keeling) Islands', 'jsForms'),
        'CO' => __('Colombia', 'jsForms'),
        'KM' => __('Comoros', 'jsForms'),
        'CG' => __('Congo (Brazzaville)', 'jsForms'),
        'CD' => __('Congo (Kinshasa)', 'jsForms'),
        'CK' => __('Cook Islands', 'jsForms'),
        'CR' => __('Costa Rica', 'jsForms'),
        'HR' => __('Croatia', 'jsForms'),
        'CU' => __('Cuba', 'jsForms'),
        'CW' => __('Cura&ccedil;ao', 'jsForms'),
        'CY' => __('Cyprus', 'jsForms'),
        'CZ' => __('Czech Republic', 'jsForms'),
        'DK' => __('Denmark', 'jsForms'),
        'DJ' => __('Djibouti', 'jsForms'),
        'DM' => __('Dominica', 'jsForms'),
        'DO' => __('Dominican Republic', 'jsForms'),
        'EC' => __('Ecuador', 'jsForms'),
        'EG' => __('Egypt', 'jsForms'),
        'SV' => __('El Salvador', 'jsForms'),
        'GQ' => __('Equatorial Guinea', 'jsForms'),
        'ER' => __('Eritrea', 'jsForms'),
        'EE' => __('Estonia', 'jsForms'),
        'ET' => __('Ethiopia', 'jsForms'),
        'FK' => __('Falkland Islands', 'jsForms'),
        'FO' => __('Faroe Islands', 'jsForms'),
        'FJ' => __('Fiji', 'jsForms'),
        'FI' => __('Finland', 'jsForms'),
        'FR' => __('France', 'jsForms'),
        'GF' => __('French Guiana', 'jsForms'),
        'PF' => __('French Polynesia', 'jsForms'),
        'TF' => __('French Southern Territories', 'jsForms'),
        'GA' => __('Gabon', 'jsForms'),
        'GM' => __('Gambia', 'jsForms'),
        'GE' => __('Georgia', 'jsForms'),
        'DE' => __('Germany', 'jsForms'),
        'GH' => __('Ghana', 'jsForms'),
        'GI' => __('Gibraltar', 'jsForms'),
        'GR' => __('Greece', 'jsForms'),
        'GL' => __('Greenland', 'jsForms'),
        'GD' => __('Grenada', 'jsForms'),
        'GP' => __('Guadeloupe', 'jsForms'),
        'GU' => __('Guam', 'jsForms'),
        'GT' => __('Guatemala', 'jsForms'),
        'GG' => __('Guernsey', 'jsForms'),
        'GN' => __('Guinea', 'jsForms'),
        'GW' => __('Guinea-Bissau', 'jsForms'),
        'GY' => __('Guyana', 'jsForms'),
        'HT' => __('Haiti', 'jsForms'),
        'HM' => __('Heard Island and McDonald Islands', 'jsForms'),
        'HN' => __('Honduras', 'jsForms'),
        'HK' => __('Hong Kong', 'jsForms'),
        'HU' => __('Hungary', 'jsForms'),
        'IS' => __('Iceland', 'jsForms'),
        'IN' => __('India', 'jsForms'),
        'ID' => __('Indonesia', 'jsForms'),
        'IR' => __('Iran', 'jsForms'),
        'IQ' => __('Iraq', 'jsForms'),
        'IE' => __('Ireland', 'jsForms'),
        'IM' => __('Isle of Man', 'jsForms'),
        'IL' => __('Israel', 'jsForms'),
        'IT' => __('Italy', 'jsForms'),
        'CI' => __('Ivory Coast', 'jsForms'),
        'JM' => __('Jamaica', 'jsForms'),
        'JP' => __('Japan', 'jsForms'),
        'JE' => __('Jersey', 'jsForms'),
        'JO' => __('Jordan', 'jsForms'),
        'KZ' => __('Kazakhstan', 'jsForms'),
        'KE' => __('Kenya', 'jsForms'),
        'KI' => __('Kiribati', 'jsForms'),
        'KW' => __('Kuwait', 'jsForms'),
        'KG' => __('Kyrgyzstan', 'jsForms'),
        'LA' => __('Laos', 'jsForms'),
        'LV' => __('Latvia', 'jsForms'),
        'LB' => __('Lebanon', 'jsForms'),
        'LS' => __('Lesotho', 'jsForms'),
        'LR' => __('Liberia', 'jsForms'),
        'LY' => __('Libya', 'jsForms'),
        'LI' => __('Liechtenstein', 'jsForms'),
        'LT' => __('Lithuania', 'jsForms'),
        'LU' => __('Luxembourg', 'jsForms'),
        'MO' => __('Macao S.A.R., China', 'jsForms'),
        'MK' => __('Macedonia', 'jsForms'),
        'MG' => __('Madagascar', 'jsForms'),
        'MW' => __('Malawi', 'jsForms'),
        'MY' => __('Malaysia', 'jsForms'),
        'MV' => __('Maldives', 'jsForms'),
        'ML' => __('Mali', 'jsForms'),
        'MT' => __('Malta', 'jsForms'),
        'MH' => __('Marshall Islands', 'jsForms'),
        'MQ' => __('Martinique', 'jsForms'),
        'MR' => __('Mauritania', 'jsForms'),
        'MU' => __('Mauritius', 'jsForms'),
        'YT' => __('Mayotte', 'jsForms'),
        'MX' => __('Mexico', 'jsForms'),
        'FM' => __('Micronesia', 'jsForms'),
        'MD' => __('Moldova', 'jsForms'),
        'MC' => __('Monaco', 'jsForms'),
        'MN' => __('Mongolia', 'jsForms'),
        'ME' => __('Montenegro', 'jsForms'),
        'MS' => __('Montserrat', 'jsForms'),
        'MA' => __('Morocco', 'jsForms'),
        'MZ' => __('Mozambique', 'jsForms'),
        'MM' => __('Myanmar', 'jsForms'),
        'NA' => __('Namibia', 'jsForms'),
        'NR' => __('Nauru', 'jsForms'),
        'NP' => __('Nepal', 'jsForms'),
        'NL' => __('Netherlands', 'jsForms'),
        'NC' => __('New Caledonia', 'jsForms'),
        'NZ' => __('New Zealand', 'jsForms'),
        'NI' => __('Nicaragua', 'jsForms'),
        'NE' => __('Niger', 'jsForms'),
        'NG' => __('Nigeria', 'jsForms'),
        'NU' => __('Niue', 'jsForms'),
        'NF' => __('Norfolk Island', 'jsForms'),
        'MP' => __('Northern Mariana Islands', 'jsForms'),
        'KP' => __('North Korea', 'jsForms'),
        'NO' => __('Norway', 'jsForms'),
        'OM' => __('Oman', 'jsForms'),
        'PK' => __('Pakistan', 'jsForms'),
        'PS' => __('Palestinian Territory', 'jsForms'),
        'PA' => __('Panama', 'jsForms'),
        'PG' => __('Papua New Guinea', 'jsForms'),
        'PY' => __('Paraguay', 'jsForms'),
        'PE' => __('Peru', 'jsForms'),
        'PH' => __('Philippines', 'jsForms'),
        'PN' => __('Pitcairn', 'jsForms'),
        'PL' => __('Poland', 'jsForms'),
        'PT' => __('Portugal', 'jsForms'),
        'PR' => __('Puerto Rico', 'jsForms'),
        'QA' => __('Qatar', 'jsForms'),
        'RE' => __('Reunion', 'jsForms'),
        'RO' => __('Romania', 'jsForms'),
        'RU' => __('Russia', 'jsForms'),
        'RW' => __('Rwanda', 'jsForms'),
        'BL' => __('Saint Barth&eacute;lemy', 'jsForms'),
        'SH' => __('Saint Helena', 'jsForms'),
        'KN' => __('Saint Kitts and Nevis', 'jsForms'),
        'LC' => __('Saint Lucia', 'jsForms'),
        'MF' => __('Saint Martin (French part)', 'jsForms'),
        'SX' => __('Saint Martin (Dutch part)', 'jsForms'),
        'PM' => __('Saint Pierre and Miquelon', 'jsForms'),
        'VC' => __('Saint Vincent and the Grenadines', 'jsForms'),
        'SM' => __('San Marino', 'jsForms'),
        'ST' => __('S&atilde;o Tom&eacute; and Pr&iacute;ncipe', 'jsForms'),
        'SA' => __('Saudi Arabia', 'jsForms'),
        'SN' => __('Senegal', 'jsForms'),
        'RS' => __('Serbia', 'jsForms'),
        'SC' => __('Seychelles', 'jsForms'),
        'SL' => __('Sierra Leone', 'jsForms'),
        'SG' => __('Singapore', 'jsForms'),
        'SK' => __('Slovakia', 'jsForms'),
        'SI' => __('Slovenia', 'jsForms'),
        'SB' => __('Solomon Islands', 'jsForms'),
        'SO' => __('Somalia', 'jsForms'),
        'ZA' => __('South Africa', 'jsForms'),
        'GS' => __('South Georgia/Sandwich Islands', 'jsForms'),
        'KR' => __('South Korea', 'jsForms'),
        'SS' => __('South Sudan', 'jsForms'),
        'ES' => __('Spain', 'jsForms'),
        'LK' => __('Sri Lanka', 'jsForms'),
        'SD' => __('Sudan', 'jsForms'),
        'SR' => __('Suriname', 'jsForms'),
        'SJ' => __('Svalbard and Jan Mayen', 'jsForms'),
        'SZ' => __('Swaziland', 'jsForms'),
        'SE' => __('Sweden', 'jsForms'),
        'CH' => __('Switzerland', 'jsForms'),
        'SY' => __('Syria', 'jsForms'),
        'TW' => __('Taiwan', 'jsForms'),
        'TJ' => __('Tajikistan', 'jsForms'),
        'TZ' => __('Tanzania', 'jsForms'),
        'TH' => __('Thailand', 'jsForms'),
        'TL' => __('Timor-Leste', 'jsForms'),
        'TG' => __('Togo', 'jsForms'),
        'TK' => __('Tokelau', 'jsForms'),
        'TO' => __('Tonga', 'jsForms'),
        'TT' => __('Trinidad and Tobago', 'jsForms'),
        'TN' => __('Tunisia', 'jsForms'),
        'TR' => __('Turkey', 'jsForms'),
        'TM' => __('Turkmenistan', 'jsForms'),
        'TC' => __('Turks and Caicos Islands', 'jsForms'),
        'TV' => __('Tuvalu', 'jsForms'),
        'UG' => __('Uganda', 'jsForms'),
        'UA' => __('Ukraine', 'jsForms'),
        'AE' => __('United Arab Emirates', 'jsForms'),
        'GB' => __('United Kingdom (UK)', 'jsForms'),
        'US' => __('United States (US)', 'jsForms'),
        'UM' => __('United States (US) Minor Outlying Islands', 'jsForms'),
        'VI' => __('United States (US) Virgin Islands', 'jsForms'),
        'UY' => __('Uruguay', 'jsForms'),
        'UZ' => __('Uzbekistan', 'jsForms'),
        'VU' => __('Vanuatu', 'jsForms'),
        'VA' => __('Vatican', 'jsForms'),
        'VE' => __('Venezuela', 'jsForms'),
        'VN' => __('Vietnam', 'jsForms'),
        'WF' => __('Wallis and Futuna', 'jsForms'),
        'EH' => __('Western Sahara', 'jsForms'),
        'WS' => __('Samoa', 'jsForms'),
        'YE' => __('Yemen', 'jsForms'),
        'ZM' => __('Zambia', 'jsForms'),
        'ZW' => __('Zimbabwe', 'jsForms'),
    );

    $countries = apply_filters('jsForms_countries', $countries);
    $decoded_countries = array();
    foreach ($countries as $key => $val) {
        $encoded_val = html_entity_decode($val);
        $decoded_countries[$key] = $encoded_val;
    }
    return $decoded_countries;
}

function jsForms_address_country_load($command, $form) {
    $field_names = array();
    foreach ($form['fields'] as $field) {
        if (!isset($field['name']))
            continue;
        if ($field['type'] == 'country') {
            array_push($field_names, $field['name']);
        }
    }
    $command['data'] = jsForms_address_country();
    $command['on'] = $field_names;
    $command['options'] = true;

    return $command;
}

function jsForms_default_field_command() {
    return array('data' => '', 'default_value' => '', 'options' => false, 'on' => array(), 'callback' => '', 'error' => '');
}

// Returns states for imediate state field
function jsForms_address_country_change($commands, $form) {
    $command = jsForms_default_field_command();
    $field_names = array();
    $source = sanitize_text_field($_POST['field_name']);
    $country_found = false;
    foreach ($form['fields'] as $field) {
        if (!isset($field['name']))
            continue;
        if ($source == $field['name']) {
            $country_found = true;
        }

        if ($field['type'] == 'state' && $country_found) {
            array_push($field_names, $field['name']);
            break;
        }
    }

    $command['on'] = $field_names;
    $field_value = sanitize_text_field($_POST['field_value']);
    $states = jsForms_load_country_states($field_value);
    if (empty($states[$field_value])) {
        $command['data'] = array();
    } else {
        $command['data'] = array_merge(array('' => __('Select State/Province', 'jsForms')), $states[$field_value]);
    }
    $command['options'] = true;

    array_push($commands, $command);
    return $commands;
}

function jsForms_load_country_states($code) {
    $states = array();
    if (file_exists(jsFORMS_PLUGIN_DIR . '/assets/states/' . $code . '.php')) {
        include jsFORMS_PLUGIN_DIR . '/assets/states/' . $code . '.php';
    }
    $states = apply_filters('jsForms_states_by_country_code', $states, $code);
    if (isset($states[$code])) {
        $decoded_states = array();
        foreach ($states[$code] as $key => $val) {
            $encoded_val = html_entity_decode($val);
            $decoded_states[$key] = $encoded_val;
        }
        return array($code => $decoded_states);
    }
    return $states;
}

function jsForms_front_submission_table($submission, $exclude = array()) {
    if (!is_array($submission))
        return;

    $html = '';
    $html .= '<table class="jsF-submission-table striped wp-list-table fixed widefat"><tbody>';
    if (!empty($submission['unique_id'])) {
        $html .= '<tr><th>' . __('Unique Submission ID', 'jsForms') . '</th>' .
                '<td>' . $submission['unique_id'] . '</td>' .
                '</tr>';
    }
    $formatter = new jsForms_Submission_Formatter('html', $submission);
    $submission = $formatter->format();

    foreach ($submission['fields_data'] as $single) {
        $html .= '<tr>' .
                '<th><label>' . $single['f_label'] . '</label></th>' .
                '<td>' . $single['f_val'] . '</td>' .
                '</tr>';
    }
    $selected_tags = jsForms()->label->tags_by_submission($submission['id']);
    if (!empty($selected_tags)) {
        $tag_html = '';
        foreach ($selected_tags as $tag_label) {
            $tag = jsForms()->label->get_label_by_name($tag_label);
            if (empty($tag))
                continue;
            $tag_html .= "<span title='" . $tag['desc'] . "' class='jsF-tag' style='background-color:#" . $tag['color'] . "'>$tag_label</span>";
        }

        $html .= '<tr>' .
                '<th><label>' . __('Submission Label(s)', 'jsForms') . '</label></th>' .
                '<td>' . $tag_html . '</td>' .
                '</tr>';
    }
    if (!empty($submission['plans'])) {
        $plan_names = array();
        foreach ($submission['plans'] as $row) {
            $plan = jsForms()->plan->get_plan($row['id']);
            if (!empty($plan)) {
                array_push($plan_names, $plan['name']);
            }
        }
        $html .= '<tr>' .
                '<th><label>' . __('Payment via', 'jsForms') . '</label></th>' .
                '<td>' . jsForms_payment_method_title($submission['payment_method']) . '</td>' .
                '</tr>' .
                '<tr>' .
                '<th><label>' . __('Amount', 'jsForms') . '</label></th>' .
                '<td>' . jsForms_currency_symbol($submission['currency'], false) . $submission['amount'] . '</td>' .
                '</tr>' .
                '<tr>' .
                '<th><label>' . __('Payment Status', 'jsForms') . '</label></th>' .
                '<td>' . ucwords($submission['payment_status']) . '</td>' .
                '</tr>' .
                '<tr>' .
                '<th><label>' . __('Payment Invoice', 'jsForms') . '</label></th>' .
                '<td>' . $submission['payment_invoice'] . '</td>' .
                '</tr>' .
                '<tr>' .
                '<th><label>' . __('Plan Name', 'jsForms') . '</label></th>' .
                '<td>' . implode(', ', $plan_names) . '</td>' .
                '</tr>' .
                '<tr>' .
                '<th><label>' . __('Date', 'jsForms') . '</label></th>' .
                '<td>' . $submission['modified_date'] . '</td>' .
                '</tr>';
    }

    $html .= '</tbody></table>';
    return $html;
}

/* Checks for edit permission */

function jsForms_edit_permission($form, $submission) {
    $allowed = false;
    if (!is_array($form)) { // Fetch Form data if form ID passed
        $form = jsForms()->form->get_form($form);
    }

    if (!is_array($submission)) {
        $submission = jsForms()->submission->get_submission($submission);
    }

    if (empty($form) || empty($submission)) {
        $allowed = false;
    } else {
        if (current_user_can('manage_options') && $submission['form_id'] == $form['id']) {
            $allowed = true;
        } else {
            if (empty($form['en_edit_sub'])) {
                $allowed = false;
            } else if (isset($submission['dis_edit_submission']) && !empty($submission['dis_edit_submission'])) {

                $allowed = false;
            } else {
                $current_user = wp_get_current_user();
                if (!empty($current_user->ID)) {
                    if ($submission['form_id'] == $form['id'] && !empty($submission['user']) && $submission['user']['ID'] == $current_user->ID) {
                        $allowed = true;
                    }
                }
            }
        }
    }

    $allowed = apply_filters('jsF_edit_submission_allowed', $allowed, $submission, $form);
    return $allowed;
}

/* Checks for view permission */

function jsForms_submission_view_permission($form, $submission) {
    $allowed = false;
    if (!is_array($form)) { // Fetch Form data if form ID passed
        $form = jsForms()->form->get_form($form);
    }

    if (!is_array($submission)) {
        $submission = jsForms()->submission->get_submission($submission);
    }

    if (empty($form) || empty($submission)) {
        $allowed = false;
    } else {
        if (current_user_can('manage_options') && $submission['form_id'] == $form['id']) {
            $allowed = true;
        } else {
            $current_user = wp_get_current_user();
            if (!empty($current_user->ID)) {
                if ($submission['form_id'] == $form['id'] && !empty($submission['user']) && $submission['user']['ID'] == $current_user->ID) {
                    $allowed = true;
                }
            }
        }
    }

    $allowed = apply_filters('jsForms_view_submission_check', $allowed, $form, $submission['id']);
    return $allowed;
}

function jsForms_is_woocommerce_activated() {
    if (class_exists('WooCommerce')) {
        return true;
    }
    return false;
}

function jsForms_non_editable_fields() {
    return array('submit', 'password', 'user_email', 'username', 'hidden');
}

function jsForms_is_user_admin() {
    if (current_user_can('manage_options')) {
        return true;
    }
    return false;
}

function jsForms_show_opt_in() {
    if (in_array('mailchimp', jsForms()->extensions) || in_array('mailpoet', jsForms()->extensions)) {
        return true;
    }
    return false;
}

function jsForms_duplicate_post($post, $meta = true) {
    global $wpdb;
    if (empty($post) || !jsForms_is_user_admin()) {
        return false;
    }

    $current_user = wp_get_current_user();
    $new_post_author = $current_user->ID;

    /*
     * new post data array
     */
    $args = array(
        'comment_status' => $post->comment_status,
        'ping_status' => $post->ping_status,
        'post_author' => $new_post_author,
        'post_content' => $post->post_content,
        'post_excerpt' => $post->post_excerpt,
        'post_name' => $post->post_name,
        'post_parent' => $post->post_parent,
        'post_password' => $post->post_password,
        'post_status' => 'publish',
        'post_title' => $post->post_title . '(Copy)',
        'post_type' => $post->post_type,
        'to_ping' => $post->to_ping,
        'menu_order' => $post->menu_order
    );

    /*
     * insert the post by wp_insert_post() function
     */
    $new_post_id = wp_insert_post($args);

    /*
     * get all current post terms ad set them to the new post draft
     */
    $taxonomies = get_object_taxonomies($post->post_type); // returns array of taxonomy names for post type, ex array("category", "post_tag");
    foreach ($taxonomies as $taxonomy) {
        $post_terms = wp_get_object_terms($post->ID, $taxonomy, array('fields' => 'slugs'));
        wp_set_object_terms($new_post_id, $post_terms, $taxonomy, false);
    }

    /*
     * duplicate all post meta just in two SQL queries
     */
    if ($meta) {
        $post_meta_infos = $wpdb->get_results("SELECT meta_key, meta_value FROM $wpdb->postmeta WHERE post_id=$post->ID");
        if (count($post_meta_infos) != 0) {
            $sql_query = "INSERT INTO $wpdb->postmeta (post_id, meta_key, meta_value) ";
            foreach ($post_meta_infos as $meta_info) {
                $meta_key = $meta_info->meta_key;
                if ($meta_key == '_wp_old_slug')
                    continue;
                $meta_value = addslashes($meta_info->meta_value);
                $sql_query_sel[] = "SELECT $new_post_id, '$meta_key', '$meta_value'";
            }
            $sql_query .= implode(" UNION ALL ", $sql_query_sel);
            $wpdb->query($sql_query);
        }
    }


    return $new_post_id;
}

function jsForms_rand_hex_color() {
    return sprintf('#%06X', mt_rand(0, 0xFFFFFF));
}

function jsForms_system_form_notifications($form_type) {
    $defaults = array('auto_reply' => __('User Auto Reply', 'jsForms'), 'admin_notification' => __('Admin Notification', 'jsForms'),
        'edit_submission' => __('Edit Submission', 'jsForms'), 'delete_submission' => __('Delete Submission', 'jsForms'));
    if ($form_type == 'reg') {
        $defaults['user_activation'] = __('User Activation', 'jsForms');
        $defaults['user_verification'] = __('User Verification', 'jsForms');
    }
    return apply_filters('jsF_system_form_notifications', $defaults, $form_type);
}

function jsForms_system_notifications() {
    $defaults = array('offline' => __('Offline User Email', 'jsForms'), 'payment_pending' => __('Payment Pending(User)', 'jsForms'),
        'payment_completed' => __('Payment Completed(User)', 'jsForms'), 'payment_completed_admin' => __('Payment Completed(Admin)', 'jsForms'),
        'note_to_user' => __('Submission Note', 'jsForms'), 'forgot_password' => __('Forgot Password', 'jsForms'));

    return apply_filters('jsF_system_notifications', $defaults);
}

function jsForms_system_form_notification_by_type($type, $form) {
    $notifications = array();
    switch ($type) {
        case 'auto_reply': $notifications = array('enabled' => $form['enabled_auto_reply'], 'recipients' => $form['auto_reply_to'], 'subject' => $form['auto_reply_subject'], 'help' => __('Auto reply emails are sent to the User who is filling the form.', 'jsForms'));
            break;
        case 'admin_notification': $notifications = array('enabled' => $form['enable_admin_notification'], 'recipients' => $form['admin_notification_to'], 'subject' => $form['admin_notification_subject'], 'help' => __('These emails are sent to recipient(s) or to site Admin for every submission.', 'jsForms'));
            break;
        case 'user_activation': $notifications = array('enabled' => $form['enable_act_notification'], 'recipients' => __("User's Email Address", 'jsForms'), 'subject' => $form['user_act_subject'], 'help' => __('This email is sent to the User when user is activated after submission.', 'jsForms'));
            break;
        case 'edit_submission': $notifications = array('enabled' => $form['enable_edit_notifications'], 'recipients' => __("User's and Admin Email Address", 'jsForms'), 'subject' => $form['edit_sub_user_subject'], 'help' => __('These emails are sent to the User and Admin on every edit submission.', 'jsForms'));
            break;
        case 'delete_submission': $notifications = array('enabled' => $form['enable_delete_notifications'], 'recipients' => __("User's and Admin Email Address", 'jsForms'), 'subject' => $form['delete_sub_user_subject'], 'help' => __('These emails are sent to the User and Admin on every submission deletion from front end <b>My Account</b> <code>[jsForms_my_account]</code>', 'jsForms'));
            break;
        case 'user_verification': $notifications = array('enabled' => $form['en_user_ver_msg'], 'recipients' => __("User's Email Address", 'jsForms'), 'subject' => $form['user_ver_subject'], 'help' => __('User verification allows to verify User\'s email account.', 'jsForms'));
            break;
    }

    $notifications = apply_filters('jsF_system_form_notification_by_type', $notifications, $type, $form);
    return $notifications;
}

function jsForms_system_notification_by_type($type, $options) {
    $notifications = array();
    switch ($type) {
        case 'offline': $notifications = array('enabled' => $options['send_offline_email'], 'subject' => $options['offline_email_subject'], 'help' => __('Sends email to users to let them know about the payment procedure.', 'jsForms'));
            break;
        case 'payment_pending': $notifications = array('enabled' => $options['en_payment_pending_email'], 'subject' => $options['pending_pay_email_subject'], 'help' => __('Email will be sent to user when payment status is pending.', 'jsForms'));
            break;
        case 'payment_completed': $notifications = array('enabled' => $options['en_payment_completed_email'], 'subject' => $options['completed_pay_email_subject'], 'help' => __('Email will be sent to user when payment status is completed.', 'jsForms'));
            break;
        case 'payment_completed_admin': $notifications = array('enabled' => $options['en_pay_completed_admin_email'], 'subject' => $options['completed_pay_admin_email_subject'], 'help' => __('Email will be sent to Admin when payment status is completed.', 'jsForms'));
            break;
        case 'note_to_user': $notifications = array('enabled' => $options['en_note_user_email'], 'subject' => $options['note_user_email_subject'], 'help' => __('Email will be sent to user when admin adds any note within the submission and check "notify user" option.', 'jsForms'));
            break;
        case 'forgot_password': $notifications = array('enabled' => 1, 'subject' => $options['forgot_pass_email_subject'], 'help' => __('Forgot password email content.', 'jsForms'));
            break;
    }

    $notifications = apply_filters('jsForms_system_notification_by_type', $notifications, $type, $options);
    return $notifications;
}

function jsForms_global_setting_menus() {
    $defaults = array('general' => array('label' => __('General Settings', 'jsForms'), 'desc' => array(__('Default Registration, Upload Directory, Security Token', 'jsForms'))),
        'user_login' => array('label' => __('Login Options', 'jsForms'), 'desc' => array(__('Social Login, After Login Redirection, Role Based Login Redirection, reCaptcha, Logout Redirection, Form Layout', 'jsForms'))),
        'payments' => array('label' => __('Payments', 'jsForms'), 'desc' => array(__('Currency,Offline', 'jsForms'))),
        'external' => array('label' => __('External Integration', 'jsForms'), 'desc' => array(__('WooCommerce Integration, Google reCaptcha', 'jsForms'))),
        'notifications' => array('label' => __('Global Notifications', 'jsForms'), 'desc' => array(__('Offline payment, Payment completed,Payment pending', 'jsForms'))));

    $menus = apply_filters('jsF_global_setting_menus', $defaults);
    return $menus;
}

function jsForms_form_configuration_menus($type) {
    $menus = array('general' => array('label' => __('General Settings', 'jsForms'), 'desc' => array(__('reCaptcha, Unique Submission ID, Primary Field', 'jsForms'))),
        'display' => array('label' => __('Display Settings', 'jsForms'), 'desc' => array(__('Layout, Label position, Content above the Form', 'jsForms'))),
        'post_sub' => array('label' => __('Post Submission'), 'desc' => array(__('After submission redirection, Success message, Post to external URL', 'jsForms'))),
        'restrictions' => array('label' => __('Restrictions', 'jsForms'), 'desc' => array(__('Allowed User by role, Password restriction, Limit Submissions', 'jsForms'))),
        'edit_sub' => array('label' => __('Edit Submission', 'jsForms'), 'desc' => array(__('Enable edit submission', 'jsForms'))),
        'plans' => array('label' => __('Plans', 'jsForms'), 'desc' => array(__('Configure payment plan(s)', 'jsForms')))
    );

    if ($type == 'reg') {
        $menus['general'] = array('label' => __('General Settings', 'jsForms'), 'desc' => array(__('reCaptcha,Login Form,Unique Submission ID', 'jsForms')));
        $menus['user_account'] = array('label' => __('User Account', 'jsForms'), 'desc' => array(__('Auto User activation,Login after registration, User verification link,User role assignment', 'jsForms')));
    }
    $menus = apply_filters('jsF_form_configuration_menus', $menus, $type);
    return $menus;
}

// Migrate Plan structure for versions less than or equal to 1.4.4
function jsForms_144_plans() {
    $plans = jsForms()->plan->get_plans();
    foreach ($plans as $plan) {
        if ($plan['type'] == 'fixed') {
            $plan['type'] = 'product';
            jsForms()->plan->update_plan($plan);
        }
    }

    // Updating submission data as per the new plan structure
    $args = array(
        'meta_query' => array(
            array(
                'key' => 'jsForm_amount',
                'compare' => 'EXISTS',
            )
        )
    );
    $posts = jsForms()->submission->get('', $args);
    foreach ($posts as $post) {
        $temp = jsForms()->submission->get_meta($post->ID, 'plan');
        $plans = array();
        if (is_array($temp)) {
            foreach ($temp as $t) {
                if (isset($t['type']) && $t['type'] == 'fixed') {
                    $t['type'] = 'product';
                    array_push($plans, array('plan' => $t, 'amount' => $t['price'], 'id' => $t['id']));
                } else {
                    $amount = jsForms()->submission->get_meta($post->ID, 'amount');
                    array_push($plans, array('plan' => $t, 'amount' => $amount, 'id' => $t['id']));
                }
            }
        }
        jsForms()->submission->update_meta($post->ID, 'plans', $plans);
    }

    // Updating form data
    $forms = jsForms()->form->get_forms();
    foreach ($forms as $form) {
        if ($form['type'] != 'reg' || empty($form['plan_enabled']))
            continue;
        $plans = array('enabled' => array(), 'required' => array());
        if ($form['plan_type'] == 'fixed') {
            if (!empty($form['fixed_plan_ids'])) {
                $plans['enabled'] = $form['fixed_plan_ids'];
                if ($form['plan_required']) {
                    $plans['required'] = $form['fixed_plan_ids'];
                }
            }
        } else if ($form['plan_type'] == 'user') {
            if (!empty($form['user_plan_id'])) {
                $form['user_plan_id'] = is_array($form['user_plan_id']) ? $form['user_plan_id'] : array($form['user_plan_id']);
                $plans['enabled'] = $form['user_plan_id'];
                if ($form['plan_required']) {
                    $plans['required'] = $form['fixed_plan_ids'];
                }
            }
        }
        $form['plans'] = $plans;
        jsForms()->form->update_form($form);
    }
}

// Migrate Plan structure for versions less than or equal to 1.4.5
function jsForms_145_migration() {
    // Updating form data for Number padding and offset changes.
    $forms = jsForms()->form->get_forms();
    foreach ($forms as $form) {
        if (!empty($form['unique_id_padding'])) {
            $form['unique_id_offset'] = $form['unique_id_padding'];
            $form['unique_id_padding'] = 0;
            jsForms()->form->update_form($form);
        }
    }
}

// Creates post meta for all the previous submissions
function jsForms_17_migration() {
    $all_forms = jsForms()->form->get_forms();
    if (!empty($all_forms)) {
        foreach ($all_forms as $form) {
            $submissions = jsForms()->submission->get_submissions_by_form($form['id']);
            foreach ($submissions as $submission) {
                if (!empty($submission['fields_data']) && is_array($submission['fields_data'])) {
                    $meta_values = array();
                    foreach ($submission['fields_data'] as $fd) {
                        if (!empty($fd['f_name']) && !empty($fd['f_val'])) {
                            if ($fd['f_type'] == 'date' && !empty($fd['f_timestamp'])) {
                                $fd['f_val'] = $fd['f_timestamp'];
                            }
                            $meta_values['jsForm_' . $fd['f_name']] = $fd['f_val'];
                        }
                    }
                    if (!empty($meta_values)) {
                        $post = array(
                            'ID' => $submission['id'],
                            'meta_input' => $meta_values
                        );
                        wp_update_post($post);
                    }
                }
            }
        }
    }
}

function jsForms_php_date_format_by_js_format($format) {
    switch ($format) {
        case 'mm/dd/yy' : return 'm/d/Y';
        case 'dd/mm/yy' : return 'd/m/Y';
        case 'dd.mm.yy' : return 'd.m.Y';
        case 'mm-dd-yy' : return 'm-d-Y';
        case 'dd-mm-yy' : return 'd-m-Y';
        case 'yy-mm-dd' : return 'Y-m-d';
        default: return 'm/d/Y';
    }
}

function jsForms_get_numeric($val) {
    $val = sanitize_text_field($val);
    $val = str_replace(',', '.', $val); // Some countries uses comma instead of dot. For example: France
    if (is_numeric($val)) {
        return $val + 0;
    }
    return 0;
}

/* Checks for delete permission */

function jsForms_delete_permission($form, $submission) {
    $allowed = false;
    if (current_user_can('manage_options') && $submission['form_id'] == $form['id']) {
        $allowed = true;
    } else {
        if (empty($form['en_edit_sub'])) {
            $allowed = false;
        } else if (empty($form['allow_sub_deletion'])) {
            $allowed = false;
        } else if (isset($submission['dis_edit_submission']) && !empty($submission['dis_edit_submission'])) {
            $allowed = false;
        } else {
            $current_user = wp_get_current_user();
            if (!empty($current_user->ID)) {
                if ($submission['form_id'] == $form['id'] && !empty($submission['user']) && $submission['user']['ID'] == $current_user->ID) {
                    $allowed = true;
                }
            }
        }
    }

    $allowed = apply_filters('jsF_submission_deletion_allowed', $allowed, $submission, $form);
    return $allowed;
}

function jsForms_login_captcha_enabled() {
    $options = jsForms()->options->get_options();
    $captcha = !empty($options['recaptcha_configured']) && !empty($options['rc_site_key']) && !empty($options['en_login_recaptcha']) ? true : false;
    $captcha = apply_filters('jsF_login_captcha', $captcha);
    return $captcha;
}

function jsForms_logout_url() {
    $options = jsForms()->options->get_options();
    if (!empty($options['logout_redirection'])) {
        $redirection = apply_filters('jsF_logout_url', $options['logout_redirection']);
        return wp_logout_url($redirection);
    }
    return wp_logout_url(get_permalink());
}

function jsForms_pass_config($form = null) {
    $conf = array('shortPass' => __('The password is too short.', 'jsForms'),
        'badPass' => __('Weak, try combining letters & numbers.', 'jsForms'),
        'goodPass' => __('Medium, try using special characters.', 'jsForms'),
        'strongPass' => __('Strong password.', 'jsForms'),
        'containsUsername' => __('The password contains the username.', 'jsForms'),
        'enterPass' => __('Type your password.', 'jsForms'),
        'showPercent' => false,
        'showText' => true,
        'animate' => true,
        'animateSpeed' => 'fast',
        'username' => false,
        'usernamePartialMatch' => true,
        'minimumLength' => 4
    );
    // Details about all the above parameters https://github.com/elboletaire/password-strength-meter
    $conf = apply_filters('jsF_pass_meter_conf', $conf, $form);
    return $conf;
}

function jsForms_tell_config($form) {
    //https://github.com/jackocnr/intl-tel-input
    $conf = array('utilsScript' => jsFORMS_PLUGIN_URL . 'assets/js/intlTelUtil.js', 'separateDialCode' => true, 'initialCountry' => 'auto',
        'geoIpLookup' => 'geo_ip_lookpup_tel', 'formatOnDisplay' => false);
    $conf = apply_filters('jsF_tel_conf', $conf, $form);
    return $conf;
}

function jsForms_global_localize() {
    global $wp_locale;
    $data = array();
    $data['ajax_url'] = admin_url('admin-ajax.php');
    $data['my_account'] = array('sub_del_confirm_msg' => __("This will delete the submission permanently. Please confirm.", 'jsForms'), 'pass_config' => jsForms_pass_config());
    $data['parsley'] = jsForms_error_strings();
    $data['user_fields'] = array(); //jsForms_filter_user_fields($form['id'])
    $data['logged_in'] = is_user_logged_in() ? 1 : 0;
    $data['is_admin'] = jsForms_is_user_admin();
    $data['js_strings'] = jsForms_js_strings();
    $data['plan'] = jsForms()->plan->get_plans();
    $options = jsForms()->options->get_options();
    $data['recaptcha_v'] = $options['recaptcha_version'];
    $data['rc_site_key'] = $options['rc_site_key'];
    $data['datepicker_defaults'] = array(
        'closeText' => __('Close'),
        'currentText' => __('Today'),
        'monthNames' => array_values($wp_locale->month),
        'monthNamesShort' => array_values($wp_locale->month_abbrev),
        'nextText' => __('Next'),
        'prevText' => __('Previous'),
        'dayNames' => array_values($wp_locale->weekday),
        'dayNamesShort' => array_values($wp_locale->weekday_abbrev),
        'dayNamesMin' => array_values($wp_locale->weekday_initial),
        'firstDay' => absint(get_option('start_of_week')),
        'isRTL' => $wp_locale->is_rtl(),
    );
    $data = apply_filters('jsF_global_localize', $data);
    return $data;
}

function jsForms_mailchimp_compatibility_notice() {
    ?>
    <div class="notice notice-success is-dismissible">
        <p><?php _e('MailChimp add-on is not compatible to the core EasyRegistrationForms plugin. Please update it from plugin dashboard.', 'jsForms'); ?></p>
    </div>
<?php }

function jsForms_conditional_compatibility_notice() {
    ?>
    <div class="notice notice-success is-dismissible">
        <p><?php _e('Conditional add-on is not compatible to the core EasyRegistrationForms plugin. Please update it from plugin dashboard.', 'jsForms'); ?></p>
    </div>
<?php }

function jsForms_gdpr_compatibility_notice() {
    ?>
    <div class="notice notice-success is-dismissible">
        <p><?php _e('GDPR add-on is not compatible to the core EasyRegistrationForms plugin. Please update it from plugin dashboard.', 'jsForms'); ?></p>
    </div>
<?php }

function jsForms_mailpoet_compatibility_notice() {
    ?>
    <div class="notice notice-success is-dismissible">
        <p><?php _e('MailPoet add-on is not compatible to the core EasyRegistrationForms plugin. Please update it from plugin dashboard.', 'jsForms'); ?></p>
    </div>
<?php
}

function jsForms_array_field_sanitizer(&$item, $key, $exclude= array()) {
    if(!in_array($key, $exclude)){
        $item = sanitize_text_field($item);
    }
}

function jsForms_field_types($type) {
    $types = array();
    array_push($types, array('key' => 'text', 'label' => __('Text Field', 'jsForms'), 'cat' => 'input'));
    array_push($types, array('key' => 'email', 'label' => __('Email', 'jsForms'), 'cat' => 'input'));
    array_push($types, array('key' => 'number', 'label' => __('Number', 'jsForms'), 'cat' => 'input'));
    array_push($types, array('key' => 'date', 'label' => __('Date', 'jsForms'), 'cat' => 'input'));
    array_push($types, array('key' => 'url', 'label' => __('URL', 'jsForms'), 'cat' => 'input'));
    array_push($types, array('key' => 'tel', 'label' => __('Phone', 'jsForms'), 'cat' => 'input'));
    array_push($types, array('key' => 'file', 'label' => __('File Upload', 'jsForms'), 'cat' => 'input'));
    array_push($types, array('key' => 'radio_group', 'label' => __('Radio Group', 'jsForms'), 'cat' => 'input'));
    array_push($types, array('key' => 'checkbox_group', 'label' => __('Checkbox Group', 'jsForms'), 'cat' => 'input'));
    array_push($types, array('key' => 'select', 'label' => __('Select', 'jsForms'), 'cat' => 'input'));
    array_push($types, array('key' => 'textarea', 'label' => __('Textarea', 'jsForms'), 'cat' => 'input'));
    array_push($types, array('key' => 'hidden', 'label' => __('Hidden', 'jsForms'), 'cat' => 'input'));
    array_push($types, array('key' => 'button', 'label' => __('Button', 'jsForms'), 'cat' => 'input'));
    array_push($types, array('key' => 'address', 'label' => __('Address', 'jsForms'), 'cat' => 'input'));

    if ($type == 'reg') {
        array_push($types, array('key' => 'username', 'label' => __('Username', 'jsForms'), 'cat' => 'input'));
        //array_push($types,array('user_email'=>'textbox','label'=>__('User Email','jsForms'),'cat'=>'input'));
    }


    array_push($types, array('key' => 'header', 'label' => __('Header', 'jsForms'), 'cat' => 'display'));
    array_push($types, array('key' => 'richtext', 'label' => __('Rich Text', 'jsForms'), 'cat' => 'display'));
    array_push($types, array('key' => 'splitter', 'label' => __('Splitter', 'jsForms'), 'cat' => 'display'));
    array_push($types, array('key' => 'separator', 'label' => __('Separator', 'jsForms'), 'cat' => 'display'));

    // WordPress fields
    array_push($types, array('key' => 'first_name', 'label' => __('First Name', 'jsForms'), 'cat' => 'wordpress_profile'));
    array_push($types, array('key' => 'last_name', 'label' => __('Last Name', 'jsForms'), 'cat' => 'wordpress_profile'));
    array_push($types, array('key' => 'nick_name', 'label' => __('Nick Name', 'jsForms'), 'cat' => 'wordpress_profile'));
    array_push($types, array('key' => 'bio', 'label' => __('Biographical Info', 'jsForms'), 'cat' => 'wordpress_profile'));
    array_push($types, array('key' => 'website', 'label' => __('Website', 'jsForms'), 'cat' => 'wordpress_profile'));
    
    // Function fields
    array_push($types, array('key' => 'formula', 'label' => __('Formula', 'jsForms'), 'cat' => 'function'));
    return $types;
}

function jsForms_short_tags($form, $submission) {
    $short_tags = array();
    $registration_html = '';

    if (!empty($submission['unique_id'])) {
        $short_tags['{{unique_id}}'] = $submission['unique_id'];
        $registration_html = '<div>' . __('Unique Submission ID', 'jsForms') . ': ' . $submission['unique_id'] . '</div><br>';
    }
    foreach ($submission['fields_data'] as $field) {
        if (empty($field['f_label']))
            contnue;
        if (is_array($field['f_val'])) {
            $field['f_val'] = implode(',', $field['f_val']);
        }
        if ($field['f_type'] == 'file' && !empty($field['f_val'])) {
            if (wp_attachment_is_image($field['f_val'])) {
                $field['f_val'] = '<a target="_blank" href="' . esc_url(jsForms_get_attachment_url($field['f_val'],$submission['id'])) . '">' . __('View File', 'jsForms') . '</a>';
            } else {
                $url = jsForms_get_attachment_url($field['f_val'],$submission['id']);
                $field['f_val'] = '<a target="_blank" href="' . esc_url($url) . '">' . __('View File', 'jsForms') . '</a>';
            }
        }
        $short_tags['{{' . $field['f_label'] . '}}'] = $field['f_val'];
        $registration_html .= '<div>' . $field['f_label'] . ': ' . $field['f_val'] . '</div> <br>';
    }

    if (!empty($submission['plans'])) {
        $short_tags['{{plan_amount}}'] = jsForms_currency_symbol($submission['currency'], false) . $submission['amount'];
        $short_tags['{{plan_payment_status}}'] = ucwords($submission['payment_status']);
        $short_tags['{{plan_invoice}}'] = $submission['payment_invoice'];
        $short_tags['{{plan_payment_method}}'] = jsForms_payment_method_title($submission['payment_method']);
        $payment_html = '';
        $payment_html .= '<div>' . __('Amount', 'jsForms') . ': ' . jsForms_currency_symbol($submission['currency'], false) . $submission['amount'] . '</div> <br>';
        $payment_html .= '<div>' . __('Payment Status', 'jsForms') . ': ' . ucwords($submission['payment_status']) . '</div> <br>';
        $payment_html .= '<div>' . __('Payment Invoice', 'jsForms') . ': ' . $submission['payment_invoice'] . '</div> <br>';
        $payment_html .= '<div>' . __('Payment Method', 'jsForms') . ': ' . jsForms_payment_method_title($submission['payment_method']) . '</div> <br>';
        $short_tags['{{payment_details}}'] = $payment_html;
        $registration_html .= $payment_html;
    }
    if (!empty($submission['user'])) {
        $user = get_user_by('ID', $submission['user']['ID']);
        if (!empty($user)) {
            $short_tags['{{display_name}}'] = $user->display_name;
            $short_tags['{{current_user}}'] = $user->user_email;
            $short_tags['{{user_email}}'] = $user->user_email;
            $short_tags['{{user_login}}'] = $user->user_login;
            $short_tags['{{user_display_name}}'] = $user->display_name;
            $short_tags['{{user_nice_name}}'] = $user->user_nicename;
            $short_tags['{{user_firstname}}'] = $user->first_name;
            $short_tags['{{user_lastname}}'] = $user->last_name;
            $short_tags['{{user_id}}'] = $user->ID;
        }
    } else if (!empty($submission['primary_field_val'])) {
        $display_name = !empty($submission['primary_contact_name_val']) ? $submission['primary_contact_name_val'] : $submission['primary_field_val'];
        $short_tags['{{display_name}}'] = $display_name;
    }

    $short_tags['{{registration_data}}'] = $registration_html;
    $short_tags['{{submission_data}}'] = $registration_html;
    return $short_tags;
}

function jsForms_forgot_pass_email_content() {
    $site_name = jsForms_site_name();
    $message = __('Someone has requested a password reset for the following account:') . "\r\n\r\n";
    $message .= sprintf(__('Site Name: %s'), $site_name) . "\r\n\r\n";
    $message .= sprintf(__('Username: %s'), '{{user_login}}') . "\r\n\r\n";
    $message .= __('If this was a mistake, just ignore this email and nothing will happen.') . "\r\n\r\n";
    $message .= __('To reset your password, use the OTP: ' . '{{otp}}') . "\r\n\r\n";
    return $message;
}

function jsForms_site_name() {
    return is_multisite() ? get_network()->site_name : wp_specialchars_decode(get_option('blogname'), ENT_QUOTES);
}

/**
 * Wrapper to call update_user_meta function. 
 * This simply calls wordpress meta function and does not add any special prefix. 
 * Checks for any special meta key to update user table data. 
 * For example: display_name : updates user's display name. Instead of adding display_name usermeta
 */
function jsForms_update_user_meta($user_id, $m_key, $m_val) {
    switch ($m_key) {
        case 'display_name' : $status = wp_update_user(array('ID' => $user_id, $m_key => $m_val));
            return is_wp_error($status) ? false : true;
    }
    return update_user_meta($user_id, $m_key, $m_val);
}

function jsForms_update_post_meta($post_id,$meta_key,$meta_value,$prefix = true){
    if($prefix){
        $meta_key = 'jsForm_'.$meta_key;
    }
    return update_post_meta($post_id,$meta_key, $meta_value);
}

function jsForms_get_post_meta($post_id,$meta_key='',$prefix = true){
    if($prefix && !empty($meta_key)){
        $meta_key = 'jsForm_'.$meta_key;
    }
    return get_post_meta($post_id,$meta_key,true);
}

function jsForms_get_attachment_url($post_id, $submission_id,$size=''){
    if(wp_attachment_is_image($post_id)){
        $image = wp_get_attachment_image_src($post_id,$size);
        $url = $image ? $image[0] : '';
    } else {
        $url = wp_get_attachment_url($post_id);
    }
    return apply_filters('jsF_attachment_url',$url, $post_id, $submission_id,$size);
}

function jsForms_get_attachment_image($post_id, $submission_id){
    $img = wp_get_attachment_image_src($post_id,'medium');
    $url = $img[0];
    return apply_filters('jsF_attachment_image',$url, $post_id, $submission_id);
}


